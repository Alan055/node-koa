<template>
    <div class="email-warrper">
      <div class="email-box">
        <div class="emailcontent" v-if="isbindEmail">
          <div class="eamilMain modifyEmail" v-if="isShowModifyEmailTips">若需要更改，请填入新的电子邮箱</div>
          <div class="eamilMain"  style="margin-left: -16%;">
            <div class="emailText fl">电子邮箱：</div>
            <div class="eamilInput fl" :class="!verificationEmail && email !== ''?'errborder':''">
              <input type="text" v-model="email" placeholder="请输入您的电子邮箱">
            </div>
          </div>
          <div class="tips"  >
            <div v-if="!verificationEmail && email !== ''"><i class="icon_v3">&#xe645;</i>{{login_pass_error}}</div>
          </div>
          <div class="eamilMain"  >
            <div class="emailNextBtn" :class="verificationEmail && email !== ''?'active':''" @click="verificationEmail && email !== '' && nextEmail()">下一步</div>
          </div>
        </div>
        <div class="eamilMain boxMian" v-show="replaceEmail">
          <div class="emailTitle emailbind" v-show="!ismodifyEmail">开启邮件后查看<span >【邮箱验证码】</span>，输入正确的邮箱验证码完成绑定。</div>
          <div class="emailTitle emailmodify" v-show="ismodifyEmail">
            <p class="emailtxt" style="margin-bottom:18px">您的邮箱：<span>{{bindInfo.email?bindInfo.email.replace(/(.{2}).+(.{2}@.+)/g,"$1****$2"):''}}</span> </p>
            <p  class="emailtxt" style="margin-bottom:34px"> 您正在修改账号绑定的邮箱，请再次确认并进行身份验证</p>
          </div>
          <div class="eamilMain" v-if="isCaptcha" style="width:83.5%;justify-content: start;">
            <div class="emailText fl">图片验证码：</div>
            <div class="selInput imgInput fl" :class="!verificationImgCode && imgYzCode !== ''?'errborder':''">
              <input type="text" class=" fl" placeholder="请输入图片验证码" v-model="imgYzCode" @input="(send_code_error = '',login_pass_error1='5位数字')" />
            </div>
            <span class="imgyzCode  fl" @click="RefreshSrc"><img :src="safetySrc" alt=""></span>
          </div>
          <div class="tips" style="width: 58%;"  v-if="isCaptcha">
            <div v-if="!verificationImgCode && imgYzCode !== ''"><i class="icon_v3">&#xe645;</i>{{login_pass_error1}}</div>
          </div>
          <div class="yzCode" >
            <div class="selInput fl" :class="!verificationEmailCode && yzCode !== ''?'errborder':''">
              <input type="text" placeholder="请输入邮箱验证码" class="fl" v-model="yzCode" @input="checkCode" />
            </div>
            <span class="yzCodeBtn  fl" v-show="!isCountFinish" @click="emailCode">发送验证码</span>
            <span class="yzCodeBtn renew fl" v-show="isCountFinish" >{{countTime}}s 后重新发送</span>
          </div>
          <div class="tips tips1">
             <div v-if="!verificationEmailCode && yzCode !== ''"><i class="icon_v3">&#xe645;</i>{{login_pass_error}}</div>
             <div v-if="send_code_error"><i class="icon_v3">&#xe645;</i>{{send_code_error}}</div>
          </div>
          <div class="emailTitle emailTop">如果半小时内没有收到邮件，请到邮箱的广告邮件，垃圾邮件列表找找或者联系客服，由客服帮您解决。</div>
          <div class="emailNextBtn" @click="verificationEmailCode&&yzCode !== ''&&bindEmail()" :class="verificationEmailCode && yzCode !== ''?'active':''">{{ismodifyEmail?'更换邮箱':'完成绑定'}}</div>
        </div>
        <!-- 完成绑定或者更换 -->
        <div class="emailSuccess" v-show="isSuccess">
          <div class="bgSuccess"></div>
          <div class="successText">绑定成功</div>
          <div class="goDetailBtn" @click="jump">自动返回首页{{countdownTime}}s</div>
        </div>
      </div>
    </div>
</template>

<script>
import {
  userConter,
  userInit,
  registerInit,
  inputlineBtn,
  Prompt,
  getVerifyCode
} from "../../js/index.js";
import { verifyRule } from "../../js/const.js";
import { mapState, mapMutations, mapGetters } from "vuex";
import base from "../../js/pubilc.js";
import breadNav from "./breadNav";
import bindSuccess from './bindSuccess.vue'

const ITEM = base.storage();
let constructObj = function() {
  let obj = {};

  for (let key in verifyRule) {
    if (
      key === "username" ||
      key === "mobile" ||
      key === "psw" ||
      key === "fundPsw" ||
      key === "repeatPsw" ||
      key === "verifyImg" ||
      key === "verifyCode" ||
      key === "fundPsw"
    ) {
      obj[key] = {
        isShow: false,
        val: "",
        tip: verifyRule[key].tip,
        reg: verifyRule[key].reg,
        error: verifyRule[key].error,
        isPass: false,
        isFocus: false
      };
    }
  }
  return obj;
};
let init = {
  userHeader: userInit(),
  userContent: userConter(),
  registerInit: registerInit()
};
export default {
    data () {
        return {
          email: "",
          login_pass_error1: "",
          login_pass_error: "邮箱格式不正确",
          send_code_error: "",
          formObj: constructObj(),
          btns: false, // 不符合规则  按钮不可用
          isCountFinish: false, //是否显示获取验证按钮
          yzCode:'',
          countTime:120,  // 倒计时
          countdownTime:3,  //  3秒后回到个人中心首页
          isSuccess:false, // 是否完成绑定
          isCaptcha:false,   // 是否显示图像验证码
          safetySrc: "", // 图片验证码路径
          imgYzCode: "", // 图片验证码
          isShowModifyEmailTips:false,  // 显示修改邮箱提示
          timer:''
        };
    },
    components: {},
    computed:{
      ...mapState([
        "ismodifyEmail", // 是否显示更换邮箱界面
        "isbindEmail", // 是否显示绑定邮箱界面
        "replaceEmail", //
        "root_userCenter",
        "bindInfo", // 用户绑定的信息
      ]),
      // 验证设置邮箱
      verificationEmail() {
        return /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(this.email);
      },
      // 图片验证码
      verificationImgCode() {
        return verifyRule.verifyImg.reg.test(this.imgYzCode);
      },
      // 邮箱验证码
      verificationEmailCode(){
        return verifyRule.verifyCode.reg.test(this.yzCode)
      }
    },
    methods: {
      ...mapMutations(['setData','setBreadMore','setBread']),
      //获取图片验证码
      RefreshSrc() {
        init.registerInit.RefreshSrc(this);
      },
      // 检验验证码是否符合规则
      checkCode() {
        this.send_code_error = "";
        this.login_pass_error= '格式不正确'
        if (!verifyRule.verifyCode.reg.test(this.yzCode)) {
          this.resetPwdErroe = verifyRule.verifyCode.error;
          return false;
        } else {
          this.resetPwdErroe = "";
          this.btns = true;
        }
      },
      // 邮箱下一步
      nextEmail(){
        this.login_pass_error = ''
        this.isShowModifyEmailTips = false
        this.setData({ key: "isbindEmail", value: false });
        this.setData({ key: "replaceEmail", value: true });
      },
      // 发送邮箱验证码
      sendEmailCode() {
        let _this = this;
        let options = {
          email:this.email?this.email:this.bindInfo.email,
          capchaCode:this.imgYzCode,
	        checkUnique:this.ismodifyEmail?false:true
        }
        _this.$http.post('/yx/u/api/personal/send-email-code',options).then(res=>{
          let data = res.body;
          if(data.code === 0){
            _this.isCountFinish = true;
            this.timer = setInterval(function() {
              if(_this.countTime === 0) {
                  clearInterval(_this.timer);
                  _this.countTime = 120;
                  _this.isCountFinish = false;
              }
              _this.countTime--;
            }, 1000);
            this.btns = false;
            this.login_pass_error = ''
          }else{
            this.btns = false;
            this.isCaptcha = true
            this.RefreshSrc()
            this.send_code_error = data.message
          }
        })
      },
      // 重新发送验证码
      emailCode() {
        this.sendEmailCode()
      },
      // 绑定邮箱
      bindEmail() {
        let _this = this
        let options = {
          email:this.email?this.email:this.bindInfo.email,
          phYzCode:this.yzCode
        }
        if(this.ismodifyEmail){
          _this.$http.post('/yx/u/api/personal/unbind-email',options).then(res=>{
            let data = res.body;
            if(data.code === 0){
              this.$Modal.al_default({
                status: 'confim', content: '您的邮箱已经解绑，是否前往绑定新的邮箱？',
                onOk() {
                  _this.setData({ key: "ismodifyEmail", value: false });
                  _this.setData({ key: "isbindEmail", value: true });
                  _this.setData({ key: "replaceEmail", value: false });
                  _this.isShowModifyEmailTips = true
                  clearInterval(_this.timer);
                  _this.countTime = 120;
                  _this.isCountFinish = false;
                  _this.isCaptcha = false;
                },
                onCancel(){
                  _this.$router.push({path: _this.root_userCenter + '/userDetail'})
                }
              })
              // let timer = setInterval(function() {
              //   if(_this.countdownTime === 0) {
              //       clearInterval(timer);
              //       _this.countdownTime = 3;
              //       _this.isSuccess = false;
              //       _this.$router.push({path: _this.root_userCenter + '/userDetail'})// 跳转到前一个页面
              //   }
              //   _this.countdownTime--;
              // }, 1000);
            }else{
              this.send_code_error = data.message
            }
            this.RefreshSrc()
            this.imgYzCode = ''
            this.yzCode = ''
          })
          return false
        }
        _this.$http.post('/yx/u/api/personal/bind-email',options).then(res=>{
          let data = res.body;
          if(data.code === 0){
            this.setData({ key: "replaceEmail", value: false });
            this.setData({ key: "isbindEmail", value: false });
            this.isSuccess = true
            this.timer = setInterval(function() {
              if(_this.countdownTime === 0) {
                  clearInterval(_this.timer);
                  _this.countdownTime = 3;
                  _this.isSuccess = false;
                  _this.$router.push({path: _this.root_userCenter + '/userDetail'})// 跳转到前一个页面
              }
              _this.countdownTime--;
            }, 1000);
          }else{
            this.send_code_error = data.message
          }
        })
      },
      // 跳转个人中心
      jump(){
        clearInterval(this.timer);
        this.countdownTime = 3;
        this.$router.push('/userCenters/userDetail')
      },
      // 修改面包屑
      setBreadInfo() {
        this.setBreadMore([{label: this.ismodifyEmail?'更换电子邮箱':'绑定电子邮箱', url: '/userEmail'}])
      },
      init(){
        if(!this.isbindEmail&&!this.ismodifyEmail&&!this.replaceEmail){
          this.$router.push({path: this.root_userCenter + '/userDetail'})// 跳转到前一个页面
        }
        this.setBreadInfo()
      }
    },
    created () {
      this.init()
    },
    destroyed() {
      this.setData({ key: "ismodifyEmail", value: false });
      this.setData({ key: "isbindEmail", value: false });
      this.setData({ key: "replaceEmail", value: false });
    },
}

</script>
<style lang="less" scoped>
@import "../../css/global.less";

.email-warrper{
  width: 100%;
  height: 100%;
  overflow: hidden;
  .email-box{
    height: 560px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    border: solid 1px #e3e3e3;
    overflow: hidden;
    .emailcontent{
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      // overflow: hidden;
    }
    .eamilMain{
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      position: relative;
      .emailText{
        font-size: 14px;
        color: #666;
      }
      .eamilInput{
        width: 364px;
        height: 44px;
        line-height: 44px;
        border-radius: 4px;
        border: solid 1px #d9d9d9;
        margin-left: 12px;
        position: relative;
        input{
          width: 100%;
          height: 40px;
          line-height: 44px;
          padding-left: 10px;
          outline: none;
          border-radius: 4px;
        }
        .imgyzCode{
          display: inline-block;
          width: 122px;
          height: 44px;
          border-radius: 4px;
          border: solid 1px #e1e1e1;
          position: absolute;
          top: -4%;
          left: 60%;
          overflow: hidden;
          cursor: pointer;
          img{
            width: 100%;
            height: 100%;
          }
        }
      }
      .imgInput{
        width: 230px;
        height: 44px;
        line-height: 44px;
        border-radius: 4px;
        border: solid 1px #e1e1e1;
        input{
          outline: none;
          padding-left:10px;
          line-height: 40px;
          border-radius: 4px;
          width: 100%;
        }
      }
      .imgyzCode{
        display: inline-block;
        width: 130px;
        height: 44px;
        position: absolute;
        border-radius: 4px;
        border: solid 1px #e1e1e1;
        top: -3%;
        left: 60%;
        overflow: hidden;
        cursor: pointer;
        img{
          width: 100%;
          height: 100%;
        }
      }
      .emailNextBtn{
        width: 177px;
        height: 48px;
        border-radius: 24px;
        border: solid 1px #dddddd;
        background-color: #e1e1e1;
        font-size: 15px;
        color: #999;
        text-align: center;
        line-height: 48px;
        margin-top: 40px;
      }
      .active{
        background: @themeColor;
        color: #fff;
        cursor: pointer;
      }
      .emailTitle{
        width: 100%;
        // height: 40px;
        color: #666;
        font-size: 14px;
        span{
          color: @themeColor;
        }
      }
      .emailbind{
        color: #333;
        margin-bottom:34px;
      }
      .emailmodify{}
      .emailTop{
        margin-top: 50px;
        height: 20px;
      }
      .yzCode{
        // margin: 34px 0 0 0;
        .selInput{
          width: 230px;
          height: 44px;
          line-height: 44px;
          border-radius: 4px;
          border: solid 1px #e1e1e1;
          input{
            outline: none;
            padding-left:10px;
            line-height: 40px;
            border-radius: 4px;
            width: 100%;
          }
        }
        .yzCodeBtn{
          display: inline-block;
          width: 130px;
          height: 44px;
          line-height: 44px;
          text-align: center;
          border: 1px solid @themeColor;
          color: @themeColor;
          font-size: 14px;
          border-radius: 4px;
          margin-left: 10px;
          cursor: pointer;
        }
      }
      .errborder{
        border: 1px solid @themeColor !important;
      }
    }
    .modifyEmail{
      color: @themeColor;
      font-size: 14px;
      margin-bottom: 34px;
    }
    .boxMian{
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }
    .tips{
      width: 78%;
      height: 20px;
      text-align: left;
      color: @themeColor;
      .icon_v3{
        color: @themeColor;
      }
    }
    .tips1{
      width: 57%;
    }
  }
  .emailSuccess{
    height: 100%;
    display: flex;
    align-items: center;
    flex-direction: column;
    justify-content: center;
    .bgSuccess{
      width: 311px;
      height: 254px;
      // background: url('../userCenter/img/rechargeSuccess.png') no-repeat center center;
      background: url('../userCenter/img/rechargeSuccess.png') no-repeat center center;
    }
    .successText{
      font-size: 24px;
      color: #04b682;
      font-weight: bold;
    }
    .goDetailBtn{
      width: 140px;
      height: 44px;
      text-align: center;
      line-height: 44px;
      border-radius: 25px;
      color: #fff;
      background: @themeColor;
      font-size: 14px;
      margin-top: 30px;
      cursor: pointer;
    }
  }
}
</style>
