<template>
  <div class="superPartner">
    <div class="recommendFriends">
      <div class="label">
        <div class="left">推荐好友</div>
        <div class="right" v-if="ruleData">推荐好友规则<span @click="rule=true">查看</span></div>
      </div>
      <div class="content">
        <div class="left">
          <div class="scan">
            <qrcode v-if="invite.inviteCode" :value="invitCode" :options="{ width: 100 }"></qrcode>
          </div>
          <div class="scanBtn">
            <div class="top">推荐二维码</div>
            <div class="btn" @click="creatScan()">生成链接</div>
            <div class="text" @click="creatPoster()">生成海报</div>
          </div>
        </div>
        <div class="right">
          <div v-for="(v,i) in myInfo" :key="i">
            <div class="num" v-if="i<(myInfo.length-1)">¥{{v.num.toFixed(2)}}</div>
            <div class="num" v-else>{{v.num}}</div>
            <div class="text">
              {{v.text}}
              <span @mouseenter="v.show=true" @mouseleave="v.show=false">
                <em class="icon_v3">&#xe6a4;</em>
                <div class="propmt" v-if="v.show"><img src="./img/guide_tri.png" alt="">{{v.detail}}</div>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="report">
      <div class="nav">
        <span v-for="(v,i) in nav" :key="i" @click="navIndex!=i&&(navIndex=i,navChange(i))"
              :class="{'active':navIndex===i}">{{v.text}}</span>
      </div>
      <div class="searchItem">
        <div class="left" v-if="navIndex===0">
          <div class="select">
            <div class="txt">时间：</div>
            <DatePicker type="daterange" :clearable="false" v-model="date" :options="dateLimit"
                        placement="bottom-end" placeholder="最多只能查询7天数据"
                        style="width: 200px"></DatePicker>
          </div>
          <div class="select">
            <Select v-model="quickSelect" class="quickSelect" placeholder="快选" @on-change="quickSelectFn">
              <Option v-for="item in quickSelectArr" :value="item.value" :key="item.value">{{ item.label }}</Option>
            </Select>
          </div>
          <div class="select">
            <div class="txt">类型：</div>
            <Select v-model="typeSelect" class="quickSelect" style="width:120px;" placeholder="类型">
              <Option v-for="item in typeSelectArr" :value="item.value" :key="item.value">{{ item.label }}</Option>
            </Select>
          </div>
          <div class="select">
            <div class="txt">状态：</div>
            <Select v-model="statusSelect" class="quickSelect" style="width:100px;" placeholder="状态">
              <Option v-for="item in statusSelectArr" :value="item.value" :key="item.value">{{ item.label }}</Option>
            </Select>
          </div>
        </div>
        <div class="left" v-if="navIndex===1">
          <div class="name"><span class="txt">用户名：</span><input type="text" v-model="name" placeholder="请输入用户名"></div>
        </div>
        <div class="right">
          <div class="search" @click="nav[navIndex].ajax()"><span>搜索</span></div>
        </div>
      </div>
      <div class="table">
        <ul class="tableTop">
          <li v-for="(v,i) in tableTop[navIndex]" :key="i">{{v}}</li>
        </ul>
        <ul class="tableContent" v-for="(v,i) in tableContent" :key="i" v-if="navIndex===0&&tableContent.length>0">
          <li>{{v.createTime?v.createTime:'-'}}</li>
          <li>{{v.remitTime?v.remitTime:'-'}}</li>
          <li>¥{{v.realAmount.toFixed(2)}}</li>
          <li>{{typeSelectArr.find(e=>e.value==v.isSingleAward).label}}</li>
          <li :class="{'fir':v.remitState==3,'sec':v.remitState==1}">
            {{statusSelectArr.find(e=>e.value==v.remitState).label}}
          </li>
        </ul>
        <ul class="tableContent total" v-if="navIndex===0&&tableContent.length>0"> <!--小计-->
          <li>小计：</li>
          <li></li>
          <li>¥{{subTotalObj.realAmount.toFixed(2)}}</li>
          <li></li>
          <li></li>
        </ul>
        <ul class="tableContent total" v-if="navIndex===0&&statistics&&tableContent.length>0"> <!--总计-->
          <li class="fir">总计：</li>
          <li></li>
          <li class="fir">¥{{statistics.realAmount.toFixed(2)}}</li>
          <li></li>
          <li></li>
        </ul>
        <ul class="tableContent" v-for="(v,i) in tableContent" :key="i" v-if="navIndex===1&&tableContent.length>0">
          <li>{{i+1 + pagination_size*pagination_page}}</li>
          <li>{{v.cn}}</li>
          <li>{{v.loginTime}}</li>
        </ul>
        <div class="tableBottom" v-show="tableContent.length>0">
          <span class="total">记录总数：<span>{{pagination_total}}</span>，页数：<span>{{pagination_page+1}}</span>/<span>{{pagination_pageTotal}}</span></span>
          <Page class="table_pagination" :current="pagination_page+1" @on-change="pagination_change"
                :total="pagination_total" show-elevator
                :page-size="pagination_size"></Page>
        </div>


        <div class="loading" v-show="load"><em class="icon_v3">&#xe6d6;</em>正在加载中</div>
        <div class="noData" v-if="tableContent.length===0&&!load">
          <div class="picture"><em class="icon_v3">&#xe6a5;</em></div>
          <div class="txt">暂无数据</div>
        </div>
      </div>
    </div>

    <!--弹框  查看规则-->
    <Modal class="modal_recommend"
           v-model="rule"
           width="500"
           :title="ruleData?ruleData.title:''"
           :mask-closable="false"
           class-name="vertical-center-modal"
           @on-cancel="">
      <div class="box" v-html="ruleData?ruleData.content:''">

      </div>
      <div class="close" @click="rule=false">关闭</div>
    </Modal>
    <!--弹框  生成海报-->
    <div class="modal_poster" v-if="poster">

      <div class="box" ref="superPartner_download">
        <div class="close" @click="poster=false"></div>
        <div class="scanBox">
          <div class="scan">
            <qrcode v-if="invite.inviteCode" :value="invitCode" :options="{ width: 170,height: 170 }"></qrcode>
          </div>
          <a class="save_btn" :href="realImageSrc" download="海报"><img src="./img/posterBtn.png" alt=""></a>
        </div>
      </div>
    </div>
    <!--存放下载海报的位置-->
    <div ref="poster"></div>
    <!--<Modal class="modal_recommend"-->
    <!--v-model="poster"-->
    <!--width="800"-->
    <!--title="推荐好友规则"-->
    <!--:mask-closable="false"-->
    <!--class-name="vertical-center-modal"-->
    <!--@on-cancel="">-->
    <!--<div class="box">-->
    <!--<img :src="posterUrl" alt="">-->
    <!--</div>-->
    <!--<div class="close" @click="poster=false">关闭</div>-->
    <!--</Modal>-->
  </div>
</template>

<script>
	import qrcode from "@chenfengyuan/vue-qrcode";
	import {mapState, mapMutations, mapActions} from 'vuex';
	import service from "./../../js/service.js";
	import html2canvas from "html2canvas";


	export default {
		components: {qrcode},
		data() {
			return {
				// 我的推荐信息详情 红利  下线投注  盈亏总额  有效会员数
				myInfo: [
					{show: false, text: '我的红利', num: 0, detail: '当前账号的红利收入'},
					{show: false, text: '线下会员人数', num: 0, detail: '当前账号的下线会员人数'},
				],
				// 报表导航栏
				nav: [
					// {text: '账目统计',},
					{text: '红利记录', ajax: this.findDividendRecord},
					{text: '我的线下', ajax: this.myOffline},
				],
				navIndex: 0, // 当前选中的导航栏
				name: '', // 查询用户名
				// date: [moment().add(-0, 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')],// 当前选择的日期
				date: [],// 当前选择的日期
				dateLimit: {// 控制时间选择器的可选时间长度
					disabledDate(date) {
						return date && (date.valueOf() > Date.now());
					}
				},
				quickSelect: '', // 快选的值
				typeSelect: 'all', // 类型的值
				statusSelect: 'all', // 状态的值
				// 快选的下拉选项框
				quickSelectArr: [
					{label: '今日', value: '1'},
					{label: '三日', value: '3'},
					{label: '七日', value: '7'},
				],
				// 盈亏/投注奖励
				typeSelectArr: [
					{label: '全部', value: 'all'},
					{label: '盈亏/投注奖励', value: 0},
					{label: '单次推荐奖励', value: 1},
				],
				// 状态的下拉选项
				statusSelectArr: [
					{label: '全部', value: 'all'},
					{label: '成功', value: 1},
					{label: '审核中', value: 3},
					{label: '已拒绝', value: 2},
				],
				// 表格头部数据
				tableTop: [
					// ['用户名', '有效投注额', '盈亏总额', '奖励红利', '单次推荐奖励', '更新日期'],
					['红利申请时间', '红利审核通过时间', '红利奖励金额', '红利类型', '状态'],
					['序号', '用户名', '最后登录日期']
				],
				tableContent: [], // 表格数据
				subTotalObj: {}, // 小计的数据
				statistics: null, // 总计

				// 分页器
				pagination_total: 0, // 后台的数据总条数
				pagination_page: 0, // 当前是第几页
				pagination_size: 5, // 一页显示多少条数据
				load: false, // 加载中。。。

				// 弹框
				rule: false, // 控制查看规则的弹框开关
				ruleData: {}, // 推荐好友规则数据
				poster: false, // 生成海报弹框的按钮

				// 下载海报的链接  这个是前端通过canvas自动生成的
				realImageSrc: '',
			}
		},
		computed: {
			...mapState(['invite']), // 推荐码和推荐好友的统计信息
			today() {
				return moment().format("YYYY-MM-DD")
			},
			// 后台总页数
			pagination_pageTotal() {
				return Math.ceil(this.pagination_total / this.pagination_size)
			},
			// 二维码
			invitCode() {
				return location.origin + '/registerNew#' + this.invite.inviteCode
			}
		},
		watch: {
			invite() {
				this.initMyInfo()
			}
		},
		methods: {
			...mapActions(["findInviteCode"]),

			// 推荐码和推荐链接
			creatScan() {
				this.$Modal.modal_recommend({inviteCode: this.invite.inviteCode}) // 弹框出推荐码和链接
			},
			// 生成海报
			creatPoster() {
				this.poster = true
				// 将海报图拼接成一张整体  方便用户下载
				this.$nextTick(function () {
					// 生成组合图片
					let obj = this.$refs['superPartner_download'] // 这里是要截屏的dom
					let that = this
					html2canvas(obj).then(function (canvas) {
						that.realImageSrc = canvas.toDataURL("image/png") // 这里生成 图片的下载地址
					})
				}.bind(this))
			},
			// 小计 当前数据的小计  将数组中每个对象相同属性的值累加  只要是数字
			subTotal() {
				this.subTotalObj.realAmount = 0
				for (let val of this.tableContent) {
					val.remitState == 1 && (this.subTotalObj.realAmount += val.realAmount)
				}
			},
			// 红利记录查询
			findDividendRecord() {
				let obj = {
					page: this.pagination_page,
					size: this.pagination_size,
				};
				if (this.date[0]) {
					obj.startDate = moment(this.date[0]).format('YYYY-MM-DD') + " 00:00:00";
					obj.endDate = moment(this.date[1]).format('YYYY-MM-DD') + " 23:59:59";
				}
				this.typeSelect !== 'all' && (obj.awardType = this.typeSelect)
				this.statusSelect !== 'all' && (obj.state = this.statusSelect)
				this.load = true // 打开加载中
				this.tableContent = []
				service.postDefault(this, '/yx/api/activity/recommend/getRecommendAwardList', obj).then(function (result) {
					this.load = false // 关闭加载中
					let res = result.data
					if (res.code === 0) {
						this.tableContent = res.data.list; // 表格内容
						this.pagination_total = res.data.totalCount; // 后台数据总数量
						this.statistics = res.data.statistics; // 总计
						this.subTotal();// 小计的数据
						// this.subTotalObj = res.data.pageStatistics // 小计的数据
					} else {
						this.$Modal.al_default({status: 'warning', content: res.message})
					}
				}, function (err) {
					this.load = false // 关闭加载中
					console.log(err)
				})
			},
			// 我的线下数据查询
			myOffline() {
				let obj = {
					page: this.pagination_page,
					size: this.pagination_size,
				}
				this.name && (obj.userName = this.name)
				this.load = true // 打开加载中
				service.postDefault(this, '/yx/api/activity/recommend/getSubUserLastLogin', obj).then(function (result) {
					let res = result.data
					if (res.code === 0) {
						this.tableContent = res.data.list; // 表格内容
						this.pagination_total = res.data.totalCount; // 后台数据总数量
						// this.statistics = res.data.statistics // 总计
						// this.subTotal() // 计算小计 我的线下不需要小计
					} else {
						this.$Modal.al_default({status: 'warning', content: res.message})
					}
					this.load = false // 关闭加载中
				}, function (err) {
					this.load = false // 关闭加载中
					console.log(err)
				})
			},
			// 快选改变事件
			quickSelectFn(i) {
				this.date = [moment().add(-(i - 1), 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')];// 当前选择的日期
			},
			// 页签点击事件
			navChange(i) {
				this.pagination_page = 0 // 初始化分页器  显示第一页
				this.nav[i].ajax(); // 请求数据
			},
			// 分页器点击事件
			pagination_change(i) {
				this.pagination_page = i - 1 // 当前第几页 后台从0开始
				this.nav[this.navIndex].ajax(); // 请求数据
			},

			// 初始化我的信息
			initMyInfo() {
				this.myInfo[0].num = this.invite.awardAmount;
				this.myInfo[1].num = this.invite.validUserCount;
			},
			// 推荐好友规则数据获取
			initRule() {
				service.post(this, 'notice/contentList', {
					platform: 'pcShow',
					typeCode: 'friend_rules'
				}).then(function (result) {
					let res = result.data
					if (res.code === 0) {
						this.ruleData = res.data.list[0]
					} else {
						this.$Modal.al_default({status: 'warning', content: res.message})
					}
				}, function (err) {
					console.log(err)
				})
			},
			init() {
				this.findInviteCode(this) // 就请求邀请码的接口  --每次进来都要刷新这个接口的 --action
				this.navChange(this.navIndex) // 展示当前导航栏的内容
				this.initRule()
			}
		},
		created() {
			this.init()
		},
		mounted() {

		},
	}
</script>

<style lang='less' scoped>
  @import "./../../css/global.less";

  .superPartner {
    .recommendFriends {
      .bor(@userCent_bor);
      .label {
        border-bottom: 1px solid @userCent_bor;
        background: @userCent_bac;
        height: 36px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 14px;
        padding: 0 10px;
        .left {
          color: #333;
        }
        .right {
          color: #666;
          display: flex;
          justify-content: center;
          align-items: center;
          span {
            width: 42px;
            height: 20px;
            color: #fff;
            background: @themeColor;
            margin-left: 10px;
            border-radius: 4px;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
          }
        }
      }
      .content {
        height: 126px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        .left {
          width: 226px;
          height: 100%;
          display: flex;
          justify-content: space-around;
          align-items: center;
          border-right: 1px solid @userCent_bor;
          .scan {
            width: 100px;
            height: 100px;
          }
          .scanBtn {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            font-size: 14px;
            color: #666;
            height: 100%;
            .top {
              color: #333;
              font-weight: 600;
              font-size: 16px;
            }
            .btn {
              margin: 8px 0;
              .bor(#ffc178);
              background: #fff0db;
            }
            .text {
              .bor(#fb849a);
              background: #ffd8dd;
            }
            .btn, .text {
              display: flex;
              justify-content: center;
              align-items: center;
              border-radius: 3px;
              padding: 0 4px;
              flex-wrap: wrap;
              width: 90px;
              cursor: pointer;
            }
          }
        }
        .right {
          display: flex;
          justify-content: space-between;
          align-items: center;
          width: calc(~"100% - 226px");
          height: 80%;
          > div {
            width: 50%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            border-right: 1px dashed @userCent_bor;
            height: 100%;
            .num {
              font-size: 20px;
              color: @themeColor;
            }
            .text {
              color: #666;
              font-size: 14px;
              span {
                position: relative;
                em {
                  font-size: 14px;
                  margin-left: 5px;
                  cursor: pointer;
                }
                .propmt {
                  position: absolute;
                  z-index: 10;
                  min-width: 200px;
                  max-width: 206px;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  flex-wrap: wrap;
                  min-height: 40px;
                  .bor(@themeColor);
                  border-radius: 2px;
                  background: #fcf5f5;
                  left: 2px;
                  top: 28px;
                  padding: 0 5px;
                  img {
                    position: absolute;
                    transform: rotate(180deg);
                    left: 4px;
                    top: -8px;
                  }
                }
              }
            }
          }
          > div:last-child {
            border-right: none;
            .num {
              color: #666;
            }
          }
        }
      }
    }
    .report {
      .bor(@userCent_bor);
      border-bottom: none;
      margin-top: 10px;
      .nav {
        height: 40px;
        display: flex;
        justify-content: left;
        align-items: center;
        background: @userCent_bac;
        font-size: 14px;
        span {
          position: relative;
          width: 140px;
          height: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
          color: #333;
          cursor: pointer;
          &.active {
            color: @themeColor !important;
            background: #fff;
            .al_navWood();
          }
        }

      }
      .searchItem {
        display: flex;
        justify-content: left;
        align-items: center;
        padding: 0 10px;
        height: 60px;
        .left {
          display: flex;
          justify-content: left;
          align-items: center;
          .select {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-left: 10px;
          }
          .txt {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            width: 60px;
            font-size: 14px;
            color: #666;
          }
          .name {
            display: flex;
            justify-content: space-between;
            align-items: center;
            input {
              .bor(@userCent_bor);
              border-radius: 3px;
              width: 160px;
              height: 30px;
              outline: none;
              padding: 0 6px;
            }
          }
          .date {
            display: flex;
            justify-content: left;
            align-items: center;
          }
        }
        .right {
          display: flex;
          justify-content: space-between;
          align-items: center;
          .search {
            margin-left: 20px;
            span {
              display: flex;
              justify-content: center;
              align-items: center;
              width: 60px;
              height: 24px;
              border-radius: 12px;
              background: @themeColor;
              cursor: pointer;
              font-size: 14px;
              color: #fff;
            }
          }
        }
      }
      .table {
        > ul {
          height: 40px;
          background: @userCent_bac;
          border-top: 1px solid @userCent_bor;
          border-bottom: 1px solid @userCent_bor;
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 14px;
          color: #333;
          li {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 50%;
            border-right: 1px solid @userCent_bor;
            height: 100%;
            &:last-child {
              border-right: none;
            }
          }
        }
        .tableContent {
          font-size: 12px;
          color: #666;
          border-top: none;
          background: #fff;
          &:last-child {
            border-bottom: none;
          }
          &.total {
            background: @userCent_bac;
          }
          .fir {
            color: @themeColor;
          }
          .sec {
            color: @themeColor_Sec;
          }
        }
        .tableBottom {
          position: absolute;
          bottom: 10px;
          right: 20px;
          left: 20px;
          padding: 10px 0;
          border: none;
          display: flex;
          align-items: center;
          justify-content: space-between;
          .total {
            span {
              color: @themeColor;
            }
          }
          .table_pagination {
            border: none;
          }
        }
      }
      .loading {
        display: flex;
        justify-content: center;
        align-items: center;
        height: calc(~"100% - 40px");
        font-size: 14px;
        color: #888;
        em {
          color: #CFCFCF;
          font-size: 24px;
          animation: transitionSelf 0.7s linear infinite;
          margin-right: 8px;
        }
      }
      .noData {
        height: 300px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        border-bottom: 1px solid @userCent_bor;
        .picture {
          em {
            color: #888;
            opacity: 0.4;
            font-size: 52px;
          }
        }
        .txt {
          color: #888;
          font-size: 16px;
        }
      }
    }
    .modal_poster {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(200, 200, 200, 0.5);
      z-index: 99;
      .box {
        position: relative;
        background: url("/static/img/poster.png");
        background-size: 100% 100%;
        width: 1200px;
        height: 600px;
        margin: 160px auto;
        .close {
          background: url("./img/posterclose.png");
          width: 50px;
          height: 50px;
          top: -50px;
          right: -44px;
          border-radius: 50%;
          position: absolute;
          cursor: pointer;
        }
        .scanBox {
          width: 220px;
          height: 309px;
          background-size: 100%;
          border-radius: 21px;
          position: absolute;
          right: 10px;
          bottom: 0px;
          .scan {
            /*background: #fff;*/
            background: url("./img/scan_bg.png");
            background-size: 100% 100%;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 10px;
          }
          .save_btn {
            font-size: 27px;
            border-radius: 30px;
            width: 110%;
            height: 80px;
            color: #fff;
            margin: 0 auto;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            margin-left: -5%;
            img{
              width: 100%;
              height: 100%;
            }
          }
        }
      }
    }
  }
  @media screen and (max-width: 1200px) {
    .superPartner{
      .modal_poster{
        .box{
          width: 960px;
        }
      }
    }
  }
</style>
