<template>
  <div class="alan_recentGame">
    <span class="text">我的喜爱:</span>
    <div class="game" :class="{'first':i===0}" v-if="data" v-for="(v,i) in data" :key="i">
      <label class="txt">{{v.showName}}</label>
      <p>{{transformationTime(Number(v.surplusTime))}}</p>
    </div>
  </div>
</template>

<script>
	import service from "./../../js/service.js";
	import {mapState, mapMutations, mapActions} from 'vuex';

	export default {
		props: ['recentGame'],
		data() {
			return {
				data: null,
			}
		},
		computed: {
			...mapState(['initStatus_recentGame']),
		},
		watch: {
			initStatus_recentGame() {
				this.init()
			}
		},
		methods: {
			//获取我的喜爱（最近游戏）数据  后台取
			findFavourite() {
				service.get(this, 'game-lottery/get-favourite-game', {}).then(function (result) {
					let res = result.data
					if (res.code === 0) {
						this.data = res.data
					} else {
            this.$Modal.al_default({status:'warning',content:res.message})
					}
				}, function (err) {
					console.log(err)
				})
			},
			//处理开奖倒计时数据
			transformationTime(v) {
				if (v > 0) {
					let h = parseInt(v / 3600) + '';
					let m = parseInt((v - h * 3600) / 60) + '';
					let s = parseInt((v % 60)) + '';
					return `${(h).padStart(2, '0')} : ${(m).padStart(2, '0')} : ${(s).padStart(2, '0')}`;
				}
				return '00 : 00 : 00'
			},


			init() {
				//获取我的喜爱数据  后台取
				this.findFavourite()
			}
		},
		created() {
			this.init()
		},
		mounted() {
		},
	}
</script>

<style lang='less' scoped>
  .alan_recentGame {
    width: 1200px;
    height: 48px;
    line-height: 48px;
    margin: 0 auto;
    background: rgba(240, 240, 240, 0.4);
    overflow: hidden;
    .text {
      display: inline-block;
      float: left;
      width: 100px;
      line-height: 48px;
      font-size: 18px;
      color: #fff;
    }
    .game {
      display: inline-block;
      float: left;
      margin: 5px;
      width: 100px;
      /*border: 1px solid #ecc0c3;*/
      background: url("./lotteryImg/btn_normal_bg.png") no-repeat;
      background-size: 100% 100%;
      border-radius: 6px;
      overflow: hidden;
      height: 38px;
      cursor: pointer;
      /*line-height: 38px;*/
      label {
        float: left;
        height: 14px;
        display: inline-block;
        font-size: 14px;
        overflow: hidden;
        line-height: 14px;
        width: 100%;
        margin-top: 4px;
        margin-bottom: 3px;
        color: #333333;
      }
      p {
        float: left;
        height: 10px;
        overflow: hidden;
        line-height: 10px;
        display: inline-block;
        font-size: 12px;
        width: 100%;
        color: #F53B4A;
      }
    }
    .first {
      background: #F53B4A;
      * {
        color: #fff !important;
      }
    }
  }
</style>