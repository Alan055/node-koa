let prefix_common = 'DW_clickH400_';
let prefix_loanList = prefix_common + '21';

let loanList = {
  clickGoLink: prefix_loanList + '01', // 点击“协议链接”
};

export default {
  loanList
};
