<template>
  <div class="note">
    <div class="mode">
      <!--模式：-->
      <span v-for="(v,i) in modeArr" :key="i" :class="{'active':v===mode}"
            @click="changeMode(i)">{{v}}</span>
    </div>
    <div class="calc">
      <!--<span>倍数：</span>-->
      <span class="reduce" @click="multiple>1&&setData({key: 'multiple',value: multiple-1})">-</span>
      <input type="number" v-model.trim.number="multiple1" @blur="!multiple1&&(multiple1=1)">
      <span class="add" @click="multiple<9999&&setData({key: 'multiple',value: multiple+1})">+ </span>
    </div> <span style="vertical-align: top;"> 倍</span>


    <label>已选<span>{{note}}</span>注</label>
    <div class="process" v-show="userMaxCode!==userMinCode">
      奖金
      <div id="process_note" class="process_note" ref="process_note"></div>
      <span>{{currentCode+'/'+percent+'%'}}</span>
    </div>
    <div class="total">共计<span>{{total}}</span>元</div>
    <slot></slot>
  </div>
</template>

<script>
	import 'nouislider';//插件  --滑块
	import {mapState, mapMutations} from 'vuex';




	export default {
		props: ['note', ],//note是注数
    components:{},
		data() {
			return {
				multiple1:1,// 用于输入框显示
				modeArr: ['元', '角', '分', '厘'],//模式
				modeIndex: 0,//当前选中的模式---元角分厘
				userMaxCode: 0,//用户最高号
				userMinCode: 0,//用户最低号
				currentCode: 0,//当前用户的号
				percent: '0.0%',//占比，用来显示的 --返点率
				univalent: 1,//单价
				total: 0,//总价格
			}
		},
		computed: {
      ...mapState(['baseInfo','lotteryConfig','mode','multiple']),
    },
		watch: {
			//改变倍数的时候
			multiple(aft, pre) {
				// 倍数改变时的事件
				this.multipleChange(aft, pre);
			},
			multiple1(aft, pre){
				// 倍数改变时的事件
				this.multipleChange(aft, pre);
      },
			initConfig() {
				this.initConfig()
			},
			note() {
				this.setData({key: "note", value: this.note})
				this.calcTotal()
			},
			lotteryConfig(){
				this.initConfig()
      },
			mode(aft){
				this.modeIndex = this.modeArr.indexOf(this.mode)
				this.calcTotal()
      },
		},
		methods: {
      ...mapMutations(['setData',]),
			//初始化配置
			initConfig() {
				//具体这块的逻辑我也不是很懂
				this.userMaxCode = parseInt(this.lotteryConfig.maxBetCode);//用户最高号
				this.userMinCode = this.lotteryConfig.sysCode - this.baseInfo.lotteryAccount.point * 20;  //用户最低号
				this.currentCode = this.baseInfo.lotteryAccount.code < this.lotteryConfig.maxBetCode?this.lotteryConfig.maxBetCode:this.baseInfo.lotteryAccount.code;//当前用户的号---奖金
				this.univalent = this.lotteryConfig.sysUnitMoney;//每一注的价格
				this.calcPercent() //计算百分比
        this.setProcess()
			},
			//初始化进度条，使用插件
			initProcess() {
				// let slider = window.document.getElementById('process_note').attributes//原生的无法没有val(),jq的有
				let slider = $('.process_note')
				let that = this
				//vue的写法---这里有一个致命的地方，就是没有回调（可能是我还找到）
				// slider && noUiSlider.create(slider, {
				// 	connect: 'lower',
				// 	behaviour: 'snap',
				// 	step: 2,
				// 	start: that.currentCode,
				// 	range: {
				// 		'max': that.userMaxCode,
				// 		'min': that.userMinCode,
				// 	}
				// });
				//原生的写法  ---这里千万注意  max和min的值相等时  移动滑块就会是NaN,所以当相等时 隐藏  切不可移动
				!slider.noUiSlider&&slider.noUiSlider({
					connect: 'lower',
					behaviour: 'snap',
					step: 2,
					start: that.currentCode,
					range: {
						'max': that.userMaxCode,
						'min': that.userMinCode,
					}
				})
				slider.on({
					//滑动停止回调
					set() {
					},
					//滑动变化回调
					slide() {
						that.currentCode = parseInt(slider.val())
						that.calcPercent() //计算百分比
						that.setProcess()
					}
				});
			},

      // 倍数改变时的事件
			multipleChange(aft, pre){
				let num = parseInt(aft)
				if (isNaN(num)) {
					num = ''
					this.setData({key: 'multiple',value: 0})
				} else {
					this.setData({key: 'multiple',value: num = num > 9999 ? 9999 : num < 1 ? 0 : num})
					num === 0 && (num='')
				}
				this.multiple1=num
				this.calcTotal()
      },
			//计算百分比
			calcPercent() {
				this.percent = (this.baseInfo.lotteryAccount.point - ((this.currentCode - this.userMinCode) / 20).toFixed(1)).toFixed(1)//初始化出占比
			},
			//切换模式（元加分厘）
			changeMode(i) {
				this.modeIndex=i;
				this.setData({key: "mode", value: this.modeArr[i]})
				this.calcTotal()
			},
			//注数改变时，计算各个选注栏的值--主要是总价格改版
			changeNote() {
				this.total = this.note === 0 ? 0 : (this.note * this.multiple * (Math.pow(0.1, this.modeIndex) * this.univalent)).toFixed(3)
			},
			//计算总投注金额---选注栏总计
			calcTotal() {
				this.total = (this.note * this.multiple * this.univalent * Math.pow(0.1, this.modeIndex)).toFixed(3)
				this.setData({key: "total", value: this.total })
			},
      //将滑块的数据写入vux中   奖金和返点
      setProcess(){
	      this.setData({key: "bonus", value: this.currentCode})
	      this.setData({key: "percent", value: this.percent})
      },

			init() {
				this.setData({key: "mode", value: '元'})
				this.initProcess()
			}
		},
		created() {
			this.setData({key: "multiple", value: 1})// 刷新倍数
			this.lotteryConfig&&this.initConfig()
		},
		mounted() {
			this.init()
		},

	}
</script>

<style lang='less' scoped>
  @import "../../css/global.less";
  .note {
    font-size: 14px;
    height: 64px;
    line-height: 64px;
    border-top: 1px solid @methodBox_bor;
    border-bottom: 1px solid @methodBox_bor;
    text-align: left;
    color: @chooseNoteColor;
    /*display: flex;*/
    /*align-items: center;*/
    background: #fff;
    label {
      vertical-align: top;
      /*letter-spacing: 2px;*/
      margin-left: 36px;
      span {
        vertical-align: top;
        color: @themeColor;
      }
    }
    > div {
      display: inline-block;
      /*line-height: 56px;*/
    }
    .calc {
      .bor(@chooseNumberBox_bor);
      width: 100px;
      height: 26px;
      line-height: 26px;
      margin-left: 26px;
      overflow: hidden;
      font-size: 14px;
      margin-right: 6px;
      user-select: none;
      margin-top: 18px;
      span, input {
        float: left;
        display: inline-block;
      }
      .reduce, .add {
        display: inline-block;
        height: 24px;
        width: 24px;
        background: #dddddd;
        color: #333;
        line-height: 24px;
        text-align: center;
        cursor: pointer;
        font-size: 16px;
      }
      input {
        height: 24px;
        width: 50px;
        text-align: center;
        vertical-align: top;
        display: inline-block;
        -webkit-appearance: none;
        -moz-appearance: textfield;
        outline: none;
        &::-webkit-inner-spin-button {
          -webkit-appearance: none;
        }
      }
    }
    .mode {
      .bor(@chooseNumberBox_bor);
      height: 26px;
      width: 96px;
      display: flex;
      justify-content: center;
      border-radius: 2px;
      overflow: hidden;
      margin-left: 20px;
      float: left;
      margin-top: 18px;
      span {
        width: 25%;
        background-color: #fff;
        height: 100%;
        line-height: 24px;
        border-right: 1px solid #d9d9d9;
        text-align: center;
        cursor: pointer;
        font-size: 14px;
        display: inline-block;
        user-select: none;
        &:last-child{
          border: none;
        }
        &.active {
          color: #fff;
          background-color: @themeColor;
          /*border-color: #0cbc9e;*/
        }
      }
    }
    .process {

      #process_note {
        width: 70px;
        display: inline-block;
        margin: 0 8px 0 10px;
        height: 8px !important;
        border: none !important;
        background-color: #ff934b;
        border-radius: 4px !important;
        margin-top: 13px;

      }
    }
    .total {
      display: inline;
      vertical-align: top;
      /*letter-spacing: 2px;*/
      margin-left: 20px;
      span {
        vertical-align: top;
        color: @themeColor;
      }
    }
  }
  @media screen and (max-width: 1024px){
    .note{
      height: 124px;
      .addNumber{
        margin-right: calc(~"50% - 146px");
        height: 40px;
      }
    }

  }
</style>