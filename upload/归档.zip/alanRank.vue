<template>
  <div class="alanRank">
    <div class="rankTop" v-if="code">
      <div class="left">
        <div class="leftBox">
          <span v-for="(v,i) in tabArr" :key="i" :class="{'active':topIndex===i}" @click="topIndex=i;changeTab()">{{v.name}}</span>
        </div>
      </div>
      <div class="right">
        <Select v-model="currentItem" style="width:80px;height: 24px" @on-change="changeSelect">
          <Option v-for="v,i in selectList" :value="v.value" :key="i">{{ v.label }}</Option>
        </Select>
      </div>
    </div>
    <div class="rankContent">
      <div v-for="(v,i) in showData" :key="i" class="rankItem" @click="itemClick(v)" v-if="showData.length&&code">
        <div class="txt0">{{v.txt0}}</div>
        <div class="txt1">@{{v.txt1}}</div>
        <div class="issue">{{v.issue}}期</div>
        <div class="serial">
          <em class="icon_v3" v-if="i<=2">&#xe699;</em>
          <span v-if="i>2">{{i+1}}</span>
        </div>
      </div>
      <div class="noData" v-if="showData.length === 0||!code">
        <div class="picture"><em class="icon_v3">&#xe6a5;</em></div>
        <div class="txt">暂无数据</div>
      </div>
    </div>

    <Modal class="modal_Ma"
           v-model="modal_Ma"
           title="快速盘口投注"
           width="500px"
           ok-text="确定投注"
           @on-ok="fastBet"
           :mask-closable="false"
           class-name="vertical-center-modal"
           @on-cancel="">
      <div class="top" v-if="fastBet_label">
        <span>{{fastBet_label.txt0}}</span>
        <span>【{{fastBet_label.txt1}}】</span>
        <span>@{{fastBet_label.odds}}</span>
      </div>
      <p>金额：<input type="text" v-model="fastBet_money"/><span>元</span></p>
    </Modal>
  </div>
</template>

<script>
  import service from "./../../js/service.js";
  import {mapState, mapMutations, mapActions} from 'vuex';
  import mapping from "./js/mapping.js";//引入映射表
  import calcObj from "./js/lottery_calc.js";//引入计算函数
  import {getLotteryType} from "../../js/common.js";//公共方法


  var typeObj = mapping;//存一下这个大对象
  export default {
    data() {
      return {
        code: '',//当前玩法的code  "CQSSCXJW" //控制出码联动是否展示，有的玩法是没有出码联动的 比如3d  快3  根据映射表的出码字典来判断
        topIndex: 0,//当前选项
        selectList: [],//期号选项
        currentItem: 'all',//当前选中的期号
        tabArr: [{key: 'lengRe', name: '出码'}, {key: 'yiLou', name: '遗漏'}],//tab切换时所需要用到的数据的key值
        saveData: [],//内容数据保存起来 这个用于隐射数据  总的
        showData: [],//这个用于展示  可以通过总数据来筛选
        ajaxData: null,//存储ajax的数据 方便页签切换
        oddsData: null,//将利率存起来
        odds: null,//点击条目  计算出当前条目的利率值
        modal_Ma: false,//快速盘口投注的弹框
        fastBet_money: 1,//快速盘口投注的金额
        fastBet_label: null,//快速盘口投注的label
        keyStr: null,//通过计算得到的赔率的key值（前+j）  其实就是投注的时候 要发送给后台的id值
        currentLottery_officialId: '0',//当前彩种对应的官方id
        currentLottery_officialType: '',//当前彩种对应的官方玩法大类 sscs  11x5...
      }
    },
    computed: {
      ...mapState(['currentLottery', 'biggerType', 'initStatus_tableRecord', 'initStatus_Rank']),
    },
    watch: {
      // 切换经典玩法和官方玩法时
      biggerType() {
        this.init()
      },
      // 当前彩种玩法改变时
      currentLottery() {
        this.init()
      },
      fastBet_money(aft, pre) {
        // 控制输入金额在 1-9999999之间
        if (aft === pre) return
        let num = Number(aft)
        if (isNaN(num)) {
          this.fastBet_money = ''
        } else {
          this.fastBet_money = num > 9999999 ? 9999999 : num < 1 ? '' : num
        }
      },
      initStatus_Rank() {
        this.init()
      }

    },
    methods: {
      ...mapMutations(['setData']),
      // 获取出码和遗漏的数据
      findData() {
        this.showData = []// 展示数据清空
        this.saveData = []// 保存的数据清空
        if (this.biggerType !== 'jd') {
          this.currentLottery_officialId = this.currentLottery.id
          this.currentLottery_officialType = this.biggerType
          this.code = typeObj['lottery_' + this.biggerType].dictionary[String(this.currentLottery.id)]//对应经典的code
        } else {
          this.currentLottery_officialId = this.dictionary[1][this.currentLottery.id]; //当前彩种对应的官方id
          this.currentLottery_officialType = getLotteryType(this.currentLottery_officialId);//当前彩种对应的官方玩法大类 sscs  11x5...
          this.code = this.currentLottery.code; //code
        }
        this.setData({key: 'isHasJd', value: !!this.code})
        this.$store.commit('setLuzhu', {})
        // if (!this.code) return
        //获取赔率的数据
        this.findOdds(this.code)
        //下面是获取出码和遗漏的数据
        this.ajaxData = null
        service.get(this, 'game-lottery/search-zhCm', {
          id: this.currentLottery.id,
          _: new Date().getTime()
        }).then(function (result) {
          let res = result.data
          if (res.code === 0) {
            //分页切换  分页取默认值
            this.ajaxData = res.data
            this.changeTab()
            if (res.data.luZhu) {
              this.$store.commit('setLuzhu', res.data.luZhu)
            }
          } else {
            console.log(res.message)
          }
        }, function (err) {
          console.log(err)
        })
      },
      // 获取赔率的数据
      findOdds(code) {
        service.post(this, 'xjw-lottery/init-game-lottery', JSON.stringify({
          lotteryId: code,
          numberPostion: ''
        })).then(function (result) {
          let res = result.data
          if (res.Success === '1') {
            this.oddsData = res.Obj
          }
        }, function (err) {
          console.log(err)
        })
      },
      //获取下拉框数据 --筛选去重保存的数据  第一个是全部
      findSelectList() {
        let arr = []
        for (let val of this.saveData) {
          !arr.find((e) => (e.value === val.issue)) && (arr.push({value: val.issue, label: val.issue + '期'}))
        }
        arr.unshift({label: '全部', value: 'all'})
        this.selectList = arr
        this.currentItem = arr[0].value// 将下拉框的数据清空
      },
      //分页切换的事件
      changeTab() {
        let data = this.ajaxData[this.tabArr[this.topIndex].key];
        let arr = []
        for (let key in data) {
          let a = data[key]
          for (let k in a) {
            arr.push({txt0: k.split('@')[0], txt1: k.split('@')[1], issue: a[k]})
          }
        }
        arr.sort(function (a, b) {
          return b.issue - a.issue
        })
        this.saveData = arr;//保存起来
        this.showData = arr;// 暂时数据赋值--暂时是一样的
        this.findSelectList()
      },
      // 下拉框选择的切换
      changeSelect(v) {
        // this.showData = [];//初始化数据
        if (v === 'all') {
          this.showData = this.saveData
          return
        }
        let arr = []
        //筛选指定期数的数据
        for (let val of this.saveData) {
          val.issue === v && arr.push(val)
          if (arr.length > 0 && val.issue !== v) break //因为已经排序了的  超过了的就不需要在判断了，肯定是不相等的，提高效率
        }
        this.showData = arr
      },
      //点击条目 投注事件
      itemClick(v) {
        // 计算赔率
        this.odds = this.calcOdds(v)
        if (!this.odds) {
          this.$Modal.al_default({status: 'warning', content: '该玩法项未开通投注！'})
          return //没有计算到赔率就停止
        }
        //弹框的label
        this.fastBet_label = {
          txt0: v.txt0,
          txt1: v.txt1,
          odds: this.odds,
        }
        this.fastBet_money = 1 //初始化快速盘口投注
        this.modal_Ma = true  //打开弹框
      },
      //计算利率
      calcOdds(v) {
        //这个页面最难的部分就在这里 --去计算赔率
        let methodsName = 'lottery_' + this.currentLottery_officialType;//获取彩种大类  ssc
        // 找到计算的方法  并给参数
        let fn = calcObj[methodsName]()
        let keyStr = fn.getcode(v.txt0 + '@' + v.txt1, typeObj[methodsName].map, [v.txt0, v.txt1]) //投注的时候  这个就是id
        // 如果计算不成功，就提示暂未开通投注
        if (!keyStr || keyStr === '-') {
          this.$Modal.al_default({status: 'warning', content: '该玩法项未开通投注！'})
        } else {
          if (!this.oddsData) {
            this.$Modal.al_default({status: 'warning', content: '该玩法项未开通投注！'})
          } else {
            this.keyStr = keyStr
            return this.oddsData.Lines['j' + keyStr]
          }
        }
        return false
      },
      // 快速盘口投注的点击确定事件
      fastBet() {
        if (!this.fastBet_money) {
          this.$Modal.al_default({status: 'warning', content: '您输入的有误'})
          return
        }
        let obj = {
          gname: this.fastBet_label.txt0,
          BetContext: this.fastBet_label.txt1,
          Lines: this.fastBet_label.odds,
          Money: this.fastBet_money,
          IsForNumber: false,
          IsTeMa: false,
          BetType: 1,
          mingxi_1: 0,
          id: this.keyStr,
        }
        service.post(this, 'xjw-lottery/bet', JSON.stringify({
          betParameters: [obj],
          // lotteryId: this.biggerType==='jd'?this.code:this.currentLottery.id
          lotteryId: this.code
        })).then(function (result) {
          let res = result.data
          if (res.result === 1) {
            this.$Modal.al_default({status: 'success', content: '投注成功！'})
            // 刷新订单组件的数据  通过vuex改变状态  订单组件中会监听这个状态是否发生改变  从而刷新
            this.setData({key: "initStatus_tableRecord", value: !this.initStatus_tableRecord})
          } else {
            this.$Modal.al_default({status: 'warning', content: res.msg ? res.msg : res.message})
          }

        }, function (err) {
          console.log(err)
        })
      },
      init() {
        if (!this.biggerType || !this.currentLottery) return
        // 逻辑  这里有两个接口,需要先获取数据,然后再获取赔率,赔率用于投注时计算
        // 获取出码和遗漏的数据
        this.findData()
      },
    },
    created() {
      this.init()
    },
    mounted() {
    },
  }
</script>

<style lang='less' scoped>
  @import "../../css/global.less";

  .alanRank {
    width: 100%;
    height: 100%;
    .rankTop {
      height: 46px;
      line-height: 46px;
      border-bottom: 1px solid @methodBox_bor;
      > div {
        display: inline-block;
        float: left;
        width: 50%;
      }
      .left {
        .leftBox {
          width: 96px;
          height: 24px;
          margin: 11px auto;
          position: relative;
          border-radius: 14px;
          .bor(@methodBox_bor);
          span {
            display: inline-block;
            width: 50px;
            height: 22px;
            line-height: 22px;
            font-size: 14px;
            color: @twoMenuColor_Sel;
            float: left;
            position: absolute;
            cursor: pointer;
            &.active {
              z-index: 10;
              color: #fff;
              background: @themeColor;
              border-radius: 14px;
              line-height: 22px;
            }
            &:first-child {
              left: 0;
            }
            &:last-child {
              right: 0;
            }
          }
        }

      }
      .right {
        > div {
          width: 100px;
        }
      }
    }
    .rankContent {
      height: calc(~"100% - 46px");
      overflow: auto;
      .al_scorll();
      .rankItem {
        height: 46px;
        line-height: 46px;
        font-size: 14px;
        overflow: hidden;
        cursor: pointer;
        &:hover {
          background: @methodBox_bor;
        }
        > div {
          display: inline-block;
          float: left;
          line-height: 46px;
          text-align: center;
          color: @chooseNumberBoxColor_Lab;
        }
        .txt0 {
          width: 44%;
        }
        .txt1 {
          width: 20%;
          color: @themeColor;
        }
        .issue {
          width: 20%;

        }
        .serial {
          width: 16%;
          em {
            font-size: 16px;
          }
          span {
            display: inline-block;
            width: 34px;
            height: 34px;
            background: url(/static/img/icon_gold_medal.png) no-repeat 7px 8px;
            background-size: 60% 71%;
            color: #333;
          }
        }
        &:nth-child(1) .serial em {
          color: #FFBA00;
        }
        &:nth-child(2) .serial em {
          color: #87A7C3;
        }
        &:nth-child(3) .serial em {
          color: #D4A267;
        }
      }
      .noData {
        margin-top: 150px;
        .picture {
          em {
            color: #888;
            opacity: 0.4;
            font-size: 52px;
          }
        }
        .txt {
          color: #888;
          font-size: 16px;

        }
      }
    }
  }
</style>
