<template>
  <div class="pankou-line-wrapper">
    <div class="nav-menu-box">
      <div class="nav-item" v-for="(item,index) in typeArr" :class="{active:index===currentTypeIndex}"
           @click="currentTypeIndex=index">{{item}}
      </div>
    </div>
    <div class="play-tab luzhu">
      <table class="outer-table">
        <thead>
        <tr>
          <th colspan="10">
            <div class="tab-item-box">
              <a class="tab-item" :class="{active:currentLuzhuIndex===0}" @click="currentLuzhuIndex=0">{{typeArr[currentTypeIndex]}}</a>
              <a class="tab-item" v-for="(item,index) in luzhuArr" :class="{active:index+1===currentLuzhuIndex}"
                 @click="currentLuzhuIndex=index+1">{{item}}</a>
            </div>
          </th>
        </tr>
        </thead>
        <tbody>
        <tr>
          <table>
            <tbody>
            <td v-for="item in lineArr" class="luzhu-td">
              <table>
                <tbody>
                <tr v-for="val in item">
                  <td style="border-left:none;border-right:none" v-if="val"><em class="inball"
                                                                                :class="[{long:val === '龙'},{da:val === '大'},{dan:val === '单'},{he:val==='和'}]">{{val}}</em>
                  </td>
                  <td style="opacity: 0;border-left:none;border-right:none" v-else><em class="inball">1</em></td>
                </tr>
                </tbody>
              </table>
            </td>
            </tbody>
          </table>
        </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  let formatLines = function (data) {
    data = JSON.parse(JSON.stringify(data))
    data.forEach(item => {
      let re = []
      item.c.split(',').forEach(val => {
        let a = val.split(':')
        let b = []
        for (let i = 0; i < a[1]; i++) {
          b.push(a[0])
        }
        re.push(b)
      })
      item.line = re
    })
    return data
  }
  export default {
    props: ['lines', 'ballsNumber'],
    data() {
      return {
        typeArr: ['第一球', '第二球', '第三球', '第四球', '第五球'],
        currentTypeIndex: 0,
        luzhuArr: ['单双', '大小', '总和单双', '总和大小', '龙虎'],
        currentLuzhuIndex: 0
      }
    },
    computed: {
      lineArr() {
        let re = formatLines(this.lines)
        let ix = this.currentLuzhuIndex > 2 ? 0 : this.currentTypeIndex + 1
        let type = this.currentLuzhuIndex === 0 ? this.typeArr[this.currentTypeIndex] : this.luzhuArr[this.currentLuzhuIndex - 1]
        let data = re.filter(item => item.p === ix && item.n === type)
        if (data.length) {
          let a = data[0].line.slice(-30)
          let maxLength = 6
          a.forEach(item => {
            if (item.length > maxLength) {
              maxLength = item.length
            }
          })
          a.forEach(item => {
            if (item.length < maxLength) {
              let num = maxLength - item.length
              for (let i = 0; i < num; i++) {
                item.push('')
              }
            }
          })
          let middle = []
          for (let i = 0; i < maxLength; i++) {
            middle.push('')
          }
          if (a.length < 30) {
            let len = 30 - a.length
            for (let i = 0; i < len; i++) {
              a.push(middle)
            }
          }
          return a
        }
        return []
      },
      ballArr() {
        let key = 'n' + (this.currentTypeIndex + 1)
        return this.ballsNumber[key] ? this.ballsNumber[key] : []
      }
    }
  }
</script>

<style lang="stylus" rel="stylesheet/stylus">
  .pankou-line-wrapper
    font-size: 0
    .nav-menu-box
      background-color: #e8e8e8
      .nav-item
        display: inline-block
        vertical-align: top
        padding: 0 26px
        color: #333333
        line-height: 40px
        font-size: 16px
        cursor: pointer
        position: relative
        &.active
          color: #f53b4a
          background-color: #ffffff
          &:before
            content: ''
            position: absolute
            top: 0
            left: 0
            width: 100%
            height: 3px
            background-color: #f53b4a
    .play-tab
      &.luzhu
        .trend-tag
          background-color: #ceb78d
      .trend-tag
        position: absolute
        height: 105px
        text-align: center
        padding: 30px 10px 0 10px
        width: 40px
        background-color: #d87c7d
        color: #fff
        line-height: 20px
        font-size: 14px
      .outer-table
        height: 105px
        margin-left: 20px
        width: 856px
        margin-bottom: 10px
        > thead th
          padding: 10px 0
          display: block
          width: 727px
          .tab-item-box
            background: #cbcbcb
            border-radius: 4px
            display: inline-block
            vertical-align: top
            overflow: hidden
            border: 1px solid #dddddd
            .tab-item
              display: inline-block
              vertical-align: top
              text-align: center
              color: #333333
              padding: 8px 16px
              margin-right: 0px
              font-size: 14px
              cursor: pointer
              border-right: 1px solid #dddddd
              margin-left: -1px
              &:last-child
                border-right: none
              &.active
                background-color: #f53b4a
                color: #fff
        > tbody
          table
            width: 100%
            tbody
              td
                &.luzhu-td
                  vertical-align: top
                  border: 1px solid rgb(221, 221, 221);
                  padding: 0
                  tbody
                    tr:first-child td
                      border-top: none
                    tr:last-child td
                      border-bottom: none
                font-size: 14px
                padding: 4px
                text-align: center
                border: 1px solid #ddd
                .inball
                  display: inline-block;
                  width: 20px
                  height: 20px
                  background-color: #f53b4a
                  color: #fff
                  line-height: 20px
                  border-radius: 20px;
                  text-align: center
                  &.long
                    background-color: #00b264
                  &.da
                    background-color: #00b264
                  &.dan
                    background-color: #00b264
                  &.he
                    background-color: #2396F7

</style>
