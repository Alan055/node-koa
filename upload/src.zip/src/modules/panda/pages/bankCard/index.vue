<template lang="html">
<div class="view bankCard">

  <div class="c-view-content">

    <!--有数据-->
    <div class="card-list" v-if="isNoList === false">

      <div class="card-item" v-for="(item, key) in list" :key="'bankListKey_' + item.banknumber + key">
        <p class="c-table-row title-row">
          <span class="c-flex-item c-tl title">
            <img class="c-icon icon_e" :src="item.banklogo" alt="">
            {{item.bankname}} 
            <span class="last-bankno">（尾号{{item.banknumber.slice(-4)}}）</span>
          </span>
        </p>
        <!-- <p class="c-table-row number-row">
          <span class="c-flex-item c-tl">
            {{item.banktype | type}}
            <span class="number">****  ****  **** {{item.banknumber.slice(-4)}}</span>
          </span>
        </p> -->
        <div class="line"></div>
        <p class="c-about-product">
            关联金融产品
        </p>
        <div class="c-flex-row detail-row">
          <ul class="c-flex-item c-table-row c-flex-wrap detail-list" :class="{open: item.open}">
            <li class="c-tl detail-item"
                v-for="(subItem,subKey) in item.productVOS"
                :key="'bankListSubItemKey_' + item.banknumber + subKey"
            >
              <img class="c-icon icon_c h-auto icon-bank" :src="subItem.iconurl" alt="">

              {{subItem.productname}}
            </li>
          </ul>
          <div v-if="item.productVOS.length > 3">
            <span class="icon expand"
                  @click="item.open = !item.open"
                  v-sinaAds="adsInfo.bankCard.index.clickBankCardToggle"
            >
              <c-icon type="arrowDown" v-if="!item.open" />
              <c-icon type="arrowUp" v-else />
            </span>
          </div>
        </div>

      </div>

    </div>

    <!--无数据-->
    <div class="card-noList c-absolute" v-show="isNoList === true">

      <div class="card-noList-img c-aspectratio w-180-140">
        <div class="c-aspectratio-content">
          <img style="width: 100px;" src="../../assets/images/message-nodata.png" />
        </div>
      </div>
      <div class="card-noList-text c-tc c-font-l">
        暂未绑定银行卡
      </div>

    </div>

  </div>

</div>
</template>

<script>
import api from '@/services/api'
import helper from '@/utils/helper'
import {Toast} from '@/utils/helper'

export default {
  data() {
    return {
      list: [],
      isNoList: null
    }
  },
  methods: {
    fetchData() {
      api.user.bankCard.list().then(res => {
        if(! helper.isSuccess(res)) return

        this.list = res.data.map(item => {
          item.open = false
          return item
        })

        this.isNoList = this.list.length === 0;

        this.$root.loadingClose();

      })
    }
  },
  beforeRouteEnter (to, from, next) {
   // 导航进入该组件时调用
   // 不！能！获取组件实例 `this`
   // 因为组件实例还没被创建

   next(vm => {
     // 通过 `vm` 访问组件实例
     vm.fetchData()
   })
  },
  filters: {
    type(value) {
      if(value == 1) {
        return '储蓄卡'
      }
      if(value == 2) {
        return '信用卡'
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .h-auto {
    height: initial;
  }
.card-list{
  padding: $gap;
}
.c-aspectratio-content {
    text-align: center;
}
.card-item{
  background: #FFFFFF;
  box-shadow: 0 0 20px 0 rgba(0,0,0,0.1);
  border-radius: 8px;
  margin-bottom: $gap;
  padding: 12px;
  padding-bottom: 0;

  .last-bankno {
    font-size: $fontM;
  }
}

.title-row{
  .title{
    font-size: $fontXXL;
    .c-icon{
      top: 0;
      vertical-align: -12px;
    }
  }
}

.number-row{
  font-size: $fontL;
  margin-top: 23px;
  .number{
    margin-left: 8px;
    letter-spacing: 1px;
  }
}

.line{
  @extend %border-b;
  margin-top: 16px;
}

.c-about-product {
    color: #666;
    margin-top: 10px;

}

.detail-row{
  font-size: $fontS;
  color: $gray;
  margin-top: 18px;
  padding-bottom: 5px;

  .detail-list{
    height: 28px;
    overflow: hidden;
    &.open{
      height: auto;
    }
    .c-icon{
      line-height: 1em;
      position: static;
      vertical-align: text-top;
    }
  }
  .detail-item{
    width: 33.33%;
    margin-bottom: 12px;
    line-height: 1.6;
  }
}

.card-noList {
  top: 40%;
  left: 50%;
  transform: translate(-50%, -50%);
  /*展示图片样式*/
  .card-noList-img {
    width: 180px;
    img {
      width: 100%;
    }
  }
  /*占位符*/
  .w-180-140 {
    aspect-ratio: '180:140';
  }
  /*展示文字样式*/
  .card-noList-text {
    color: #666666;
  }
}

</style>
