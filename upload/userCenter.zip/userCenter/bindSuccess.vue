<template>
    <div class="emailSuccess" >
      <div class="bgSuccess"></div>
      <div class="successText" >绑定成功</div>
      <div class="goDetailBtn" @click="$router.push('/userCenters/userDetail')">自动返回首页{{countdownTime}}s</div>
    </div>
</template>

<script>
import { mapState } from 'vuex';

export default {
    data () {
        return {
          countdownTime:3 // 3秒回首页
        };
    },
    components: {},
    computed:{
      ...mapState(['root_userCenter'])
    },
    methods: {
    },
    created () {
      let _this = this
      let timer = setInterval(function() {
        if(_this.countdownTime === 0) {
            clearInterval(timer);
            _this.countdownTime = 3;
            // _this.isSuccess = false;
            // _this.$router.push({path: _this.root_userCenter + '/userDetail'})// 跳转到前一个页面
        }
        _this.countdownTime--;
      }, 1000);
    }
}

</script>
<style lang="less" scoped>
@import "../../css/userForm.less";
</style>
