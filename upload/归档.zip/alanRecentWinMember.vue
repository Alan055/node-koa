<template>
  <div class="recentWin" @mouseenter="pauseTimer=true" @mouseleave="pauseTimer=false">
    <div class="stable">
      <div v-for="(v,i) in data" :key="i" v-if="data.length>0&&i<3" class="recentWinbox">
        <div class="icon"><img :src="v.img" alt=""></div>
        <div class="content">
          <div class="name">{{v.name}}</div>
          <div class="method">{{v.method}}</div>
        </div>
        <div class="money">{{v.money}}元</div>
        <div class="map">
          <em class="icon_v3" v-if="i<=2">&#xe699;</em>
          <span v-if="i>2">{{i+1}}</span>
        </div>
      </div>
    </div>
    <div class="loop">
      <div v-for="(v,i) in data" :key="i" v-if="data.length>0&&i>=3" class="recentWinbox ">
        <div class="icon"><img :src="v.img" alt=""></div>
        <div class="content">
          <div class="name">{{v.name}}</div>
          <div class="method">{{v.method}}</div>
        </div>
        <div class="money">{{v.money}}元</div>
        <div class="map">
          <em class="icon_v3" v-if="i<=2">&#xe699;</em>
          <span v-if="i>2">{{i+1}}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
	export default {
		data() {
			return {
				data: [
					{img: '/static/img/avatar_default.png', name: 'SDF****JJF', method: '后三复式', money: '1888.88'},// 这里只是看一下效果  初始化的时候  数据会清空的
				],
				dataNumber: 18,// 总共18条数据
				txt: 'abcdefghijklmnopqrstuvwsyz',// 名字的字母选择范围
				nameNumber: [6, 7, 8],// 控制名字的长度 +4个*
				// 玩法池
				methodArr: [
					'后三复式',
					'前三码直选复式',
					'前三码直选和值',
					'前三码组选和值',
					'中三码直选复式',
					'中三码直选和值',
					'中三码组选和值',
					'二星后二直选复式',
					'二星后二直选单式',
					'二星后二直选和值',
					'后三码组三',
					'后三和值尾数',
					'后三组选包胆',
					'五星直选复式',
					'总和大小单双',
					'龙虎和万千',
					'龙虎和千百',
					'趣味好事成双',
					'趣味好事成双',
				],
				// 轮播图定时器
				loopTimer: null,
				// 暂停定时器
				pauseTimer: false,
			}
		},
		computed: {},
		watch: {},
		methods: {
			// 随机数 在x，y之间的整数,不包含y
			random(x, y) {
				!y && (y = 0)
				return Math.floor(Math.random() * (x - y) + y)
			},
			// 随机生成一个名字
			creatName() {
				let num = this.nameNumber[this.random(3)];//拿到名字的长度
				let length = this.txt.length
				let name = ''
				for (let i = 0; i < num; i++) {
					name += this.txt[this.random(length)]
					i == 2 && (name += '****')
				}
				return name
			},
			// 随机生成一个玩法
			creatMethod() {
				let length = this.methodArr.length;
				return this.methodArr[this.random(length)]
			},
			// 随机生成一个金额
			creatMoney() {
				return this.random(200000, 10000) / 100 + ''
			},

			// 轮播操作  --说明一下  前三个不轮播  其他的轮播
			loop() {
				let box = $('.recentWin .loop');// 获取需要轮播的dom元素
				this.loopTimer = setInterval(function () {
					if (!this.pauseTimer) {// 暂停就不走
						let top = parseInt(box.css('top'));
						box.css('top', top - 2)
              if (top <= -550) box.css('top', 390)
					}
				}.bind(this), 40)
			},

			init() {
				this.data = []
				for (let i = 0; i < this.dataNumber; i++) {
					this.data.push({
						img: '/static/img/avatar_default.png',
						name: this.creatName(),
						method: this.creatMethod(),
						money: this.creatMoney()
					})
				}
				this.data.sort(function (a, b) {
					return b.money - a.money
				})
				this.$nextTick(function () {
					this.loop()
				}.bind(this))
			},
		},
		created() {
			this.init()
		},
		mounted() {
		},
		destroyed() {
			this.loopTimer && clearInterval(this.loopTimer)
		}
	}
</script>

<style lang='less' scoped>
  @import "../../css/global.less";

  .recentWin {

    height: 100%;
    width: 100%;
    position: relative;
    overflow: hidden !important;
    .stable {
      z-index: 12;
      position: absolute;
      width: 100%;
      background: #fff;
    }
    .loop {
      z-index: 5;
      position: absolute;
      width: 100%;
      top: 138px;
      background: #fff;
    }
    .recentWinbox {
      /*height: 100%;*/
      width: 100%;
      overflow: hidden;
      > div {
        display: inline-block;
        float: left;
        height: 46px;
        line-height: 34px;
        padding: 6px 0;
      }
      .icon {
        width: 18%;
      }
      .content {
        width: 35%;
        font-size: 12px;
        .name {
          line-height: 17px;
          color: #666;
        }
        .method {
          line-height: 17px;
          color: #333;
        }
      }
      .money {
        width: 30%;
        color: @themeColor;
        font-size: 14px;
      }
      .map {
        width: 17%;
        em {
          font-size: 16px;
        }
        span {
          display: inline-block;
          width: 34px;
          height: 34px;
          background: url(/static/img/icon_gold_medal.png) no-repeat 9px 4px;
          color: #333;
        }
      }
      &:nth-child(1) .map em {
        color: #FFBA00;
      }
      &:nth-child(2) .map em {
        color: #87A7C3;
      }
      &:nth-child(3) .map em {
        color: #D4A267;
      }

    }

  }
</style>