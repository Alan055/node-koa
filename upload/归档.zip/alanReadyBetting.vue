<template>
  <div class="readyBetting">
    <div class="left">
      <!--这里面的表格做成组件-->
      <al_tableReadyBetting :table_content="number_tableData"></al_tableReadyBetting>
    </div>
    <div class="right">
      <div class="rightTop">
        <span v-for="(v,i) in btnArr" :key="i" @click="v.click()" :class="{'noClick':i===0&&number_tableData.length===0}">
          <i class="icon_v3" v-html="v.icon"></i>{{v.text}}
        </span>
      </div>
      <div class="rightBottom" :class="{'noData':number_tableData.length===0}"
           @click="number_tableData.length>0&&determineBet()">
        <div><b><em class="icon_v3">&#xe6ac;</em>确定投注</b></div>
        <div class="time"><em class="icon_v3">&#xe6a6;</em><i class="Countdown">{{timeArr[0]}}</i>:<i>{{timeArr[1]}}</i>:<i>{{timeArr[2]}}</i>
        </div>
      </div>
    </div>

    <!--我要追号的模态框-->
    <Modal class="modal_chaseNumber"
           :mask-closable="false"
           v-model="modal_chaseNumber"
           title="我要追号"
           @on-ok="ok_chaseNumber()"
           width="800px"
           ok-text="确定投注"
           @on-cancel="">
      <div class="bodyHeader">当前销售第<span>{{issue}}</span>期，距离投注截止时间还有<span>{{openTime.split('-').join(':')}}</span>
      </div>
      <div class="nav">
        <span :class="{'active':chase_navIndex===i}" @click="chase_navIndex!==i&&(chase_navIndex=i)"
              v-for="(v,i) in chase_nav" :key="i">
          {{v}}
        </span>
      </div>
      <div class="chase_input">
        <div class="content">
          追号期数：<Input class="input" v-model="chase_issueNum" :maxlength="5"></Input>
          总期数：<span class="text">{{chase_chooseIssueNum}}</span>期,
          总追号金额：<span class="text">{{chase_totalMoney}}</span>元
          <Checkbox class="chase_isStop" v-model="chase_isStop"> 中奖后停止追号</Checkbox>
        </div>
        <div class="content">
          起始倍数：<Input class="input" v-model="chase_multipleStart" :maxlength="5"></Input>
          <!--翻倍追号-->
          <div class="classification" v-if="chase_navIndex===0">
            隔 <Input class="input" v-model="chase_intervalIssue" :maxlength="5"></Input> 期，
            倍 <Input class="input" v-model="chase_multiple" :maxlength="5"></Input>
          </div>

          <!--同倍追号什么都没有-->
          <!--利润率追号-->
          <div class="classification" v-if="chase_navIndex===2">
            最大倍投：<Input class="input" v-model="chase_maxMultipleBet" :maxlength="5"></Input>
            最低收益率：<Input class="input" v-model="chase_minIncomeRate" :maxlength="5"></Input>%
          </div>
        </div>
        <div class="btn">
          <!--按钮-->
          <Button class="chase_btn" type="success"
                  :class="{'noclick':!(Number(chase_issueNum)>=0&&Number(chase_multipleStart)>0&&Number(chase_intervalIssue)>0&&Number(chase_multiple)>0)}"
                  @click="Number(chase_issueNum)>=0&&Number(chase_multipleStart)>0&&Number(chase_intervalIssue)>0&&Number(chase_multiple)>0&&chase_generateTable()">
            生成追号单
          </Button>
        </div>
      </div>
      <div class="chase_table">
        <ul class="top">
          <li v-for="(v,i) in chase_tableTop" :key="i">
            {{v}}
          </li>
        </ul>
        <div class="chase_tableContent">
          <ul v-for="(v,i) in chase_tableContent" :key="i">
            <li>
              <Checkbox @on-change="changeTableCheck(v)" v-model="v.active" :disabled="!chase_canChoose"></Checkbox>
            </li>
            <li>{{v.issue}}</li>
            <li><Input @on-keyup="inputChange(v,i)" :maxlength="5"  :disabled="!v.active" class="multiple"
                       v-model="v.multiple"></Input>
              倍
            </li>
            <li>{{v.money}}</li>
            <li>{{v.stopTime}}</li>
          </ul>
        </div>
      </div>

    </Modal>


  </div>
</template>

<script>
  import {mapState, mapMutations, mapActions} from 'vuex';
  import al_tableReadyBetting from "./../lotteryRefactoring/alanTableReadyBetting.vue";
  import lottery_calc from "./js/lottery_calc.js";//引入彩种计算函数
  import service from "./../../js/service.js";//引入ajax
  import {LZString} from "./../../js/common.js";//引入公共方法
  import lotteryComment from "./js/common.js";//引入投注模块公共方法


  var compressStr = LZString();

  // var maxBounsArr = [100000, 200000, 400000];


  export default {
    components: {al_tableReadyBetting},
    props: ['name', 'issue'],//name是当前彩种大类名字，如重庆时时彩 --在表格中展示时用到   issue是当前开奖的期数
    data() {
      return {
        btnArr: [
          {text: '我要追号', icon: '&#xe65c;', click: this.appendNumer},
          {text: '清空号码', icon: '&#xe6ab;', click: this.clearNumber},
        ],
        timeArr: ['00', '00', '00'],//倒计时展示
        moneyRate: 0,//存一下金额的比率 比如  分就是0.01元   这个后面都会用到的
        //模态框
        modal_chaseNumber: false,//我要追号的模态框

        // // 最高奖金
        // maxBounsObj: {
        // 	pk10: maxBounsArr[1],
        // 	elvenY: maxBounsArr[1],
        // 	dpc: maxBounsArr[0],
        // 	k3: maxBounsArr[1],
        // 	sscs: maxBounsArr[2],
        // 	flb: maxBounsArr[2],
        // },
        maxBouns: 0,//点击投注时弹框的最高限额值

        //我要追号模态框数据
        chase_canChoose: false, // 追号一开始是不能勾选的  只能当生成追号了才能勾选  因为这里有个后台bug，第一期不追，就没办法投注
        chase_nav: ['翻倍追号', '同倍追号', '利润率追号'],  //导航栏  相当于页签
        chase_navIndex: 0,//当前选中的导航栏（页签）
        chase_issueNum: 10,//追号期数  这个就是模态框表格的size
        chase_chooseIssueNum: 0,//模态框中表格选中的期数数量
        chase_totalMoney: 0,//总追号金额
        chase_multipleStart: 1,//起始倍数
        chase_isStop: true,//中奖后是否停止追号
        chase_intervalIssue: 1,//间隔多少期  --翻倍追号里面的
        chase_multiple: 2,//倍数  --翻倍追号里面的
        chase_maxMultipleBet: 100,//最大倍投  --利润率追号
        chase_minIncomeRate: 30,//最低收益率  --利润率追号
        chase_tableTop: ['选择', '期号', '倍数', '金额（元）', '代购截止时间'],//模态框表格头
        chase_tableContent: null,//模态框表格内容
        chase_tableContent_Backup: null,//模态框表格内容备份，即原始数据
      }
    },
    computed: {
      ...mapState([
        'biggerType',//最大的彩种类型  sscs jd flb other elvenY dpc
        'currentLottery',//当前选中的彩种大类  包含中文名字  英文名字  id  三个属性  cqssc 重庆时时彩 11
        'openTime',//openTime  --倒计时
        'currentPlayInfo',//当前玩法的信息，确定投注的时候  可以使用 shortname compress
        'note',//note  --注数
        'chooseNumberData',//chooseNumberData  --选号区的所有数据，这里用于计算出实际投注所展示的选号数据
        'number_tableData',//添加的号码表格数据
        'shortName',//shortName  --当前玩法的缩写名字，这里用于计算出实际投注所展示的选号数据  和chooseNumberData一起作为参数
        'multiple',//选注栏的倍数
        'mode',//选注栏的模式  元角分厘
        'total',//选注栏的总金额
        'bonus',//选注栏的进度条   实际是奖金
        'percent',//选注栏的进度条  百分比
        'lottery_method',//当前玩法的彩种（最小一级 如：name五星直选复式 bonus 2000），用于点击投注的时候展示在表格中  还有我要追号的利润率追号
        // 'lottery_type',//当前玩法的类型 比如   五星直选复式
        // 'lottery_Bonus',//当前玩法的彩种奖金 --用于在点击添加号码的时候  显示金额
        'initStatus',//这个状态用来初始化选号区的数据，当我们点击投注或者预投注的时候   改变这个状态，在选号区监听，然后初始化
        'initStatus_tableRecord',//这个状态用来刷新订单记录组件的表格数据  监听其改变时的状态来刷新表格
        'lotteryConfig', //当前玩法的一些配置值
      ])//倒计时
    },
    methods: {
      ...mapMutations(['setData']),
      ...mapActions(['ajaxBetting']),//立即投注和确认投注的ajax事件
      //!--    公共事件     -->
      //计算当前选中的号码  处理成能发送给后台的格式  "-,-,2,3,4"
      calcNumber() {
        let calc = lottery_calc['lottery_' + this.biggerType]
        return calc().inputFormat(this.shortName, this.chooseNumberData)
      },
      //选号提交（投注  追号  添加号码等）之后，需要刷新选号区的数据
      chooseNumberInit() {
        /*
        * 添加完数据之后，需要将选号区的数据清空
        * 这个用vuex来做，给个状态，在选号区监听，当其状态改变的时候  就清空数据
         */
        this.setData({key: "initStatus", value: !this.initStatus})
      },
      // 刷新一下订单记录表格的数据  --在立即投注 和确认投注的时候有用到
      updataRecordTable() {
        // --这个也是用vuex实现   让一个状态更新   另外一边监听这个状态，如果改变了就刷新
        this.setData({key: "initStatus_tableRecord", value: !this.initStatus_tableRecord})
      },
      //!--  --------     -->


      //确认投注  点击事件
      determineBet() {
        //这里的逻辑是从已选号码的表格里面  将表格的数据发往后台   需要判断表格内容是否为空
        if (this.number_tableData.length === 0) {
          this.$Modal.al_default({status: 'warning', content: '请选择一个玩法'})
        } else {
          let that = this;
          this.$Modal.al_default({
            status: 'confim',
            content: '是否确认投注',
            onOk() {
              let arr = []
              for (let val of that.number_tableData) {
                let betArr = val.chooseNumber.split('|')
                for (let v of betArr) {
                  arr.push({
                    lottery: val.lottery,//彩种大类的英文名字  cqssc
                    issue: that.issue,//期号
                    method: val.shortName,//当前玩法的简写code
                    // content: val.lottery.includes('pl3') ? '-,-,' + v : v,//选号的数据  --排列三的时候要特殊处理
                    content: v,//选号的数据  --排列三的时候要特殊处理
                    model: that.moneyTranslation[val.mode].text,//选中的钱   元角分厘  要转换成拼音
                    multiple: val.multiple,//倍数
                    code: val.bonus,//滑块（进度条）的奖金数
                    compress: val.compress//这个是从当前玩法的对象里面取的
                  })
                }
              }
              that.ajaxBetting({that: that, arr: arr, class:'.lotteryContent .readyBetting .rightBottom'});//发送ajax请求
            }
          })
        }
      },

      //我要追号点击事件
      appendNumer() {
        /*
        * 当选号列表里面有数据的时候  才能追号
        * 追号有一个弹出框，让用户可以操作
         */

        this.number_tableData.length > 0 && this.updataTable()
      },
      //清空号码
      clearNumber() {
        this.setData({key: "number_tableData", value: []})
      },
      //获取倒计时
      findCountDown() {
        this.timeArr = this.openTime.split('-')
      },
      //我要追号模态框 打开模态框的相关事件
      updataTable() {
        //打开弹出框之前，将弹出框里面的数据初始化
        this.updataTable_dataInit()
        //打开弹出框
        this.modal_chaseNumber = true
        //存一下金额的比率 比如  分就是0.01元   这个后面都会用到的
        this.moneyRate = this.moneyTranslation[this.mode].rate
        //请求弹出框里面表格的数据
        let that = this;
        service.post(this, 'game-lottery/static-chase-time', {name: this.currentLottery.code}).then(function (result) {
          let res = result.data
          for (let val of res) {
            val.active = false
            val.multiple = 0
            val.money = (val.multiple * (that.moneyRate)).toFixed(3)
          }
          // 数据先存储起来 以便后面使用
          that.chase_tableContent_Backup = res
          //赋值给表格中显示
          that.chase_tableContent = res.slice(0, that.chase_issueNum) //深复制
        }, function (err) {
          console.log(err)
        })
      },
      //打开弹出框之前，将弹出框里面的数据初始化
      updataTable_dataInit() {
      	this.chase_canChoose = false
        this.chase_navIndex = 0;
        this.chase_issueNum = 10;
        this.chase_chooseIssueNum = 0;
        this.chase_multipleStart = 1;
        this.chase_isStop = true;
        this.chase_intervalIssue = 1;
        this.chase_multiple = 2;
        this.chase_maxMultipleBet = 100;
        this.chase_minIncomeRate = 30;
        this.chase_tableContent_Backup = null;
        this.chase_totalMoney = 0;
      },
      //我要追号模态框 表格中复选框的打开按钮
      changeTableCheck(v) {
        /*
        * 逻辑
        * 关闭时 表格中这行数据的输入框为0  打开时就为1
        * 当其改变状态时，会重新计算总追号期数（chase_chooseIssueNum）  和 总追号金额（chase_totalMoney）
         */
        v.multiple = v.active ? 1 : 0;
        v.money = (v.multiple * this.moneyRate).toFixed(3)
        // 计算
        this.calcTotalIssueMoney()
      },
      //我要追号模态框  计算总追号数和总追号金额
      calcTotalIssueMoney() {
        let totalMoney = 0, totalIssue = 0;
        for (let val of this.chase_tableContent) {
          if (val.active) {
            totalIssue++;
            totalMoney += Number(val.money)
          }
        }
        this.chase_chooseIssueNum = totalIssue
        this.chase_totalMoney = totalMoney.toFixed(3)
      },
      //我要追号的模态框  表格中输入框的改变事件
      inputChange(v) {
        //初始倍数的数据  只能是1-10000的整数
        let num = parseInt(v.multiple)
        if (isNaN(Number(num))) {
          v.multiple = 1
        } else {
          v.multiple = num > 10000 ? 10000 : num < 1 ? 1 : num
        }
        //输入框后面的金额数值跟着改变
        v.money = (this.number_tableData[0].note * v.multiple * this.moneyRate).toFixed(3)
        //上方的总金额  数值也一起改变
        this.calcTotalIssueMoney()
      },
      //我要追号  生成追号单事件
      chase_generateTable() {
        // 模态框表格数据清空
        for (let val of this.chase_tableContent) {
          val.active = false
          val.multiple = 0
          val.money = (val.multiple * (this.moneyRate)).toFixed(3)
        }
        /*
        * 这里是生成追号单的事件
        * 逻辑就是根据不同的三个页签  来获取相关的值 追号期数  起始倍数之类的
        * 根据数值，然后改变表格的数据
         */
        // 先获取追号期数所对应的数据总数量
        let arr = this.chase_tableContent_Backup.slice(0, this.chase_issueNum)  //这个就是深复制了

        //总期数和总追号金额
        this.chase_chooseIssueNum = this.chase_issueNum
        this.chase_totalMoney = 0;//总追号金额初始化
        // 取到页签对应的参数
        let t = this.chase_multipleStart  //原始倍数，然后遍历逐步增加
        let obj = this.number_tableData[0];//拿到选号的数据  只有一条
        if (this.chase_navIndex === 0) {
          //翻倍追号  --每隔多少期 倍数增大
          for (let [v, i] of new Map(arr.map((v, i) => [v, i]))) {
            if (i !== 0 && i % this.chase_intervalIssue === 0) {
              t = t * this.chase_multiple
            }
            v.active = true;
            v.multiple = t;
            v.money = (obj.note * v.multiple * (this.moneyRate)).toFixed(3)
            this.chase_totalMoney += Number(v.money) //总追号金额  累加
          }
        } else if (this.chase_navIndex === 1) {
          //同倍追号 每一期都是相同的倍数
          for (let [v, i] of new Map(arr.map((v, i) => [v, i]))) {
            v.active = true;
            v.multiple = t;
            v.money = (obj.note * v.multiple * (this.moneyRate)).toFixed(3)
            this.chase_totalMoney += Number(v.money) //总追号金额  累加
          }
        } else {
          //利润率追号
          /*
          * 这里说明一下逻辑  --只能有一个订单才可以追号
          * 这里展示情况和同倍追号一直，只是加了一个筛选
          * 即最大倍数和最低收益率的筛选
          * 当超过这个最大倍数或者低于收益率的时候  会被过滤掉
           */
          //先判断是否可以追号 选号表格中数据只能是1条
          if (this.number_tableData.length !== 1) {
            this.$Modal.al_default({status: 'warning', content: '多个订单不支持利润率追号！'})
            return
          }
          //获取当前玩法的最低奖金
          let minBonus = this.lotteryConfig.minBetCode
          let rate = this.moneyTranslation[this.mode].rate//元1 角0.1 分0.01 里0.001
          //传入数据  计算单倍奖金
          let price = this.calcSingleBonus(this.moneyRate, obj.bonus, minBonus)
          if (price.length > 1) {
            this.$Modal.al_default({status: 'warning', content: '该玩法不支持利润率追号！'})
            return
          }
          //计算单倍投注金额 注数*系统单价*当前选中的金钱种类  --元1 角0.1 分0.01 里0.001
          let money = obj.note * this.lotteryConfig.sysUnitMoney * this.moneyRate
          //计算所选种类的倍数
          let result = this.calcMultiple(this.chase_issueNum, this.chase_multipleStart, this.chase_maxMultipleBet, this.chase_minIncomeRate / 100, money, price)
          //渲染数据
          if (result.length > 0) {
            let rate = this.moneyRate
            let totalMoney = 0
            result.forEach(function (v, i) {
              arr[i].active = true
              arr[i].multiple = v.multiple
              arr[i].money = (obj.note * v.multiple * rate).toFixed(3)
              totalMoney += Number(arr[i].money)
            })
            this.chase_totalMoney = totalMoney
          } else {
            this.$Modal.al_default({status: 'warning', content: '没有符合要求的方案，请调整参数重新计算！'})
            return
          }
        }
        //赋值给表格中的数据  展示
        this.chase_tableContent = arr;
        this.chase_totalMoney = this.chase_totalMoney.toFixed(3)//总追号金额保留三位小数
	      this.chase_canChoose = true // 可以任意勾选
      },
      // 我要追号--利润率追号   计算单倍奖金  这个arr>1就不支持利润率   --这个逻辑我也不是很清楚
      calcSingleBonus(rate, bonus, minBonus) {
        // 拿到当前玩法对应的大对象
        let arr = []
        if (this.lottery_method) {
          let ps = this.lottery_method.bonus.split(',')
          for (let val of ps) {
            //这里的追号逻辑不一样，龙腾的追号如下
            let percent = Number(val) / minBonus;
            arr.push(((bonus * percent / Number(val)) * ps * (this.lotteryConfig.sysUnitMoney / 2) * rate).toFixed(3))

            //这里的追号逻辑不一样，头彩的追号如下
            // arr.push(((bonus / Number(val)) * ps * (this.lotteryConfig.sysUnitMoney / 2) * rate).toFixed(3))
          }
        }
        return arr;
      },
      //我要追号--利润率追号  计算所选种类的倍数     --这个逻辑我也不是很清楚
      calcMultiple(count, sMultiple, maxMultiple, minProfit, money, prize) {
        var result = []; // 结果
        var totalMoney = 0;
        var multiple = sMultiple;
        for (var i = 0; i < count; i++) {
          var thisMoney = 0;
          var thisPrize = 0;
          var thisProfit = 0;
          while (true) {
            thisMoney = money * multiple;
            thisPrize = prize * multiple;
            var tempTotal = totalMoney + thisMoney;
            thisProfit = (thisPrize - tempTotal) / tempTotal;
            if (multiple > maxMultiple) return result;
            if (thisProfit >= minProfit) break;
            multiple++;
          }
          totalMoney += thisMoney; // 累计投入
          //alert(multiple + '-' + thisMoney + '-' + totalMoney + '-' + thisPrize);
          result.push({multiple: multiple, thisMoney: thisMoney, thisPrize: thisPrize, thisProfit: thisProfit});
        }
        return result;
      },
      //我要追号  点击确认按钮
      ok_chaseNumber() {
        // 创建一个容器对象  订单的数据   追号的数据  是否中奖后停止追号
        let obj = {orderList: [], planList: [], winStop: this.chase_isStop};
        //整合表格里面的数据
        for (let val of this.number_tableData) {
          if (val.chooseNumber.includes('|')) {
            let arr = val.chooseNumber.split('|')
            for (let v of arr) {
              obj.orderList.push({
                lottery: val.lottery,//彩种大类的英文名字  cqssc
                // issue:this.issue,//期号   ---追号时不需要传这个
                method: val.shortName,//当前玩法的简写code
                content: v,//选号的数据
                model: this.moneyTranslation[val.mode].text,//选中的钱   元角分厘  要转换成拼音
                // multiple:Number(val.multiple),//倍数   ---追号时不需要传这个
                code: val.bonus,//滑块（进度条）的奖金数
                compress: val.compress//这个是从当前玩法的对象里面取的
              })
            }
          } else {
            obj.orderList.push({
              lottery: val.lottery,//彩种大类的英文名字  cqssc
              // issue:this.issue,//期号   ---追号时不需要传这个
              method: val.shortName,//当前玩法的简写code
              content: val.chooseNumber,//选号的数据
              model: this.moneyTranslation[val.mode].text,//选中的钱   元角分厘  要转换成拼音
              // multiple:Number(val.multiple),//倍数   ---追号时不需要传这个
              code: val.bonus,//滑块（进度条）的奖金数
              compress: val.compress//这个是从当前玩法的对象里面取的
            })
          }
        }
        //整合模态框里面的数据
        for (let val of this.chase_tableContent) {
          val.active && obj.planList.push({issue: val.issue, multiple: val.multiple})
        }
        if (obj.planList.length > 0) {
          //发送ajax
          this.ajaxBetting({that: this, arr: obj, url: 'game-lottery/add-chase'})
        } else {
          this.$Modal.al_default({status: 'warning', content: '您还没有选择追号单！'})// 提示还没有选中号码
        }


      },


      init() {
        //获取倒计时
        this.findCountDown()
      }
    },
    created() {

      this.init()
    },
    mounted() {

    },
    watch: {
      openTime() {
        this.init();
      },
    }
  }
</script>

<style lang='less' scoped>
  @import "../../css/global.less";

  .readyBetting {
    height: 230px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    cursor: default;
    position: relative;
    border-radius: 6px;
    padding: 14px 15px 24px 12px;
    overflow: hidden;
    background: #fff;
    .left {
      width: 714px;
      overflow-y: hidden;
      overflow-x: hidden;
      border-top: none;
      float: left;
      position: relative;
      padding: 8px 10px 0 10px;
      box-sizing: border-box;
      &:before {
        width: 713px;
        height: 10px;
        background: #ddd;
        border-radius: 5px;
        content: '';
        position: absolute;
        top: 2px;
        left: 0px;
        z-index: 3;
      }
    }
    .right {
      width: 130px;
      position: absolute;
      right: 15px;
      top: 12px;
      z-index: 9;
      .rightTop {
        overflow: hidden;
        margin-bottom: 20px;
        span {
          float: left;
          display: block;
          width: 100%;
          height: 40px;
          line-height: 40px;
          text-align: center;
          font-size: 14px;
          border-radius: 20px;
          margin-right: 10px;
          cursor: pointer;
          &.noClick{
            cursor: not-allowed;
            background: #ccc !important;
          }
          i {
            margin-right: 5px;
            vertical-align: bottom;
          }
          &:first-child {
            background: @themeColor_Sec;
            color: #fff;
          }
          &:last-child {
            margin-top: 20px;
            background: #EBEBEB;
            color: #666;
            i {
              color: #ADADAD;
            }
          }
        }

      }
      .rightBottom {
        width: 130px;
        background: @themeColor;
        color: #fff;
        height: 60px;
        line-height: 60px;
        border: none;
        clear: both;
        font-size: 24px;
        border-radius: 10px;
        cursor: pointer;
        &.noData {
          cursor: not-allowed;
          background: #ccc;
        }
        > div {
          height: 30px;
          line-height: 36px;
        }

        b {
          font-weight: 400;
          font-size: 14px;
          em {
            font-size: 14px;
            margin-right: 5px;
            vertical-align: bottom;
          }
        }
        .time {
          line-height: 24px;
          color: #FFDE00;
          font-size: 12px;
          em {
            font-size: 12px;
            margin-right: 2px;
          }
        }
      }
    }

  }

  @media screen and (max-width: 1024px) {
    .readyBetting {
      height: 310px;
      width: 100%;
      .left {
        width: 100%;
        .table_ready {
          width: 100%;
        }
      }
      .right {
        top: 220px;
        width: 100%;
        right: 0;
        .rightTop {
          position: absolute;
          width: 100%;
          padding: 10px 114px;
          margin-left: 6px;
          span {
            width: 120px;
            display: inline-block;
            &:last-child {
              margin-top: 0;
              float: right;
            }
          }
        }
        .rightBottom {
          z-index: 30;
          position: absolute;
          left: calc(~"50% - 64px");
        }

      }
    }

  }
</style>
