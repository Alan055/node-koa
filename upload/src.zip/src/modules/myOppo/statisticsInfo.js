// 我的
import about from './about/aboutAds';
import agreements from './agreements/agreementsAds';

export default {
    about,
    agreements
};