<template>
  <!--预投注表格-->
  <div class="table_ready">
    <div class="tableData">
      <ul class="top">
        <li v-for="(v,i) in top_data" :key="i">
          {{v}}
        </li>
      </ul>
      <div class="content">
        <ul v-for="(v,i) in table_content" :key="i" v-if="table_content.length>0">
          <!--<li>{{v.bigType}}</li>-->
          <li :title="'['+v.smallType+']'">[{{v.smallType}}]</li>
          <li :title="v.show_chooseNumber">{{v.show_chooseNumber}}</li>
          <li :title="v.multiple+'倍'">{{v.multiple}}倍</li>
          <li :title="v.mode">{{v.mode}}</li>
          <!--<li>{{v.note}}</li>-->
          <li :title="'¥'+v.total">¥{{v.total}}</li>
          <!--<li>{{v.process}}</li>-->
          <!--<li><span @click="deleteItem(i)" class="icon iconfont">&#xe63b;</span></li>-->
          <li><span @click="deleteItem(i)">删除</span></li>
        </ul>
        <div v-if="table_content.length===0" class="noData">
          <div class="picture"><em class="icon_v3">&#xe6a5;</em></div>
          <div class="txt">暂无数据</div>
        </div>
      </div>
    </div>
    <div class="tableBottom" v-if="stopOpenTime&&historyLotteryInfoFirst">
      第<span class="special">{{issue}}</span>
      期投注截止时间 ：<span class="special">{{stopOpenTime.split(' ')[1]}}</span>
      <span class="text">，总投注数 <span class="special">{{noteTotal}}</span>
        注，共需支付金额 <span class="special">¥{{moneyTotal}}</span> 元</span>
    </div>

  </div>
</template>

<script>
	import {mapState, mapMutations, mapActions} from 'vuex';

	export default {
		props:['table_content'],//table_content是表格内容的数据，deleteItem是删除表格中某一行的点击事件
		data() {
			return {
				//表格头部的数据
				top_data:[
					// '彩种',
          '玩法',
          '号码',
          '倍数',
          '模式',
          // '总注数',
          '投注金额（元）',
          // '奖金/返点',
          '操作'
        ],
        //表格底部的数据
        noteTotal:0,//表格中总共有多少注
        moneyTotal:0,//表格中总共多少钱
      }
		},
		computed: {
      ...mapState(['stopOpenTime','historyLotteryInfoFirst','issue']),
    },
		methods: {
      ...mapMutations(['deleteItem'])
    },
		created() {
		},

		mounted() {
		},
		watch: {
			table_content(){
				let noteT=0
        let moneyT=0
				for(let val of this.table_content){
					noteT+=Number(val.note)
					moneyT+=Number(val.total)
				}
				this.noteTotal=noteT
				this.moneyTotal=moneyT.toFixed(3)
      },
    }
	}
</script>

<style lang='less' scoped>
  @import "../../css/global.less";
  .table_ready{
    width: 693px;
    height: 182px;
    /*box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);*/
    .bor(#E1E1E1);
    z-index: 8;
    position: relative;
    .tableData{
      overflow: hidden;
      height: 148px;
      background-color: #fff;
      padding: 0 10px;
      /*box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);*/
      .top{
        height: 34px;
        border-bottom: 1px solid #E3E3E3;
        line-height: 34px;
        li{
          text-align: center;
          font-size: 14px;
          color: #666;
          font-weight: 500;
          line-height: 34px;
        }
      }
      .content{

        height: calc(~"100% - 35px");
        overflow: auto;
        .al_scorll();
        ul{
          background: rgba(243,69,69,0.1);;
          height: 34px;
          li{
            line-height: 34px;
            height: 34px;
            color: #999;
            font-size: 12px;
            overflow:hidden;
            text-overflow:ellipsis;
            white-space:nowrap;
            &:last-child{
              span{
                cursor: pointer;
                color: @themeColor;
              }
            }
          }
        }
        .noData{
          .picture{
            em{
              color: #888;
              opacity: 0.4;
              font-size: 52px;
            }
          }
          .txt{
            color: #888;
            font-size:16px;
          }
        }
      }
      ul{
        overflow: hidden;
        li{
          float: left;
          height: 21px;
          line-height: 21px;
        }
        li:nth-child(1){width: 20%}
        li:nth-child(2){width: 24%}
        li:nth-child(3){width: 15%}
        li:nth-child(4){width: 13%}
        li:nth-child(5){width: 18%}
        li:nth-child(6){width: 10%}
        li:nth-child(7){width: 14%}
        li:nth-child(8){width: 10%}
        li:nth-child(9){width: 10%;cursor: pointer;
          color: #777876;}
      }

    }
    .tableBottom{
      color: #797979;
      font-size: 12px;
      height: 34px;
      line-height: 34px;
      margin-top: -1px;
      text-align: center;
      /*background: #fff;*/
      /*border-top: 1px solid #ccc;*/
      border-bottom: 1px solid @methodBox_bor;
      user-select: text;
      .special{
        color: @themeColor;
      }
    }
  }
</style>