<template>
  <div class="lhc-choose-area-wrapper">
    <div class="nav-menu-box">
      <div class="top-nav">
        <div class="nav-item" :class="{active:currentType === item.type}" v-for="item in typeArr"
             @click="currentType = item.type;zu(item.title)">{{item.title}}
        </div>
        <div class="nav-item" v-if="switchFn" @click="$router.push({path:'/lottery/#'+switchFn})">官方</div>
        <router-link :to="`/playDetails#${helpId}`" target="_blank" class="help"><i class="icon_v3">&#xe645;</i>玩法说明
        </router-link>
      </div>
      <div class="prompt-infor">
        <i class="icon_v3">&#xe645;</i>
        <p>{{promptInfor}}</p>
      </div>
      <div class="bottom-nav">
        <div :title="item.prompt" :class="{active:currentListNav[currentType] === item.type}"
             @click="setCurrentListType(item.type)"
             v-for="item in listNav">
          {{item.title}}
        </div>
      </div>
    </div>
    <div class="lhc-area">
      <table class="outer-table" :class="value.parentType" v-for="(value) in listData" v-show="isShow(value)">
        <tbody>
        <tr>
          <td class="outer-table-td" v-for="(item,jx) in value.list">
            <table class="inner-table">
              <thead>
              <tr>
                <th>号码</th>
                <th>金额</th>
              </tr>
              </thead>
              <tbody>
              <tr class="common" :class="[`common_${jx}_${ix}`,{kj:des.kj},{active:des.input || des.active}]"
                  v-for="(des,ix) in item">
                <td class="one" :data-code="des.code">
                  <span class="text" v-show="des.text">{{des.text}}</span>
                  <span class="rate"
                        v-if="value.parentType === 'bb' || value.parentType === 'sx' || value.parentType === 'ws' || value.parentType === 'zf'">x{{des.rate}}</span>
                  <span class="ball" :class="[des.color,`${value.parentType}_${index}`]"
                        v-for="(ball,index) in des.type.split(',')">{{ball}}</span>
                  <span class="rate"
                        v-if="value.parentType === 'tm' || value.parentType === 'zm'">x{{des.rate}}</span>
                </td>
                <td class="three">
                  <input maxlength="7" v-model="des.num" v-if="getType(value)" type="text" min="0"/>
                  <i class="icon_v3" :class="{active:des.active}" @click="des.active = !des.active" v-else>{{!des.active
                    ? '&#xe688;' :
                    '&#xe686;'}}</i>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        </tbody>
      </table>
      <div class="rate-box" v-if="currentType === 'bz'">赔率 x{{currentListData.list[0][0].rate}}</div>
    </div>
    <div class="kj-area" v-show="showKjFlag">
      <div class="normal-money" v-show="currentListNav[currentType] !== 'lx'">
        <span>常用金额</span>
        <div class="item" @click="setCurrentNormalMoney(index)" :class="{active:index === currentNormalMoney}"
             v-for="(item,index) in normalMoney">{{item}}
        </div>
      </div>
      <div class="first">
        <div class="item" :class="[getColor(item.word),{active:item.active}]" @click="setCurentKj(item)"
             v-for="item in currenKjList"
             v-show="item.type === 'one'">{{item.word}}
        </div>
      </div>
      <div class="two">
        <div class="item" :class="[getColor(item.word),{active:item.active}]" @click="setCurentKj(item)"
             v-for="item in currenKjList"
             v-show="item.type === 'two'">{{item.word}}
        </div>
      </div>
    </div>
    <div class="submit-reset">
      <div class="left">
        您选择了<span>{{note}}</span>注&nbsp;&nbsp;总金额:<span>{{total}}</span>元
      </div>
      <div class="right">
        <div class="money" v-show="isRadio">金额:<input maxlength="7" v-model="kjMoney" type="text"></div>
        <div class="btn-submit" :class="{'noClick':!canBet}" @click="canBet&&submit()"><i class="icon_v3">&#xe6cc;</i>立即投注
        </div>
        <div class="btn-submit" @click="resetData"><i class="icon_v3">&#xe663;</i>重置</div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import mockData from './js/lhcData'
  import {mapState, mapMutations, mapActions} from 'vuex';
  import {userInit, Prompt, noticeInit} from '../../js/index.js'
  import Combinatorics from 'js-combinatorics'
  import jd_play from './js/jd_play.js'

  let init = userInit();

  let initData = JSON.parse(JSON.stringify(mockData))
  export default {
    props: ['zu'],
    data() {
      return {
        // 玩法集合
        typeArr: [],
        // 数据集合
        listData: [],
        currentType: '', // 当前玩法种类
        lotteryCode: '', // 彩种编码
        lines: [], // 路珠参数
        ballsNumber: {}, // 号码显示次数
        total: 0, // 投注总金额
        note: 0, // 投注总注数
        // maxBouns: 0,// 点击投注时弹框的最高限额值
        data: [], // 投注数据
        switchFn: 0, // 切换官方和经典玩法后的id
        helpId: 5,
        currentLotteryId: 250,
        kjMoney: 1, // 快捷投注的金额
        kjList: [...initData.kjList],
        showKjFlag: false,
        normalMoney: [2, 5, 10], // 常用投注金额
        currentNormalMoney: -1,
        currentListNav: {}, // 当前的子类玩法
      }
    },
    computed: {
      ...mapState([
        'issue', // 当前即将开奖的期号
        'maxBouns', // 点击投注时弹框的最高限额值
        'initStatus_tableRecord'
      ]),
      // 提示信息显示
      promptInfor() {
        let a = this.typeArr.filter(item => item.type === this.currentType)
        if (a.length) {
          a = a[0]
          if (a.prompt) {
            return a.prompt
          } else {
            let key = this.currentListNav[this.currentType]
            return a.list.filter(item => item.type === key)[0].prompt
          }
        }
        return ''
      },
      // 当前显示的子类别
      listNav() {
        let a = this.typeArr.filter(item => item.type === this.currentType)
        a = a.length ? a[0].list : []
        return a
      },
      currentListData() {
        if (this.listData.length) {
          let key = this.currentListNav[this.currentType]
          if (key) {
            let a = this.listData.filter(item => item.parentType === this.currentType && item.listType === key)
            return a[0]
          } else {
            let a = this.listData.filter(item => item.parentType === this.currentType)
            return a[0]
          }
        }
        return []
      },
      // 是否是选择框投注
      isRadio() {
        if ((this.currentType === 'sx' && this.currentListNav[this.currentType] === 'lx') || (this.currentType === 'bz')) {
          return true
        }
        return false
      },
      // 当前快捷输入金额
      currenKjList() {
        this.showKjFlag = false
        if (this.currentType === 'tm' || this.currentType === 'zm') {
          this.showKjFlag = true
          return this.kjList[0]
        }
        if (this.currentType === 'bb') {
          this.showKjFlag = true
          return this.kjList[1]
        }
        if (this.currentType === 'sx') {
          this.showKjFlag = true
          return this.kjList[2]
        }
        if (this.currentType === 'ws') {
          this.showKjFlag = true
          return this.kjList[3]
        }
      },
      // 是否可以投注
      canBet() {
        return this.kjMoney && this.data.betParameters && this.data.betParameters.length > 0
      }
    },
    methods: {
      ...mapMutations(['setData']),
      getColor(flag) {
        if (flag.indexOf('红') > -1) {
          return 'hong'
        }
        if (flag.indexOf('蓝') > -1) {
          return 'lan'
        }
        if (flag.indexOf('绿') > -1) {
          return 'lv'
        }
        return ''
      },
      getHtml(type, current) {
        // k3彩种
        if ((this.helpId === 2) && (type === '两连' || type === '豹子' || type === '对子') && (current !== '任意豹子')) {
          let html = ''
          let arr = current.split(',').map(Number)
          arr.forEach(item => {
            html += `<div class="icon_${item}"></div>`
          })
          return html
        } else {
          let long = this.isLong(current) ? 'long' : ''
          return `<span class="${long}">${current}</span>`
        }
      },
      isShow(val) {
        if (!!val.listType) {
          if ((val.parentType === this.currentType) && (val.listType === this.currentListNav[this.currentType])) {
            return true
          }
          return false
        }
        if (val.parentType === this.currentType) {
          return true
        }
        return false
      },
      isInput(item) {
        item.num = item.num ? String(item.num) : ''
        if (item.num === '') {
          item.input = false
          return false
        }
        let reg = /^[1-9][0-9]*$/
        if (!reg.test(item.num)) {
          let a = item.num.slice(0, -1)
          item.input = reg.test(a)
          item.num = a
          return false
        }
        item.input = true
      },
      setCurentKj(item) {
        this.currentNormalMoney = -1
        this.currenKjList.forEach(item => {
          item.active = false
        })
        item.active = true
        let ids = item.ids
        this.currentListData.list.forEach(item => {
          item.forEach(obj => {
            obj.num = ''
            if (this.currentListNav[this.currentType] === 'lx') {
              if (ids.indexOf(obj.text) > -1) {
                obj.active = true
              } else {
                obj.active = false
              }
            } else {
              if (this.currentType === 'tm' || this.currentType === 'zm') {
                if (ids.indexOf(Number(obj.type)) > -1) {
                  obj.kj = true
                } else {
                  obj.kj = false
                }
              } else {
                if (ids.indexOf(obj.text) > -1) {
                  obj.kj = true
                } else {
                  obj.kj = false
                }
              }
            }
          })
        })
      },
      // 获取彩种id
      getLotteryId() {
        this.switchFn = this.dictionary[1][this.currentLotteryId]
        if (this.currentLotteryId === 0) {
          return false
        }
        this.typeArr = [...initData.typeArr.lhc]
        this.typeArr.forEach(item => {
          if (item.list) {
            this.currentListNav[item.type] = item.list[0].type
          }
        })
        this.lotteryCode = initData.lotteryCode[this.currentLotteryId]
        this.currentType = this.typeArr[0].type
        this.listData = [...initData.lotteryData.lhc]
        this.lotteryCode && this.initGameLottery()
      },
      getType(item) {
        if ((item.parentType === 'sx' && item.listType === 'lx') || (item.parentType === 'bz')) {
          return false
        }
        return true
      },
      // 获取初始化的数据
      initGameLottery() {
        this.$http.post('/yx/u/api/xjw-lottery/init-game-lottery', JSON.stringify({lotteryId: this.lotteryCode}), {
            emulateJSON: true,
            headers: {'Content-Type': 'application/json; charset=UTF-8'}
          }
        ).then((response) => {
          let data = response.body;
          let line = data.Obj.Lines
          this.listData.forEach(item => {
            item.list.forEach(obj => {
              obj.forEach(des => {
                let a = line[des.code].split('|')[0].split('@')
                des.lines = a[0]
                des.rate = a[1]
              })
            })
          })
          this.zu(this.listData[0].title,)
        })
      },
      // 重新设置money
      resetData() {
        this.kjMoney = 1
        this.currentNormalMoney = -1
        this.kjList.forEach(item => {
          item.forEach(obj => {
            obj.active = false
          })
        })
        this.listData.forEach(item => {
          item.list.forEach(obj => {
            obj.forEach(des => {
              des.num = ''
              des.input = false
              des.active = false
              des.kj = false
            })
          })
        })
      },
      // 投注
      submit() {
        // 快捷玩法
        // if (this.isRadio) {
        //   if (Number(this.kjMoney) <= 0 || isNaN(Number(this.kjMoney))) {
        //     this.$Modal.al_default({
        //       status: 'warning',
        //       content: '请输入投注金额',
        //       time: 4000
        //     })
        //     return false
        //   }
        // }
        // if (this.data.betParameters.length === 0) {
        //   this.$Modal.al_default({
        //     status: 'warning',
        //     content: '请至少选择一个投注类型',
        //     time: 4000
        //   })
        //   return false
        // }
        this.$Modal.al_jdbetting({
          title: '快速投注',
          status: 'confim',
          onOk: this.sendImmediatelyBetting,
          data: {
            note: this.note,
            total: this.total,
            list: this.data.betParameters,
          }
        })
      },
      // 点击快捷输入金额
      setCurrentNormalMoney(index) {
        this.currentNormalMoney = index
        this.currentListData.list.forEach(item => {
          item.forEach(obj => {
            if (obj.kj) {
              obj.num = this.normalMoney[this.currentNormalMoney]
            }
          })
        })
      },
      // 发送投注数据让
      sendImmediatelyBetting() {
        this.$http.post('/yx/u/api/xjw-lottery/bet', JSON.stringify(this.data), {
            emulateJSON: true,
            headers: {'Content-Type': 'application/json; charset=utf-8'}
          }
        ).then((response) => {
          let data = response.body;
          if (data.result !== 1) {
            this.$Modal.al_default({
              status: 'warning',
              content: data.message ? data.message : data.msg,
              time: 4000
            })
          } else {
            this.resetData()
            this.$Modal.al_default({
              status: 'success',
              content: '投注成功',
              time: 4000
            })
            this.setData({key: "initStatus_tableRecord", value: !this.initStatus_tableRecord})
            // 刷新用户金额
            init.initlotteryBalance(this)
          }
        })
      },
      // 改变子类的栏目item
      setCurrentListType(type) {
        this.currentListNav = Object.assign({}, this.currentListNav, {
          [this.currentType]: type
        })
      },
      getTotalInfor() {
        let val = this.currentListData
        let a = 0
        let b = 0
        let data = {
          betParameters: [],
          lotteryId: this.lotteryCode
        }
        let middle = {
          BetContext: '',
          BetType: 1,
          IsForNumber: false,
          IsTeMa: false,
          Lines: '',
          Money: '',
          gname: '',
          id: '',
          rate: '',
          mingxi_1: 0
        }
        let gname = ''
        switch (val.parentType) {
          case 'tm':
          case 'bb':
          case 'ws':
          case 'zf':
            gname = this.typeArr.filter(item => item.type === val.parentType)[0].title
            break
          default:
            gname = this.listNav.filter(item => item.type === val.listType)[0].title
        }
        if (val.parentType === 'bz' || (val.parentType === 'sx' && val.listType === 'lx')) {
          let c = []
          let d = 0
          switch (val.listType) {
            case 'wbz':
              d = 5
              break
            case 'lx':
            case 'lbz':
              d = 6
              break
            case 'qbz':
              d = 7
              break
            case 'bbz':
              d = 8
              break
            case 'jbz':
              d = 9
              break
            case 'sbz':
              d = 10
              break
          }
          val.list.forEach(item => {
            item.forEach(obj => {
              // 按钮点击
              if (obj.active) {
                c.push(obj.text ? obj.text : obj.type)
                middle.Lines = obj.lines
                middle.id = Number(obj.code.slice(1))
                middle.rate = obj.rate
              }
            })
          })
          if (c.length >= d) {
            b = Combinatorics.combination(c, d).length
            data.betParameters.push(Object.assign({}, middle, {
              BetContext: c.join(','),
              gname: gname,
              Money: this.kjMoney,
            }))
          }
          this.note = b
          this.total = this.kjMoney * b
          this.data = data
          return false
        }
        // 除开选择框的那些
        val.list.forEach(item => {
          item.forEach(obj => {
            this.isInput(obj)
            if (Number(obj.num)) {
              let BetContext = obj.text ? obj.text : obj.type
              let g = gname
              if (val.parentType === 'sx' || val.parentType === 'zf') {
                BetContext = gname + BetContext
                g = BetContext
              }
              if (val.parentType === 'ws') {
                BetContext = BetContext.slice(0, -1)
                g += BetContext
              }
              data.betParameters.push(Object.assign({}, middle, {
                BetContext: BetContext,
                Lines: obj.lines,
                gname: g,
                Money: obj.num,
                id: Number(obj.code.slice(1)),
                rate: obj.rate
              }))
              a += Number(obj.num)
              b++
            }
          })
        })
        this.total = a
        this.note = b
        this.data = data
      }
    },
    created() {
      this.getLotteryId()
    },
    mounted() {
    },
    watch: {
      '$route'(val) {
        this.resetData()
      },
      currentListData: {
        deep: true,
        handler(val) {
          this.getTotalInfor()
        }
      },
      kjMoney(val, last) {
        if (val !== '') {
          let reg = /^[1-9][0-9]*$/
          if (!reg.test(val)) {
            this.kjMoney = last
          }
        } else {
          this.kjMoney = 1
        }
        this.getTotalInfor()
      }
    }
  }
</script>

<style lang="less">
  .lhc-choose-area-wrapper {
    font-size: 0;
    line-height: 1;
    text-align: left;
    background-color: #fff;
    user-select: none;
    .nav-menu-box {
      line-height: 1;
      position: relative;
      background-color: #fff;
      .top-nav {
        background: rgba(243, 226, 227, 1);
        .nav-item {
          display: inline-block;
          vertical-align: top;
          line-height: 40px;
          padding: 0 27px;
          font-size: 14px;
          color: #555555;
          position: relative;
          cursor: pointer;
          &.active {
            color: #f53b4a;
            font-weight: bold;
            font-size: 16px;
            background: #fff;
            &:before {
              content: '';
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              height: 2px;
              background: rgba(231, 69, 82, 1);
            }
          }
        }
        .help {
          position: absolute;
          right: 22px;
          top: 0;
          line-height: 40px;
          font-size: 14px;
          color: #333333;
          i {
            vertical-align: middle;
            color: #ff6a76;
            margin-right: 2px;
            position: relative;
            top: -1px;
          }
        }
      }
      .prompt-infor {
        display: flex;
        padding: 10px 26px 10px 0;
        border-bottom: solid 1px #e6e6e6;
        .icon_v3 {
          color: #ff6a76;
          display: inline-block;
          margin: 0 8px 0 10px;
        }
        p {
          font-size: 12px;
          line-height: 1.5;
          color: #666666;
        }
      }
      .bottom-nav {
        padding-bottom: 6px;
        > div {
          display: inline-block;
          vertical-align: top;
          padding: 0 15px;
          height: 24px;
          font-size: 12px;
          color: #666;
          line-height: 24px;
          border-radius: 4px;
          background-color: #f0f0f0;
          margin-left: 7px;
          cursor: pointer;
          margin-top: 8px;
          &.active {
            color: #fff;
            background: #f53b4a;
          }
        }
      }
    }
    .lhc-area {
      line-height: 1;
      margin: 0px 12px 0 12px;
      table {
        border-collapse: collapse;
        border-spacing: 0;
        empty-cells: show;
        width: 100%;
        background: transparent;
        text-align: center;
        th {
          line-height: 30px;
          font-size: 14px;
          color: #fff;
          text-align: center;
          background-color: #f53b4a;
          &:first-child {
            border-right: 1px solid #fff;
          }
        }
      }
      .outer-table {
        &.zf {
          .outer-table-td .inner-table tr.common td.one {
            text-align: left;
          }
          .inner-table tr.common td.one .ball {
            background: transparent !important;
            color: #2c3e50 !important;
            font-weight: normal !important;
          }
        }
        &.bb, &.sx, &.ws, &.zf {
          .outer-table-td {
            width: 50%;
            .inner-table tr.common td.one {
              text-align: left;
              padding-left: 10px;
            }
          }
        }
        &.tm, &.zm {
          .outer-table-td:nth-child(5n+4) {
            .common.common_3_9 .three {
              position: relative;
              &:before {
                content: '';
                position: absolute;
                right: -7px;
                top: 0;
                width: 6px;
                height: calc(100% + (2px));
                background-color: #fff;
              }
            }
          }
        }
        &.bb {
          .text {
            width: 3em;
            display: inline-block;
          }
          .rate {
            width: 4em;
            display: inline-block;
          }
        }
        &.sx {
          .text {
            width: 1em;
            display: inline-block;
          }
          .rate {
            width: 4em;
            display: inline-block;
          }
        }
        &.zf {
          .text {
            width: 2em;
            display: inline-block;
          }
          .rate {
            width: 3em;
            display: inline-block;
          }
        }
        &.ws {
          .text {
            width: 2em;
            display: inline-block;
          }
          .rate {
            width: 4em;
            display: inline-block;
          }
        }

        > tbody > tr, > thead > tr, > thead > tr th {
          display: block;
          width: 100%;
        }
        .outer-table-td {
          padding: 0 3px;
          margin-top: 6px;
          vertical-align: top;
          display: inline-block;
          min-width: 20%;
          background: #e5e5e5;
          &:first-child {
            padding-left: 0;
          }
          &:last-child {
            padding-right: 0;
          }
          &.full {
            width: 100%;
            td.top {
              vertical-align: top;
            }
          }
          &.k3-dd-bz-dz, &.lhd-o-t-f, &.nn-m, &.sh-o {
            width: 25%;
          }
          .inner-table {
            background-color: #E6E6E6;
            tr {
              &.title {
                background: #e6e6e6;
                td {
                  line-height: 30px;
                  font-size: 13px;
                  color: rgba(102, 102, 102, 1);
                  border: 1px solid #F5F5F5;
                }
              }
              &.common {
                background: #fff;
                &.kj {
                  background-color: #ffa6ad !important;
                }
                &.common_0_0 {
                  td.one .ball {
                    &.sx_0 {
                      background-color: #00b164;
                    }
                    &.sx_1 {
                      background-color: #f53b4a;
                    }
                    &.sx_2 {
                      background-color: #f53b4a;
                    }
                    &.sx_3 {
                      background-color: #128beb;
                    }
                    &.ws_0 {
                      background-color: #128beb;
                    }
                    &.ws_1 {
                      background-color: #128beb;
                    }
                    &.ws_2 {
                      background-color: #f53b4a;
                    }
                    &.ws_3 {
                      background-color: #f53b4a;
                    }
                  }
                }
                &.common_0_1 {
                  td.one .ball {
                    &.sx_0 {
                      background-color: #128beb;
                    }
                    &.sx_1 {
                      background-color: #00b164;
                    }
                    &.sx_2 {
                      background-color: #f53b4a;
                    }
                    &.sx_3 {
                      background-color: #f53b4a;
                    }
                    &.ws_0 {
                      background-color: #f53b4a;
                    }
                    &.ws_1 {
                      background-color: #00b164;
                    }
                    &.ws_2 {
                      background-color: #00b164;
                    }
                    &.ws_3 {
                      background-color: #128beb;
                    }
                    &.ws_4 {
                      background-color: #128beb;
                    }
                  }
                }
                &.common_0_2 {
                  td.one .ball {
                    &.sx_0 {
                      background-color: #128beb;
                    }
                    &.sx_1 {
                      background-color: #00b164;
                    }
                    &.sx_2 {
                      background-color: #00b164;
                    }
                    &.sx_3 {
                      background-color: #f53b4a;
                    }
                    &.ws_0 {
                      background-color: #f53b4a;
                    }
                    &.ws_1 {
                      background-color: #f53b4a;
                    }
                    &.ws_2 {
                      background-color: #00b164;
                    }
                    &.ws_3 {
                      background-color: #00b164;
                    }
                    &.ws_4 {
                      background-color: #128beb;
                    }
                  }
                }
                &.common_0_3 {
                  td.one .ball {
                    &.sx_0 {
                      background-color: #f53b4a;
                    }
                    &.sx_1 {
                      background-color: #128beb;
                    }
                    &.sx_2 {
                      background-color: #00b164;
                    }
                    &.sx_3 {
                      background-color: #00b164;
                    }
                    &.ws_0 {
                      background-color: #128beb;
                    }
                    &.ws_1 {
                      background-color: #f53b4a;
                    }
                    &.ws_2 {
                      background-color: #f53b4a;
                    }
                    &.ws_3 {
                      background-color: #00b164;
                    }
                    &.ws_4 {
                      background-color: #00b164;
                    }
                  }
                }
                &.common_0_4 {
                  td.one .ball {
                    &.sx_0 {
                      background-color: #f53b4a;
                    }
                    &.sx_1 {
                      background-color: #f53b4a;
                    }
                    &.sx_2 {
                      background-color: #128beb;
                    }
                    &.sx_3 {
                      background-color: #00b164;
                    }
                    &.ws_0 {
                      background-color: #128beb;
                    }
                    &.ws_1 {
                      background-color: #128beb;
                    }
                    &.ws_2 {
                      background-color: #f53b4a;
                    }
                    &.ws_3 {
                      background-color: #f53b4a;
                    }
                    &.ws_4 {
                      background-color: #00b164;
                    }
                  }
                }
                &.common_0_5 {
                  td.one .ball {
                    &.sx_0 {
                      background-color: #00b164;
                    }
                    &.sx_1 {
                      background-color: #f53b4a;
                    }
                    &.sx_2 {
                      background-color: #f53b4a;
                    }
                    &.sx_3 {
                      background-color: #128beb;
                    }
                  }
                }
                &.common_1_0 {
                  td.one .ball {
                    &.sx_0 {
                      background-color: #00b164;
                    }
                    &.sx_1 {
                      background-color: #00b164;
                    }
                    &.sx_2 {
                      background-color: #f53b4a;
                    }
                    &.sx_3 {
                      background-color: #128beb;
                    }
                    &.ws_0 {
                      background-color: #00b164;
                    }
                    &.ws_1 {
                      background-color: #128beb;
                    }
                    &.ws_2 {
                      background-color: #128beb;
                    }
                    &.ws_3 {
                      background-color: #f53b4a;
                    }
                    &.ws_4 {
                      background-color: #f53b4a;
                    }
                  }
                }
                &.common_1_1 {
                  td.one .ball {
                    &.sx_0 {
                      background-color: #128beb;
                    }
                    &.sx_1 {
                      background-color: #00b164;
                    }
                    &.sx_2 {
                      background-color: #00b164;
                    }
                    &.sx_3 {
                      background-color: #f53b4a;
                    }
                    &.ws_0 {
                      background-color: #00b164;
                    }
                    &.ws_1 {
                      background-color: #00b164;
                    }
                    &.ws_2 {
                      background-color: #128beb;
                    }
                    &.ws_3 {
                      background-color: #128beb;
                    }
                    &.ws_4 {
                      background-color: #f53b4a;
                    }
                  }
                }
                &.common_1_2 {
                  td.one .ball {
                    &.sx_0 {
                      background-color: #128beb;
                    }
                    &.sx_1 {
                      background-color: #128beb;
                    }
                    &.sx_2 {
                      background-color: #00b164;
                    }
                    &.sx_3 {
                      background-color: #00b164;
                    }
                    &.ws_0 {
                      background-color: #f53b4a;
                    }
                    &.ws_1 {
                      background-color: #00b164;
                    }
                    &.ws_2 {
                      background-color: #00b164;
                    }
                    &.ws_3 {
                      background-color: #128beb;
                    }
                    &.ws_4 {
                      background-color: #128beb;
                    }
                  }
                }
                &.common_1_3 {
                  td.one .ball {
                    &.sx_0 {
                      background-color: #f53b4a;
                    }
                    &.sx_1 {
                      background-color: #128beb;
                    }
                    &.sx_2 {
                      background-color: #128beb;
                    }
                    &.sx_3 {
                      background-color: #00b164;
                    }
                    &.ws_0 {
                      background-color: #f53b4a;
                    }
                    &.ws_1 {
                      background-color: #f53b4a;
                    }
                    &.ws_2 {
                      background-color: #00b164;
                    }
                    &.ws_3 {
                      background-color: #00b164;
                    }
                    &.ws_4 {
                      background-color: #128beb;
                    }
                  }
                }
                &.common_1_4 {
                  td.one .ball {
                    &.sx_0 {
                      background-color: #f53b4a;
                    }
                    &.sx_1 {
                      background-color: #f53b4a;
                    }
                    &.sx_2 {
                      background-color: #128beb;
                    }
                    &.sx_3 {
                      background-color: #128beb;
                    }
                    &.sx_4 {
                      background-color: #00b164;
                    }
                    &.ws_0 {
                      background-color: #128beb;
                    }
                    &.ws_1 {
                      background-color: #f53b4a;
                    }
                    &.ws_2 {
                      background-color: #f53b4a;
                    }
                    &.ws_3 {
                      background-color: #00b164;
                    }
                    &.ws_4 {
                      background-color: #00b164;
                    }
                  }
                }
                &.common_1_5 {
                  td.one .ball {
                    &.sx_0 {
                      background-color: #f53b4a;
                    }
                    &.sx_1 {
                      background-color: #f53b4a;
                    }
                    &.sx_2 {
                      background-color: #128beb;
                    }
                    &.sx_3 {
                      background-color: #128beb;
                    }
                  }
                }
                &.active {
                  background-color: #ffd3d7;
                  &.normal {
                    background-color: #ffa5ac;
                    input {
                      border-color: #fff;
                    }
                  }
                }
                td {
                  height: 40px;
                  border: 1px solid #F5F5F5;
                  &.one {
                    .text {
                      font-size: 12px;
                      margin-left: 2px;
                      display: inline-block;
                      text-align: left;
                    }
                    .rate {
                      font-size: 12px;
                      margin: 0 4px;
                      display: inline-block;
                      text-align: left;
                    }
                    .ball {
                      margin-left: 2px;
                      box-sizing: border-box;
                      display: inline-block;
                      font-size: 12px;
                      height: 20px;
                      min-width: 20px;
                      background-color: #f53b4a;
                      line-height: 20px;
                      border-radius: 50%;
                      text-align: center;
                      color: #fff;
                      font-weight: bold;
                      &.blue {
                        background-color: #128beb;
                      }
                      &.green {
                        background-color: #00b164;
                      }
                    }
                  }
                  &.two {
                    font-size: 12px;
                    font-weight: bold;
                    color: rgba(51, 51, 51, 1);
                  }
                  &.three {
                    input {
                      width: 74px;
                      height: 20px;
                      background: #fff;
                      border: solid 1px #d0d0d0;
                      border-radius: 2px;
                      outline: none;
                      font-size: 12px;
                      padding: 0 5px;
                      &:focus {
                        background: rgba(255, 241, 241, 1);
                        border-color: #F53B4A;
                      }
                    }
                    .icon_v3 {
                      font-size: 18px;
                      color: #d0d0d0;
                      &.active {
                        color: #f53b4a;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      .rate-box {
        font-size: 12px;
        color: #666666;
        margin: 11px 0 14px 0;
      }
    }
    .kj-area {
      .normal-money {
        border-bottom: solid 1px #e6e6e6;
        line-height: 23px;
        padding: 10px 0 10px 15px;
        span {
          vertical-align: middle;
          font-size: 14px;
        }
        .item {
          font-size: 14px;
          display: inline-block;
          vertical-align: middle;
          width: 30px;
          height: 23px;
          background-color: #e5e5e5;
          text-align: center;
          border-radius: 3px;
          color: #333;
          margin-left: 5px;
          cursor: pointer;
          &.active {
            background-color: #f53b4a;
            color: #fff;
          }
        }
      }
      .first {
        line-height: 35px;
        padding: 0 15px;
        border-bottom: solid 1px #e6e6e6;
        .item {
          display: inline-block;
          vertical-align: top;
          font-size: 14px;
          color: #333333;
          position: relative;
          padding-left: 18px;
          margin-right: 10px;
          cursor: pointer;
          &.hong {
            color: #f53b4a;
          }
          &.lan {
            color: #2396f7;
          }
          &.lv {
            color: #00b164;
          }
          &.active {
            &:before {
              background-color: #f53b4a;
            }
          }
          &:before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            margin-top: -6px;
            cursor: pointer;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background-color: #e5e5e5;
          }
        }
      }
      .two {
        padding: 0 15px;
        border-bottom: solid 1px #e6e6e6;
        line-height: 50px;
        .item {
          display: inline-block;
          vertical-align: middle;
          font-size: 16px;
          line-height: 34px;
          color: #333333;
          position: relative;
          padding: 0 10px;
          margin-right: 6px;
          cursor: pointer;
          border: 1px solid #dddddd;
          background-color: #f2f2f2;
          border-radius: 10px;
          &.active {
            background-color: #f53b4a;
            border-color: #f53b4a;
            color: #fff;
          }
        }
      }
    }
    .submit-reset {
      overflow: hidden;
      padding: 12px 12px 12px 15px;
      .left {
        font-size: 14px;
        color: #666666;
        line-height: 40px;
        display: inline-block;
        span {
          color: #f53b4a;
        }
      }
      .right {
        height: 40px;
        float: right;
        .money {

          display: inline-block;
          vertical-align: middle;
          font-size: 14px;
          input {
            vertical-align: middle;
            width: 80px;
            height: 30px;
            background: #fff1f1;
            border-radius: 4px;
            outline: none;
            font-size: 12px;
            border: 1px solid #F53B4A;
            padding: 0 5px;
            margin-left: 4px;
          }
        }
        .btn-submit {
          display: inline-block;
          vertical-align: middle;
          font-size: 14px;
          color: #fff;
          background-color: #f53b4a;
          width: 130px;
          height: 40px;
          border: solid 1px #f53b4a;
          line-height: 38px;
          text-align: center;
          border-radius: 40px;
          cursor: pointer;
          margin-left: 12px;
          &.noClick {
            cursor: not-allowed;
            background: #ccc !important;
            border: none;
          }
          i {
            font-size: 20px;
            vertical-align: middle;
            margin-right: 2px;
            display: inline-block;
            position: relative;
          }
          &:last-child {
            background-color: #ececec;
            border-color: #ddd;
            color: #666666;
            i {
              color: #bababa;
              font-size: 18px;
              top: -1px;
            }
          }
        }
      }
    }
  }

  @media screen and (max-width: 1024px) {
    .lhc-choose-area-wrapper .nav-menu-box .top-nav .nav-item {
      padding: 0 18px;
    }
  }
</style>
