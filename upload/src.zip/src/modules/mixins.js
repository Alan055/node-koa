import Vue from 'vue'
import util from '@/utils'
import AppBridge from "@/services/AppBridge.js"
import api from "@/services/api";

let defaultAppName = '大王贷款';

//app 整体全局变量
window.sinaif_global = {
    appName: ''
};

Vue.mixin({
    data() {
        return {
            appName: ''
        }
    },
    beforeCreate() {
        let self = this;
        if (!!util.getParams("appVersion")) {
            if (window.isGetAppName) return;
            AppBridge.getInitData({}, res => {
                if (res.code == '200' && res.data && res.data.config && typeof res.data.config.app_name != 'undefined') {
                    this.appName = res.data.config.app_name;
                    window.sinaif_global.appName = res.data.config.app_name;
                    document.title = res.data.config.app_name;
                } else {
                    this.appName = defaultAppName;
                    window.sinaif_global.appName = defaultAppName;
                    //document.title = defaultAppName;
                }

                window.isGetAppName = this.appName;
                //console.log('this.appName', this.appName)
            })
        } else {
            setTimeout(() => {
                this.appName = defaultAppName;
                window.sinaif_global.appName = defaultAppName;
                //document.title = defaultAppName
            }, 0);
        }
    },

    methods: {

        /**
         * 导流前置操作-联合登录
         * @param url 请求接口
         * @returns {function(*=, *=): *}
         * @constructor
         */
        //分流前置操作
        beforeDriver(url) {

            if (!url) return
            // http://api.sinawallent.com/app/sys/unionLoginRz?params={"loginProduct":"2001",channelId:"king2001"}

            api.emptyRequest(url,{method: 'get',})({}).then(res=>{

            }).catch(e=>{
                console.error('接口请求异常',url);
            })
        },

    }

})
