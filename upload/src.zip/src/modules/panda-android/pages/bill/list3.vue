<template lang="html">
    <div class="view bill-detail-page">
        <div class="c-view-content" v-min-height>
            <div class="bill-header-content">
                <div class="top">
                    <span class="c-flex-item c-tl title">
                        <img class="c-icon" :src="firstData.iconurl" alt="">
                        <em>{{billList[0].productname}}</em>
                    </span>
                </div>
                <div class="bottom c-flex-row">
                    <div class="c-col-33">
                        <p class="title">应还金额（元）</p>
                        <p class="value">{{loanMoney}}</p>
                    </div>
                    <div class="c-col-33">
                        <p class="title">还款日期</p>
                        <p class="value">{{firstData.loanDay}}</p>
                    </div>
                    <div class="c-col-33">
                        <p class="title">借款期限(期)</p>
                        <p class="value">{{billList.length}}</p>
                    </div>
                </div>
            </div>
            <div class="bill-plan">
                <div class="list">
                    <div :class="['list-item', item.isClear ? 'clear':'']" v-for="(item, i) in billList" :key="i" @click="handleListClick(item)">
                        <div class="list-row">
                            <div class="left-title">第{{item.period}}期</div>
                            <div class="right-title">
                                <span class="status0" v-if="item.status == 0">未开始</span>
                                <span class="status1" v-if="item.status == 1">待还款</span>
                                <span class="status2" v-if="item.status == 2">已结清</span>
                                <span class="status3" v-if="item.status == 3">已逾期
                                    <!-- {{computedDueDay(item)}}天 -->
                                </span>
                                <span class="status4" v-if="item.status == 4">逾期已结清</span>
                            </div>
                        </div>
                        <div class="list-row c-flex-row">
                            <span class="c-col-50 c-tl count">
                                <p class="sub-title">应还金额</p>
                                <p class="sub-content">{{item.dueamount}}</p>
                            </span>

                            <span class="c-col-50 c-tr date-row">
                                <p class="sub-title">应还日期</p>
                                <p class="sub-content">{{item.paydate}}</p>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bill-plan-space"></div>
        </div>

        <div class="footer-plan" v-if="footerPlan" v-html="footerPlan"></div>

        <Popup :value="isPopupShow">
            <div class="bill-detail-dialog" slot="content">
                <div class="dialog-title">
                    <span>第{{detailData.period}}期账单详情</span>
                    <span class="close" @click="isPopupShow = !isPopupShow"></span>
                </div>
                <div class="dialog-content">
                    <span class="dialog-cricle cricle-left"></span>
                    <span class="dialog-cricle cricle-right"></span>
                    <div class="dialog-sub-title">
                        应还款金额（元）
                    </div>
                    <div class="dialog-loan-money">
                        {{detailData.repayAmount}}
                    </div>
                    <div class="dialog-list">
                        <div class="dialog-list-item" v-for="(item, i) in detailData.billItemVOList" :key="i" v-if="item.amount > 0">
                            <div class="left-title">{{item.desc}}</div>
                            <div class="right-content">{{item.amount}}</div>
                        </div>
                    </div>
                    <div class="dialog-list" v-if="detailData.billProgressList && detailData.billProgressList.length > 0">
                        <div class="dialog-list-item">
                            <div class="left-title">还款时间</div>
                            <div class="right-content">{{detailData.billProgressList[0].createtime}}</div>
                        </div>
                        <div class="dialog-list-item">
                            <div class="left-title">还款账户</div>
                            <div class="right-content">{{detailData.cardBank}}(尾号{{detailData.cardNoLast4}})</div>
                        </div>
                    </div>
                </div>

            </div>
        </Popup>
    </div>
</template>

<script>
    import PageControl from "@/utils/PageControl";
    import api from '@/services/api';
    import helper from '@/utils/helper';
    import util from "@/utils";
    ;
    import Popup from '@/components/view/popup';
    import { Toast, Indicator } from "@/utils/helper";

    export default {
        data() {
            return {
                routeParams: {},
                billList: [],
                billUnClearedList: [],
                billClearedList: [],
                loanMoney: '',
                currentDay: moment(),
                firstData: {
                    status: '',
                    dueDay: '',
                    loanDay: '',
                    productname: '',
                    iconurl: ''
                },
                isPopupShow: false,
                detailData: {
                    period: '',
                    repayAmount: '',
                    billItemVOList: [],
                    billProgressList: []
                },
                footerPlan: ''
            }
        },
        computed: {
            computedDueDay(item) {
                return (item) => {
                    return this.currentDay.diff(moment(item.paydate), 'day')
                }
            }
        },
        components: {
            Popup,
        },
        methods: {
            gotoAgreements() {

                this.sinaAds.click(this.adsInfo.bill.list.clickLoanList);

                this.$root.nextTitle = '借款协议';

                if (this.$root.isApp) {

                    let path = location.href.split('/pages')[0];

                    let url = path + `/pages/my/#/agreements/loanList/${this.routeParams.productid}/${this.routeParams.orderid}`;
                    this.$AppBridge.getInitData(res => {
                        if (res && res.data.pageaddress) {
                            let agreement = res.data.pageaddress.filter((item) => {
                                return item.type == 'LOAN_AGREEMENT'
                            })
                            if (agreement.length > 0 && agreement[0].url != '') {
                                url = agreement[0].url + '/' + this.routeParams.productid + '/' + this.routeParams.orderid;
                            }
                        }
                    })
                    this.$root.openUrl({
                        url: url,
                        title: '借款协议'
                    });

                } else {

                    this.$router.push({
                        path: `/agreements/loanList/${this.routeParams.productid}`
                    })

                }

            },
            getBillList1() {
                return new Promise((resolve, reject) => {
                    api.user.bill.list({
                        pageIndex: '1',
                        pageSize: '99',
                        type: '1',
                        billid: this.routeParams.id

                    }).then(res => {
                        if (!helper.isSuccess(res)) {
                            Toast(res.msg)
                            return
                        }

                        if (res.data && res.data.billUnClearedList) {
                            this.billUnClearedList = res.data.billUnClearedList;
                        }else {
                            this.allLoadeda = true;
                            this.nomoreShowa = true;
                        }

                        resolve(res)
                    })
                })
            },
            //结清账单
            getBillList2() {
                return new Promise((resolve, reject) => {
                    api.user.bill.list({
                        pageIndex: '1',
                        pageSize: '99',
                        type: '2',
                        billid: this.routeParams.id

                    }).then(res => {
                        if (!helper.isSuccess(res)) {
                            Toast(res.msg)
                            return
                        }

                        if (res.data && res.data.billClearedList) {
                            this.billClearedList = res.data.billClearedList.map((item) => {
                                return Object.assign(item, {
                                    isClear: true
                                })
                            });
                        }

                        resolve(res)
                    })
                })

            },
            handleListClick(item) {
                Indicator.open();
                this.getBillDetail(item.id).then(() => {
                    this.isPopupShow = true;
                    Indicator.close();
                })
            },
            getBillDetail(id) {
                return new Promise((resolve, reject) => {
                    api.user.bill
                        .detail({
                            billdetailid: id
                        })
                        .then(res => {

                            if (!helper.isSuccess(res)) {
                                return;
                            }
                            this.detailData = res.data;

                            resolve(res)
                        })
                })
            },
            //查询底部文案
            queryPlans() {
                api.queryPlans({
                    fundproductid: this.routeParams.productid,
                    modeltype: '3',
                    configtype: '4',
                    status: '',

                }).then(res => {


                    if (!helper.isSuccess(res)) {
                        Toast(res.msg)
                        return
                    }

                    if (res.data && res.data.length) {

                        let data = res.data.filter(item => {
                            return item.type == 50
                        })

                        if (data.length && data[0].content) {
                            this.footerPlan = data[0].content
                        }
                    }

                }).catch(e => {

                })

            },
        },
        activated () {
            // 设置右上角
            this.$AppBridge.setWebTitleAttribute({
                btnType: 'text',
                btnVal: '借款协议'
            }, () => {
                this.gotoAgreements();
            });
            
            this.$root.getRouteData().then(params => {
                this.routeParams = params
                console.log('this.routeParams', this.routeParams)

                Promise.all([this.getBillList1(), this.getBillList2()]).then((values) => {
                    let billList = this.billUnClearedList.concat(this.billClearedList);
                    billList.forEach((item) => {
                        this.loanMoney = (Number(this.loanMoney) + Number(item.dueamount)).toFixed(2);
                    })
                    if(billList.length > 0) {
                        console.log('billList[0]', billList[0])
                        this.firstData.status = billList[0].status;
                        this.firstData.loanDay = billList[0].paydate;

                        //this.firstData.dueDay = this.currentDay.diff(moment(billList[0].paydate), 'day');
                        this.firstData.productname = this.routeParams.productname;
                        this.firstData.iconurl = this.routeParams.iconurl;
                    }
                    this.billList = billList;
                });

                this.queryPlans();
            })



        },
        watch: {

        }

    }
</script>

<style lang="scss" scope>

    .bill-detail-page {
        .bill-header-content {
            margin: 12px 16px 28px 16px;
            height: 120px; 
            border-radius: 8px;
            background-image: linear-gradient(-52deg, #FF6068 0%, #EB242A 100%);
            box-shadow: 0 6px 20px 0 rgba(0,0,0,0.10);
            border-radius: 8px;

            .title {
                font-size: 20px;
                .c-icon {
                    @include size(16px);
                }
            }

            .top {
                height: 40px;
                background: rgba(255,255,255, 0.15);
                border-radius: 8px 8px 0 0;
                padding: 8px 12px;

                .title {
                    em {
                        font-size: 16px;
                        color: #FFFFFF;
                        letter-spacing: -0.46px;
                    }
                    
                    .c-icon {
                        @include size(24px);
                    }
                    
                }
            }
            .bottom {
                .title {
                    margin: 19px 0 2px 0;
                    font-size: 12px;
                    color: #FFFFFF;
                }
                .value {
                    font-size: 16px;
                    color: #FFFFFF;
                }
                .c-col-33 {
                    padding-left: 12px;
                    text-align: left;
                }
            }
        }
        .bill-header {
            position: relative;
            background: white;
            margin-bottom: 8px;

            .bill-header-title {
                font-size: 14px;
                color: #666666;
                letter-spacing: 0.12px;
                text-align: center;
                padding-top: 14px;
            }
            .bill-header-money {
                font-size: 26px;
                color: #333333;
                letter-spacing: 0.23px;
                text-align: center;
                margin-bottom: 8px;
            }
            .bill-status-img {
                position: absolute;
                width: 70px;
                height: 70px;
                right: 10px;
                top: 10px;

                img {
                    width: 100%;
                }
            }
            .bill-header-subtitle {
                font-size: 14px;
                letter-spacing: 0.12px;
                text-align: center;
                padding-bottom: 25px;

                &.red {
                    color: #D54740;
                }

                .status1 {
                    color: #666666;
                }
                .status2 {
                    color: #666666;
                }
                .status3 {
                    color: #D54740;
                }
            }
        }

        .bill-detail {
            background: white;
            padding: 14px;
            margin-bottom: 8px;

            .title {
                font-size: 16px;
                color: #333333;
            }

            .list {
                padding: 14px 0 6px 0;
                background: white;
                .list-item {
                    display: flex;
                    justify-content: space-between;
                    padding-bottom: 8px;
                    color: #666666;

                    .right-content {
                        display: flex;
                        font-size: 14px;
                    }

                    .see-agreement {
                        color: #4A90E2;
                    }

                }
            }

        }

        .bill-plan {
            position: relative;
            background: white;

            .title {
                font-size: 16px;
                color: #333333;
                padding-bottom: 14px;
            }

            .list {
                .list-row {
                    display: flex;
                    justify-content: space-between;
                    padding-bottom: 6px;

                    &:first-child {
                        @extend %border-b;
                    }
                    

                    .left-title {
                        font-size: 14px;
                        font-weight: bold;
                        color: #333333;
                        margin-top: 12px;
                        padding-left: 12px;
                        position: relative;

                        &::after {
                            content: "";
                            position: absolute;
                            left: 0;
                            top: 2px;
                            height: 14px;
                            width: 4px;
                            background: #eb242a;
                            border-radius: 2px;
                        }
                    }
                    .right-title {
                        font-size: 16px;
                        color: #333333;
                        padding: 11px 0 5px 0;
                    }

                    .left-date,
                    .right-content {
                        font-size: 14px;
                        color: #999999;
                        padding-bottom: 14px;
                    }
                    .right-title {
                        font-size: 14px;
                        .status1 {
                            color: #42B05A;
                        }
                        .status2 {
                            color: #ADADAD;
                        }
                        .status3 {
                            color: #D54740;
                        }
                        .status4 {
                            color: #ADADAD;
                        }
                    }
                }
                .list-item {
                    padding: 0 14px;
                    border-top: 8px solid #F8F8F8;
                }
            }
            .clear {
                .left-date,
                .right-content,
                .left-title,
                .right-title {
                    color: #ADADAD !important;
                }
            }
            .count {
                @extend %border-r;
            }
            .date-row {
                .line {
                    height: 20px;
                    @extend %border-r;
                }
            }
            .c-flex-row {
                justify-content: start !important;
            }
            .c-col-50 {
                margin-top: 10px;
                text-align: left;

                &:not(:first-child) {
                    padding: 0 0 0 29px;
                }
                
            }
            .sub-title {
                font-size: 12px;
                color: #999999;
            }
            .sub-content {
                font-size: 20px;
                color: #666666;
            }
        }

        .bill-plan-space {
            height: 88px;
            width: 100%;
            background-color: transparent;
        }

        .footer-plan {
            background: #f4f4f4;
            position: absolute;
            bottom: 0;
            padding: 20px;
            line-height: 16px;
            color: #999;
        }
    }

    .bill-detail-dialog {
        background-color: #fff;
        width: 329px;
        .dialog-title {
            position: relative;
            background: #e8e7e7;
            font-size: 16px;
            color: #333333;
            padding: 14px;
            text-align: center;

            .close{
                display: inline-block;
                float: right;
                width: 14px;
                height: 14px;
                background: url("../../assets/images/close.png") no-repeat;
                background-size: cover;
                margin-top: 2px;
                padding: 2px 4px;
            }

        }
        .dialog-content {
            text-align: center;
            position: relative;

            .dialog-cricle {
                background: #666;
                height: 10px;
                width: 10px;
                border-radius: 50%;
                position: absolute;
                display: block;
                top: -5px;
            }
            .cricle-left {
                left: -5px;
            }
            .cricle-right {
                right: -5px;
            }

            .dialog-sub-title {
                font-size: 14px;
                color: #666666;
                padding: 20px 0 6px 0;
            }
            .dialog-loan-money {
                font-size: 18px;
                color: #333333;
                padding-bottom: 18px;
            }
        }

        .dialog-list {
            @extend %border-t;
            padding: 16px;

            .dialog-list-item {
                display: flex;
                justify-content: space-between;
                margin-bottom: 10px;
                color: #666666;
            }
        }
    }
</style>
