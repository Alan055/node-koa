<template>
  <div class="luzhu-wrapper" v-if="showLuzhuBtn">
    <div class="nav-menu-box">
      <div class="nav-item" v-for="item in typeArrCur" :class="{active:item.active}"
           @click="setCurrent(typeArrCur,item)">{{item.word}}
      </div>
    </div>
    <div class="play-tab luzhu">
      <table class="outer-table">
        <thead>
        <tr>
          <th colspan="10">
            <div class="tab-item-box">
              <a class="tab-item" v-for="item in currentListArr"
                 :class="{active:item.active}"
                 @click="setCurrent(currentListArr,item)">{{item.word}}</a>
            </div>
          </th>
        </tr>
        </thead>
        <tbody>
        <tr>
          <table>
            <tbody>
            <td v-for="item in lineArr" class="luzhu-td">
              <table>
                <tbody>
                <tr v-for="val in item">
                  <td style="border-left:none;border-right:none" v-if="val"><em class="inball"
                                                                                :class="[{long:val === '龙'},{da:val === '大'},{dan:val === '双'},{he:val==='和'}]">{{val}}</em>
                  </td>
                  <td style="opacity: 0;border-left:none;border-right:none" v-else><em class="inball">1</em></td>
                </tr>
                </tbody>
              </table>
            </td>
            </tbody>
          </table>
        </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  let formatLines = function (data, mX = 30, mY = 6) {
    // mX横向最大数值 mY纵向最大数值
    let re = []
    // 得到一个空数组
    let empty = []
    for (let i = 0; i < mX; i++) {
      empty.push([])
      for (let j = 0; j < mY; j++) {
        empty[i].push('')
      }
    }
    let A = function (arr) {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i] !== '') {
          return i
        }
      }
      return mY
    }
    let B = function (res = []) {
      let re = JSON.parse(JSON.stringify(empty))
      let a, b, c, d
      for (let i = 0; i < res.length; i++) {
        // 得到当前这一列还有多少没有
        let middle = C(re)
        a = middle.a
        if (typeof a === 'undefined') {
          res.shift()
          return B(res)
        }
        b = res[i].length
        // 还能装的下 一个个赋值进去
        d = middle.d
        let n = b > a ? a : b
        // console.log('i---', i, '--a--', a, '---b---', b, '---', res[i][0])
        // console.log(d)
        for (let j = 0; j < n; j++) {
          re[d][j] = res[i][0]
        }
        // 装不下先把能装的装进去 然后剩下的拐弯
        if (b > a) {
          c = b - a + d + 1
          // 最大数值大于横向最大能容纳的数值时 将第一个数据去掉 重新计算
          if (c > mX) {
            res.shift()
            return B(res)
          } else {
            for (let j = d + 1; j < c; j++) {
              re[j][a - 1] = res[i][0]
            }
          }
        }
      }
      return re
    }
    let C = function (arr) {
      let j
      for (let i = 0; i < arr.length; i++) {
        j = A(arr[i])
        if (j !== 0) {
          return {a: j, d: i}
        }
      }
      return {}
    }
    let getData = function (str) {
      // 初步解析数据得到
      let res = []
      str.split(',').forEach(val => {
        let a = val.split(':')
        let b = []
        for (let i = 0; i < a[1]; i++) {
          b.push(a[0])
        }
        res.push(b)
      })
      res = res.reverse()
      return B(res)
    }
    for (let key in data) {
      let middle = {parent: '', listType: '', list: getData(data[key])}
      switch (key) {
        case '冠军大小':
        case '第一球大小':
          middle.parent = 'dx'
          middle.listType = 'one'
          break
        case '亚军大小':
        case '第二球大小':
          middle.parent = 'dx'
          middle.listType = 'two'
          break
        case '第三球大小':
          middle.parent = 'dx'
          middle.listType = 'three'
          break
        case '第四球大小':
          middle.parent = 'dx'
          middle.listType = 'four'
          break
        case '第五球大小':
          middle.parent = 'dx'
          middle.listType = 'five'
          break
        case '总和大小':
          middle.parent = 'dx'
          middle.listType = 'zh'
          break
        case '冠军单双':
        case '第一球单双':
          middle.parent = 'ds'
          middle.listType = 'ds_one'
          break
        case '亚军单双':
        case '第二球单双':
          middle.parent = 'ds'
          middle.listType = 'ds_two'
          break
        case '第三球单双':
          middle.parent = 'ds'
          middle.listType = 'ds_three'
          break
        case '第四球单双':
          middle.parent = 'ds'
          middle.listType = 'ds_four'
          break
        case '第五球单双':
          middle.parent = 'ds'
          middle.listType = 'ds_five'
          break
        case '总和单双':
          middle.parent = 'ds'
          middle.listType = 'ds_zh'
          break
        case '冠军VS第十名':
        case '第一球VS第二球':
          middle.parent = 'lh'
          middle.listType = 'wq'
          break
        case '亚军VS第九名':
        case '第一球VS第三球':
          middle.parent = 'lh'
          middle.listType = 'wb'
          break
        case '第三名VS第八名':
        case '第一球VS第四球':
          middle.parent = 'lh'
          middle.listType = 'ws'
          break
        case '第四名VS第七名':
        case '第一球VS第五球':
          middle.parent = 'lh'
          middle.listType = 'wg'
          break
        case '第五名VS第六名':
        case '第二球VS第三球':
          middle.parent = 'lh'
          middle.listType = 'qb'
          break
        case '第二球VS第四球':
          middle.parent = 'lh'
          middle.listType = 'qs'
          break
        case '第二球VS第五球':
          middle.parent = 'lh'
          middle.listType = 'qg'
          break
        case '第三球VS第四球':
          middle.parent = 'lh'
          middle.listType = 'bs'
          break
        case '第三球VS第五球':
          middle.parent = 'lh'
          middle.listType = 'bg'
          break
        case '第四球VS第五球':
          middle.parent = 'lh'
          middle.listType = 'sg'
          break
      }
      re.push(middle)
    }
    return re
  }
  let luzhuEmpty = [["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""], ["", "", "", "", "", ""]]

  export default {
    data() {
      return {
        // 分类
        typeArr: [
          {
            "key": "dx",
            "word": "大小",
            "list": [
              {
                "key": "one",
                "word": "第一球",
                "active": true
              },
              {
                "key": "two",
                "word": "第二球",
                "active": false
              },
              {
                "key": "three",
                "word": "第三球",
                "active": false
              },
              {
                "key": "four",
                "word": "第四球",
                "active": false
              },
              {
                "key": "five",
                "word": "第五球",
                "active": false
              },
              {
                "key": "zh",
                "word": "总和",
                "active": false
              }
            ],
            "active": true
          },
          {
            "key": "ds",
            "word": "单双",
            "list": [
              {
                "key": "ds_one",
                "word": "第一球",
                "active": true
              },
              {
                "key": "ds_two",
                "word": "第二球",
                "active": false
              },
              {
                "key": "ds_three",
                "word": "第三球",
                "active": false
              },
              {
                "key": "ds_four",
                "word": "第四球",
                "active": false
              },
              {
                "key": "ds_five",
                "word": "第五球",
                "active": false
              },
              {
                "key": "ds_zh",
                "word": "总和",
                "active": false
              }
            ],
            "active": false
          },
          {
            "key": "lh",
            "word": "龙虎",
            "list": [
              {
                "key": "wq",
                "word": "万千",
                "active": true
              },
              {
                "key": "wb",
                "word": "万百",
                "active": false
              },
              {
                "key": "ws",
                "word": "万十",
                "active": false
              },
              {
                "key": "wg",
                "word": "万个",
                "active": false
              },
              {
                "key": "qb",
                "word": "千百",
                "active": false
              },
              {
                "key": "qs",
                "word": "千十",
                "active": false
              },
              {
                "key": "qg",
                "word": "千个",
                "active": false
              },
              {
                "key": "bs",
                "word": "百十",
                "active": false
              },
              {
                "key": "bg",
                "word": "百个",
                "active": false
              },
              {
                "key": "sg",
                "word": "十个",
                "active": false
              }
            ],
            "active": false
          }
        ],
        // 分类
        typeArrQE: [
          {
            "key": "dx",
            "word": "大小",
            "list": [
              {
                "key": "one",
                "word": "第一球",
                "active": true
              },
              {
                "key": "two",
                "word": "第二球",
                "active": false
              }
            ],
            "active": true
          },
          {
            "key": "ds",
            "word": "单双",
            "list": [
              {
                "key": "ds_one",
                "word": "第一球",
                "active": true
              },
              {
                "key": "ds_two",
                "word": "第二球",
                "active": false
              }
            ],
            "active": false
          }
        ],
        // 分类
        typeArrHE: [
          {
            "key": "dx",
            "word": "大小",
            "list": [
              {
                "key": "four",
                "word": "第四球",
                "active": false
              },
              {
                "key": "five",
                "word": "第五球",
                "active": false
              }
            ],
            "active": true
          },
          {
            "key": "ds",
            "word": "单双",
            "list": [
              {
                "key": "ds_four",
                "word": "第四球",
                "active": false
              },
              {
                "key": "ds_five",
                "word": "第五球",
                "active": false
              }
            ],
            "active": false
          }
        ],
        typeArrPk10: [
          {
            "key": "dx",
            "word": "大小",
            "list": [
              {
                "key": "one",
                "word": "第一名",
                "active": true
              },
              {
                "key": "two",
                "word": "第二名",
                "active": false
              },
              {
                "key": "three",
                "word": "第三名",
                "active": false
              }
            ],
            "active": true
          },
          {
            "key": "ds",
            "word": "单双",
            "list": [
              {
                "key": "ds_one",
                "word": "第一名",
                "active": true
              },
              {
                "key": "ds_two",
                "word": "第二名",
                "active": false
              },
              {
                "key": "ds_three",
                "word": "第三名",
                "active": false
              }
            ],
            "active": false
          },
          {
            "key": "lh",
            "word": "龙虎",
            "list": [
              {
                "key": "wq",
                "word": "1v10",
                "active": true
              },
              {
                "key": "wb",
                "word": "2v9",
                "active": false
              },
              {
                "key": "ws",
                "word": "3v8",
                "active": false
              },
              {
                "key": "wg",
                "word": "4v7",
                "active": false
              },
              {
                "key": "qb",
                "word": "5v6",
                "active": false
              }
            ],
            "active": false
          }
        ],
        typeArrCur: [],
        currentLotteryId: 0
      }
    },
    computed: {
      // 打开走势图开关
      showLuzhuBtn() {
        let A = function (data, listType) {
          data.forEach((item, index) => {
            if (index === 0) {
              item.active = true
            } else {
              item.active = false
            }
            item.list.forEach((obj, ix) => {
              if (listType) {
                if (obj.word === listType) {
                  obj.active = true
                } else {
                  obj.active = false
                }
              } else {
                if (ix === 0) {
                  obj.active = true
                } else {
                  obj.active = false
                }
              }
            })
          })
          return data
        }
        let a = this.$store.getters.showLuzhuBtn
        if (a.type === 'pk10') {
          switch (a.code) {
            case 'DX':
              this.typeArrCur = A(this.typeArrPk10.slice(0, 1), a.listType)
              break
            case 'DS':
              this.typeArrCur = A(this.typeArrPk10.slice(1, 2), a.listType)
              break
            case 'LH':
              this.typeArrCur = A(this.typeArrPk10.slice(-1), a.listType)
              break
          }
        } else {
          switch (a.code) {
            case 'QEDXDS':
              this.typeArrCur = A(this.typeArrQE)
              break
            case 'HEDXDS':
              this.typeArrCur = A(this.typeArrHE)
              break
            case 'LH':
              this.typeArrCur = A(this.typeArr.slice(-1), a.listType)
              break
          }
        }
        if (a.type === 'jd') {
          switch (this.currentLotteryId) {
            case 70:
            case 71:
            case 72:
            case 80:
            case 82:
            case 85:
            case 86:
            case 87:
            case 88:
              this.typeArrCur = A(this.typeArr)
              return true
            default :
              return false
          }
        }
        return a.show && this.$store.state.showLuzhuFlag
      },
      // 露珠数据
      listData() {
        let data = this.$store.state.luzhu
        if (data && Object.keys(data).length) {
          return formatLines(data)
        }
        return []
      },
      // 当前的露珠
      lineArr() {
        let a = this.typeArrCur.find(item => item.active)
        let b = a.list.find(item => item.active)
        let c = {parent: a.key, listType: b.key}
        let d = this.listData.find(item => item.parent === c.parent && item.listType === c.listType)
        return d ? d.list : luzhuEmpty
      },
      // 当前子分类
      currentListArr() {
        return this.typeArrCur.find(item => item.active).list
      }
    },
    methods: {
      // 设置当前分类
      setCurrent(arr, item) {
        arr.map(obj => obj.active = false)
        item.active = true
      }
    },
    created() {
      this.currentLotteryId = Number(this.$route.hash.replace('#', ''))
    },
    watch: {
      '$route'() {
        this.currentLotteryId = Number(this.$route.hash.replace('#', ''))
      }
    }
  }
</script>

<style lang="stylus" rel="stylesheet/stylus">
  .luzhu-wrapper
    font-size: 0
    margin: 30px auto
    user-select: none
    .nav-menu-box
      background-color: #ddd
      text-align: left
      .nav-item
        display: inline-block
        vertical-align: top
        padding: 0 26px
        color: #333333
        line-height: 40px
        font-size: 16px
        cursor: pointer
        position: relative
        &.active
          color: #e75560
          background-color: #ffffff
          &:before
            content: ''
            position: absolute
            top: 0
            left: 0
            width: 100%
            height: 3px
            background-color: #f53b4a
    .play-tab
      &.luzhu
        .trend-tag
          background-color: #ceb78d
      .trend-tag
        position: absolute
        height: 105px
        text-align: center
        padding: 30px 10px 0 10px
        width: 40px
        background-color: #d87c7d
        color: #fff
        line-height: 20px
        font-size: 14px
      .outer-table
        height: 105px
        margin-left: 20px
        width: 856px
        margin-bottom: 10px
        > thead th
          padding: 10px 0
          display: block
          width: 727px
          .tab-item-box
            background: #e8e8e8
            border-radius: 4px
            display: inline-block
            vertical-align: top
            overflow: hidden
            border: 1px solid #dddddd
            .tab-item
              display: inline-block
              vertical-align: top
              text-align: center
              color: #333333
              padding: 8px 16px
              margin-right: 0px
              font-size: 12px
              cursor: pointer
              border-right: 1px solid #dddddd
              margin-left: -1px
              &:last-child
                border-right: none
              &.active
                background-color: #f53b4a
                color: #fff
        > tbody
          table
            width: 100%
            tbody
              td
                &.luzhu-td
                  vertical-align: top
                  border: 1px solid rgb(221, 221, 221);
                  padding: 0
                  tbody
                    tr:first-child td
                      border-top: none
                    tr:last-child td
                      border-bottom: none
                font-size: 14px
                padding: 4px
                text-align: center
                border: 1px solid #ddd
                .inball
                  font-size: 12px
                  display: inline-block;
                  width: 20px
                  height: 20px
                  background-color: #009367
                  color: #fff
                  line-height: 20px
                  border-radius: 20px;
                  text-align: center
                  &.long
                    background-color: #e74552
                  &.da
                    background-color: #e74552
                  &.dan
                    background-color: #e74552
                  &.he
                    background-color: #0A8CEC

</style>
