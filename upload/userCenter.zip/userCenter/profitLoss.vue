<template>
  <div class="profitLoss">
    <!--导航栏-->
    <div class="profitLoss_nav"><span v-for="(v,i) in nav" :key="i" @click="navIndex=i,init()"
                                      :class="{'active':navIndex===i}">{{v.label}}</span></div>
    <!--分类模块--> <!--趋势模块-->
    <div>
      <!--时间筛选-->
      <div class="assortChoose">
        <div v-if="navIndex===0">
          <DatePicker type="month" v-model="assort_start" :options="dateLimit" style="width: 100px"></DatePicker>
          <!--&nbsp; - &nbsp;-->
          <!--<DatePicker type="month" v-model="assort_end" :options="dateLimit" style="width: 100px"></DatePicker>-->
        </div>
        <div v-else>
          <DatePicker type="year" v-model="year" :options="dateLimit" style="width: 100px"></DatePicker>
        </div>
        <span class="search" @click="assort_search()">查询</span>
        <span class="reset" @click="assort_reset()">重置</span>
      </div>
      <fundStatus :funds="fundObj" v-if="fundObj"></fundStatus>
      <div class="dataReport">
        <div class="dataAnalysis">
          <div class="top">
            <div class="left"><em class="icon_v3">&#xe718;</em>数据分析</div>
          </div>
          <div class="content">
            <div id="profitLoss_chart"></div>
            <div class="tab" v-if="navIndex===0">
              <span :class="{'active':tabIndex===i}" v-for="(v,i) in tab" :key="i"
                    @click="tabIndex=i,find_chartDataAjax()"><em class="icon_v3" v-html="i===1?'&#xe727;':'&#xe726;'"></em>{{v}}</span>
            </div>
          </div>
        </div>
        <div class="report">
          <div class="top">
            <div class="left">
              <em class="icon_v3">&#xe719;</em>报表
            </div>
            <div class="right">
              <em class="icon_v3 pre" @click="report_page>1&&report_page--" :class="{'noClick':report_page==1}">&#xe616;</em>
              <span>第{{report_page}}页</span>
              <em class="icon_v3 next" @click="!(report_page==Math.ceil(total_size/size)||total_size==0)&&report_page++" :class="{'noClick':report_page==Math.ceil(total_size/size)||total_size==0}">&#xe616;</em>
            </div>
          </div>
          <ul class="report_top">
            <li v-for="(v,i) in report_top" :key="i">{{v}}</li>
          </ul>
          <ul class="report_content" v-for="(v,i) in report_content_show" :key="i" v-if="report_content_show.length>0&&!load">
            <li>{{v.lotteryName}}</li>
            <li>¥{{v.confirmAmountSum}}</li>
            <li>¥{{v.awardAmountSum}}</li>
            <li :class="tabIndex==0?'profit':'loss'">{{(tabIndex==0?'+':'')+v.profitAmountSum}}</li>
          </ul>
          <div class="noData" v-if="report_content_show.length==0&&!load">
            <div class="picture"><em class="icon_v3">&#xe6a5;</em></div>
            <div class="txt">暂无数据</div>
          </div>
          <div class="loading" v-show="load"><em class="icon_v3">&#xe6d6;</em>正在加载中</div>
        </div>
      </div>
	</div>

	</div>
	</template>

	<script>
	import fundStatus from "./fundStatus.vue";
	import echarts from "echarts";
	import service from './../../js/service.js'

	export default {
		components: {fundStatus},
		data() {
			return {
				nav: [
					{label: '分类'},
					// {label: '趋势'},
				],
				navIndex: 0,
				// 资金状态的数据 --公共组件
				fundObj: [
					{label: '有效投注额', num: ''},
					{label: '总中奖金额', num: ''},
					{label: '盈亏额', num: ''},
				],
				report_page: 1, // 报表的分页 -- 当前是第几页
				size: 11, // 一次请求多少条数据  由于页面的大小问题  这里一次可以显示11条
				total_size: 0, // 后台总页数
				// 时间下拉框
				assort_start: moment().format('YYYY-MM'), // 分类查询起始时间
				// assort_start: '2018-09', // 分类查询起始时间
				assort_end: moment().format('YYYY-MM'), // 分类查询结束时间 --- 这个暂时不需要了
				year: moment().format('YYYY'), // 趋势的年份下拉框
				dateLimit: {// 控制时间选择器的可选时间长度
					disabledDate(date) {
						return date && (date.valueOf() > Date.now());
					}
				}, // 分类查询时间限制
				report_top: ['彩种', '有效投注额', '中奖总额', '盈利总额'], // 报表表格头部
				report_content: [], // 报表内容数据 --存放的数据
				report_content_show: [], // 表报的数据内容 --显示的 需要前端分页的
				tab: ['盈利', '负盈利'], // 饼图下方的盈利和亏损
				tabIndex: 0,// 当前选中的是盈利还是亏损
				assortChart: null, // 饼图对象
				assortChartData: null, // 饼图对象的数据
				// 饼图的各个区间的 颜色
				chartColor: ['#e95f43', '#f17340', '#fa9955', '#f0b327', '#f0d627', '#c1d824', '#52d884', '#52ded2', '#52bdf6', '#527cf6', '#ab52f6',],
				// 趋势线的颜色
				chartLineColor: ['#0084ff', '#ffab18', '#c73bf5', '#f53b4a'], //
				// 趋势线下方的阴影颜色
				chartLineColor_sha: ['#eef7ff', '#fff7ea', '#e1e1f5', '#feedee'],
				// 趋势每根线的名字
				chartLineText: ['有效投注额', '中奖总额', '活动总额', '盈亏总额'],
        // 加载中。。。
        load: false,
        // 饼图的盈亏总额
        pieChartLumpSum: '',
			}
		},
		computed: {},
		watch: {
			report_page(){
				this.report_content_show = this.report_content.slice((this.report_page-1)*this.size,this.report_page*this.size)
      }
    },
		methods: {
			// 分类的时间筛选
			assort_search() {
				this.find_chartDataAjax()
			},

			// 饼图的数据查询
			find_chartDataAjax() {
				this.load = true // 打开加载中
				service.post(this, 'report/report-lottery-profit-loss', {
					queryDate: moment(this.assort_start).format('YYYY-MM-DD') + ' 00:00:00',
					profitLossType: this.tabIndex + 1,
				}).then(function (result) {
					this.load = false // 关闭加载中
					let res = result.data
					if (res.code === 0) {
						// 资金状态数据匹配
						this.fundObj[0].num = res.data.recordMap.confirmAmountSum
						this.fundObj[1].num = res.data.recordMap.awardAmountSum
						this.fundObj[2].num = res.data.recordMap.profitAmount // 盈亏额
            this.pieChartLumpSum = res.data.recordMap.profitAmountSum//饼图的盈亏总额
            // 存放右边报表的数据 这里有分页的功能，只是前端分页 所以要缓存着
						this.report_content = res.data.recordList
						this.total_size = res.data.recordList.length // 后台总数据数量
            this.report_page = 1 // 初始化表报的页数为第一页
						this.report_content_show = res.data.recordList.slice((this.report_page-1)*this.size,this.report_page*this.size)
						// 这里要做特殊处理  关于饼图的 饼图最多只能有11条数据  大于10条的用其他合并
            let pieChart = []; // 饼图的数据
						if (res.data.recordList.length > 5) {
							// 数据大于条  就截取前面10条数据  后面的数据用 dataAccountFor （其他代替）  保证最多只有11条数据
							pieChart = res.data.recordList.slice(0, 5)
							pieChart.push(res.data.dataAccountFor)
						} else {
							pieChart = res.data.recordList // 显示在表格中
						}

						// 将数据格式转换成echart能使用的格式
						let arr = [];
						for (let val of pieChart) {
							arr.push({
								value: val.profitAmountSum, name: val.lotteryName, label: { // 是数据排版位置
									formatter: [
										`{${this.tabIndex == 0 ? 'a' : 'd'}|${(val.profitAmountSum.toFixed(2))}}  {c|${(Math.round(val.dataAccountFor * 10000)/100)}%}`,
										'{b|{b}}{abg|}'
									].join('\n'),
									rich: {
										a: {
											color: 'red',
											lineHeight: 10
										},
										d: {
											color: '#2396F7',
											lineHeight: 10
										},
										b: {
											color: '#666',
											align: 'center',
										},
										c: {
											color: '#666',
										},
									}
								}
							},)
						}
						this.assortChartData = arr; // 添加到饼图的数据中
            console.log(pieChart)
						// 有数据之后在实例化饼图
						if (this.report_content.length > 0) {
							this.init_assortChart();
						} else {
							// 没有数据就清楚饼图
							this.assortChart && this.assortChart.clear()
						}
					} else {
						this.$Modal.al_default({status: 'warning', content: res.message})
					}

				}, function (err) {
					this.load = false // 关闭加载中
					console.log(err)
				})
			},

			// 点击重置功能
			assort_reset() {
				// 默认显示当前月份
				this.assort_start = moment().format('YYYY-MM')
				this.assort_end = moment().format('YYYY-MM')
			},
			// 创建一个option对象 --曲线图的  --这个暂时不要了
			creatLineOption(data) {
				let monthArr = []; // 月份通过 年份的剩下的月份来计算出
				let series = []; // 数据格式 以及样式
				for (let [ind, val] of data.entries()) {
					series.push({
						name: this.chartLineText[ind],
						type: 'line',
						// smooth: true, // 是否是曲线
						areaStyle: {
							color: {
								type: 'linear',
								x: 0,
								y: 0.5,
								x2: 0,
								y2: 1,
								colorStops: [{
									offset: 0, color: this.chartLineColor_sha[ind] // 0% 处的颜色
								}, {
									offset: 1, color: '#fff' // 100% 处的颜色
								}],
								globalCoord: false // 缺省为 false
							}
						},
						data: val
					})
				}
				// 如果是当前年份就 月份的数组就是当前年到现在的月份  如果不是当前年份  就是12个月
				let length = this.year === moment().format('YYYY') ? Number(moment().format('MM')) : 12
				for (let i = 0; i < length; i++) {
					monthArr.push(i + 1 + '月')
				}
				return {
					tooltip: {
						trigger: 'axis',
						axisPointer: {
							type: 'cross',
							label: {
								backgroundColor: '#6a7985'
							}
						}
					},
					legend: {
						data: this.chartLineText
					},
					xAxis: {
						type: 'category',
						data: monthArr
					},
					yAxis: {
						type: 'value'
					},
					color: this.chartLineColor,
					series: series
				};


			},

			// 初始化盈亏报表的饼图  --渲染加载
			init_assortChart() {
				let dom = document.getElementById("profitLoss_chart")
				this.assortChart = echarts.init(dom)
        // 解决分辨率问题
				let isNormal = $('#profitLoss_chart').width()>400
				let option = {
					title: {
						text: '盈利总额（¥）',
						subtext: this.pieChartLumpSum.toFixed(2),
						x: 'center',
						y: '45%',
						textStyle: {
							color: '#666',
							fontSize: 18,
							fontWeight: 'normal'
						},
						subtextStyle: {
							color: '#f53b4a',
							fontSize: 16
						}
					},
					tooltip: {
						trigger: 'item',
						// formatter: '{a} <br/>{b} : {c} ({d}%)'
						formatter: '{a} <br/>{b} : ¥{c}'
					},
					series: [
						{
							name: '盈亏数据',
							type: 'pie',
							radius: isNormal?['35%', '50%']:['30%', '42%'],
							center: ['50%', '50%'],
							color: this.chartColor,
							hoverAnimation: false,
							label: {
								show: true,
								fontSize: 13,
								position: 'outside',
								verticalAlign: 'top',
								padding: [0, -3, 0, -3],
							},
							labelLine: {
								show: true,
								length: 15,
								length2: 10,
							},
							animationDuration: 1000,
							itemStyle: {
								emphasis: {
									shadowBlur: 10,
									shadowOffsetX: 0,
									shadowColor: 'rgba(0, 0, 0, 0.5)'
								}
							},
							data: this.assortChartData, // 饼图的数据
						}
					]
				};
				this.assortChart.setOption(option, true);
			},

			// 初始化盈亏报表的曲线线 --渲染加载 --这个暂时不要了
			init_Chart(data) {
				let dom = document.getElementById("profitLoss_chart")
				this.assortChart = echarts.init(dom)
				data = [
					[120, 132, 101, 134, 90, 230, 210, -134, 90, 230, 210],
					[220, 182, 191, 234, 290, 330, 310, 234, 290, 330, 310],
					[150, 232, 201, 154, -190, 330, 410, 154, 190, 330, -410],
					[320, 332, 301, -334, 390, 330, 320, 334, 390, 330, 320],
				];
				let option = this.creatLineOption(data)
				this.assortChart.setOption(option, true);
			},
			init() {
				if (this.navIndex === 0) {
					this.find_chartDataAjax();
					this.assort_start = moment().format('YYYY-MM'); // 分类查询起始时间
				} else {
					this.year = moment().format('YYYY'), // 趋势的年份下拉框
						this.init_Chart() // 初始化echar图
				}
			}
		},
		created() {

		},
		mounted() {
			this.init()
		},
	}
</script>

<style lang='less' scoped>
  @import "./../../css/global.less";

  .profitLoss {
    height: calc(~"100% - 24px");
    > div {
      height: 100%;
    }
    .profitLoss_nav {

      display: flex;
      justify-content: left;
      height: 30px;
      border-radius: 4px;
      overflow: hidden;
      width: 160px;
      display: none;
      span {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
        width: 80px;
        font-size: 14px;
        cursor: pointer;
        color: #333;
        &.active {
          background: @themeColor;
          color: #fff;
        }
        &:not(.active) {
          .bor(#ebebeb);
          background: #f5f5f5;
        }
      }
    }
    .assortChoose {
      display: flex;
      justify-content: left;
      height: 30px;
      margin: 16px 0;
      align-items: center;
      .search {
        display: flex;
        height: 100%;
        width: 60px;
        border-radius: 15px;
        color: #fff;
        justify-content: center;
        align-items: center;
        background: @themeColor;
        margin: 0 10px;
        cursor: pointer;
      }
      .reset {
        cursor: pointer;
      }

    }
    .dataReport {
      margin-top: 15px;
      display: flex;
      justify-content: space-between;
      height: calc(~"100% - 180px");
      > div {
        width: 50%;
        .bor(@userCent_bor);
      }
      .top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: @userCent_bac;
        font-size: 14px;
        height: 40px;
        border-bottom: 1px solid @userCent_bor;
        .left {
          em {
            color: #b5b5b5;
            margin: 0 10px;
          }
        }
        .right {
          margin-right: 10px;
          display: flex;
          justify-content: center;
          align-items: center;
          em {
            display: flex;
            cursor: pointer;
          }
          .pre {
            transform: rotate(90deg);
          }
          .next {
            transform: rotate(-90deg)
          }
          .noClick {
            color: #ccc;
            cursor: not-allowed;
          }
          span {
            margin: 0 5px;
          }
        }
      }
      .dataAnalysis {
        border-right: none;
        .content {
          height: calc(~"100% - 60px");
          padding-top: 20px;
          #profitLoss_chart {
            width: 100%;
            height: calc(~"100% - 30px");
          }
          .tab {
            display: flex;
            justify-content: center;
            height: 30px;
            border-radius: 4px;
            overflow: hidden;
            width: 160px;
            margin: 0 auto;
            span {
              display: flex;
              justify-content: center;
              align-items: center;
              height: 100%;
              width: 80px;
              font-size: 14px;
              cursor: pointer;
              color: #333;
              &:first-child.active {
                background: @themeColor;
                color: #fff;
              }
              &:last-child.active {
                background: @themeColor_Sec;
                color: #fff;
              }
              &:not(.active) {
                .bor(#ebebeb);
                background: #f5f5f5;
              }
            }
          }
        }

      }
      .report {
        display: flex;
        flex-direction: column;
        justify-content: left;
        ul {
          display: flex;
          justify-content: space-between;
          height: 40px;
          li {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 25%
          }
        }
        .report_top {
          padding: 0 15px;
          font-size: 14px;
          color: #333;
          border-bottom: 1px solid @userCent_bor;
        }
        .report_content {
          color: #666;
          margin: 0 15px;
          border-bottom: 1px dashed @userCent_bor;
          .profit {
            color: @themeColor;
          }
          .loss {
            color: @themeColor_Sec;
          }
        }
        .loading {
          display: flex;
          justify-content: center;
          align-items: center;
          height: calc(~"100% - 40px");
          font-size: 14px;
          color: #888;
          em {
            color: #CFCFCF;
            font-size: 24px;
            animation: transitionSelf 0.7s linear infinite;
            margin-right: 8px;
          }
        }
        .noData {
          height: 300px;
          display: flex;
          flex-direction: column;
          justify-content: center;
          .picture {
            em {
              color: #888;
              opacity: 0.4;
              font-size: 52px;
            }
          }
          .txt {
            color: #888;
            font-size: 16px;
          }
        }
      }
    }
  }
</style>