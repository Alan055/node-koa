<template>
  <div class="user_bonusPool">
    <div class="top">
      <div class="issue">
        <label>期号：</label>
        <Select v-model="issue" style="width:120px">
          <Option v-for="item in issueList" :value="item.value" :key="item.value">{{ item.label }}</Option>
        </Select>
      </div>
      <div class="Number">
        <label>号码：</label>
        <input type="text" placeholder="请输入号码" v-model="number">
      </div>
      <div class="status">
        <label>状态：</label>
        <Select v-model="status" style="width:120px">
          <Option v-for="item in statusList" :value="item.value" :key="item.value">{{ item.label }}</Option>
        </Select>
      </div>
      <div class="time">
        <label>时间：</label>
        <DatePicker type="daterange" :clearable="false" v-model="date" :options="dateLimit"
                    placement="bottom-end" placeholder="请选择查询日期"
                    style="width: 200px"></DatePicker>
      </div>
      <div class="btn">
        <span class="search" @click="pagination_page = 0,findData()">查询</span>
        <span class="reset" @click="reset()">重置</span>
      </div>
    </div>
    <div class="table">
      <!--tableTop: 表格头部 ,tableContent: 表格内容 ,page_total:后台数据总条数 ,page_page: 当前第几页 ,
      page_pageTotal: 总共多少页 ,page_size: 一页显示多少条数据 ,page_change:点击分页时的事件，loading：是否在加载中状态-->
      <Table
        :tableTop="tableTop"
        :tableContent="tableContent"
        :page_page="pagination_page"
        :page_pageTotal="Math.ceil(pagination_total / pagination_size)"
        :page_total="pagination_total"
        :page_size="pagination_size"
        :page_change="pagination_change"
        :loading="loading"
      >
        <ul class="tableTop">
          <li v-for="(v,i) in tableTop" :key="i">{{v}}</li>
        </ul>
        <ul class="tableContent" v-for="(v,i) in tableContent" :key="i" v-if="tableContent.length>0&&!loading">
          <li>{{i+1+(pagination_page*pagination_size)}}</li>
          <li>{{v.activityIssueNo}}</li>
          <li>{{v.activityNumber}}</li>
          <li>{{tran_time(v.createTime)}}</li>
          <li>{{tran_status(v.status)}}</li>
        </ul>
      </Table>
    </div>

  </div>
</template>

<script>
  import service from "./../../js/service.js";
  import {mapState, mapMutations, mapActions} from 'vuex';
  import Table from "./alan_table.vue"; // 引入表格组件

  export default {
    components: {Table},
    data() {
      return {
        issue: '0', // 期号选择器数据
        issueList: [
          {label: '全部', value: '0'},
          {label: '近一期', value: '1'},
          {label: '近两期', value: '2'},
          {label: '近三期', value: '3'},
        ],
        status: 'all', // 状态选择器数据
        statusList: [
          {label: '全部', value: 'all'},
          {label: '未开奖', value: '0'},
          {label: '已中奖', value: '1'},
          {label: '未中奖', value: '2'},
        ],
        date: [moment().add(0, 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')], // 当前选择的日期
        dateLimit: { // 控制时间选择器的可选时间长度
          disabledDate(date) {
            return date && (date.valueOf() > Date.now());
          }
        },
        number: '', // 查询的号码

        tableTop: ['序号', '期号', '号码', '生成时间', '状态'], // 表格头
        tableContent: [], // 表格内容
        load: false, // 是否出现正在加载中
        pagination_size: 10, // 一页的数据数
        pagination_total: 0, // 后台数据总数
        pagination_page: 0, // 当前页
        loading: false, // 加载中
      }
    },
    computed: {
      ...mapState(['bonusPool_issue', 'bonusPool_id']),
    },
    watch: {},
    methods: {
      // 获取表格的数据
      findData() {

        this.tableContent = [] // 初始化清空列表数据
        let obj = {
          activityNumber: this.number,
          startTime: moment(this.date[0]).format('YYYY-MM-DD') + " 00:00:00",
          endTime: moment(this.date[1]).format('YYYY-MM-DD') + " 23:59:59",
          page: this.pagination_page,
          size: this.pagination_size,
          activityId: this.bonusPool_id,
        }
        if (this.issue !== '0') { // 期号筛选 这里比较麻烦  后台不给力
          obj.activityIssueNo = []
          for (let i = 0; i < this.issue; i++) {
            obj.activityIssueNo.push(`${this.bonusPool_issue - i}`)
          }
          obj.activityIssueNo = obj.activityIssueNo.join(',')
        }
        this.status !== 'all' && (obj.status = this.status)
        this.loading = true // 打开加载中
        service.postDefault(this, '/yx/api/activity/activityNumberList', obj).then(function (result) {
          let res = result.data
          if (res.code === 0) {
            this.tableContent = res.data.list
            this.pagination_total = res.data.totalCount
          } else {
            this.$Modal.al_default({status: 'warning', content: res.message})
          }
          this.loading = false // 关闭加载中
        }, function (err) {
          console.log(err)
          this.loading = false // 关闭加载中
        })
      },
      // 转换状态的枚举
      tran_status(v) {
        let obj = this.statusList.find((e) => (e.value == v))
        return obj ? obj.label : ''
      },
      // 转换时间
      tran_time(v) {
        return moment(v).format("YYYY-MM-DD HH:mm:ss")
      },

      pagination_change(i) {
        // i是当前点击的页数，但我们后台是从0开始的  所以要减1
        this.pagination_page = i - 1
        this.findData() // 查询数据
      },

      // 重置的点击事件
      reset() {
        this.issue = '0';
        this.status = 'all';
        this.number = '';
        this.pagination_page = 0
        this.date = [moment().add(0, 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')]; // 当前选择的日期
        this.findData()
      },
      init() {
        this.findData()
      }
    },
    created() {
      this.init()
    },
    mounted() {
    },
  }
</script>

<style lang='less' scoped>
  @import "./../../css/global.less";

  .user_bonusPool {
    height: 100%;

    .top {
      display: flex;
      justify-content: left;
      align-items: center;
      height: 44px;
      color: #333;

      > div {
        margin-right: 10px;

        label {
          font-size: 14px;
        }

        &.Number {
          input {
            .bor(#dcdee2);
            width: 120px;
            height: 30px;
            border-radius: 4px;
            padding-left: 8px;
            outline: none;
            color: #333;
          }
        }

        &.btn {
          > * {
            cursor: pointer;
          }

          .search {
            display: inline-block;
            background: @themeColor;
            color: #fff;
            border-radius: 20px;
            padding: 3px 15px;
            margin: 0 10px;
          }
        }
      }
    }

    .table {
      margin-top: 10px;
      height: calc(~"100% - 64px");

      ul {
        display: flex;
        justify-content: space-between;
        align-items: center;

        li {
          display: flex;
          justify-content: center;
          align-items: center;
          width: 20%;
          border-right: 1px solid #ccc;
          height: 36px;
          font-size: 14px;

          &:last-child {
            border-right: none;
          }
        }
      }

      .tableTop {
        background: #f6f6f6;
        border: 1px solid #ccc;
      }

      .tableContent {
        color: #666;
        border-left: 1px solid #ccc;
        border-right: 1px solid #ccc;

        li {
          border-bottom: 1px solid #ccc;
          border-right: 1px solid #ccc;
        }

      }
    }
  }
</style>
