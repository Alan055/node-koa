<template>
  <div class="teamOverview">
    <section class="top">
      <aside class="label">当前等级</aside>
      <article class="box">
        <div class="left">
          <div class="photo"><img :src="userInfoGrade.img" alt=""></div>
          <div class="text">{{userInfoGrade.label}}</div>
          <div class="num"><span @click="$router.push({path:root_userCenter+'/teamDetail'})">当前团队人数：{{teamInfo.teamCount}}人</span></div>
        </div>
        <div class="center">
          <div>
            <p class="num">¥{{al_fi(teamInfo.dayProceeds,1)}}</p>
            <p class="text"><span @click="$router.push({path:root_userCenter+'/teamBetRecord'})">本日收益>></span></p>
          </div>
          <div>
            <p class="num">¥{{al_fi(teamInfo.allProceeds,1)}}</p>
            <p class="text"><span @click="$router.push({path:root_userCenter+'/teamBetRecord'})">总收益>></span></p>
          </div>
        </div>
        <div class="right">
          <div class="photo">
            <qrcode v-if="scan" :value="scan" :options="{ width: 154,height: 154 }"></qrcode>
          </div>
          <div class="btn">
            <label>推荐二维码</label>
            <span class="copy" :class="{'noClick':!copyText}" @click="copyText&&copyClick($event)">复制链接</span>
            <span class="poster" @click="creatPoster()">生成海报</span>
          </div>
        </div>
      </article>
    </section>

    <section class="content">
      <aside class="label">当前保级任务</aside>
      <article class="box">
        <div v-for="(v,i) in teamConfig" :key="i" class="item">
          <div class="text">{{teamInfo[TypeTran[v.type]]>=v[gradeTran[userInfoGrade.label]]?'恭喜你，已完成保级任务！':v.copywriting}}</div>
          <div class="process">
            <div class="left">
              <span>{{ruleTran[v.type]}}: </span>
              <b>
                <i :style="`width: ${teamInfo[TypeTran[v.type]]>=v[gradeTran[userInfoGrade.label]]?100:teamInfo[TypeTran[v.type]]/v[gradeTran[userInfoGrade.label]]*100}%`"></i>
                <s v-if="teamInfo[TypeTran[v.type]]>=v[gradeTran[userInfoGrade.label]]" class="finished"><em class="icon_v3">&#xe646;</em></s>
              </b>
              <span ><em>{{teamInfo[TypeTran[v.type]]}}</em>/{{v[gradeTran[userInfoGrade.label]]}}</span>
            </div>
            <div class="right">
              <span v-if="teamInfo[TypeTran[v.type]]>=v[gradeTran[userInfoGrade.label]]&&ruleTran[v.type].includes('团队投注')" class="finish">已完成</span>
              <span v-else-if="ruleTran[v.type].includes('团队投注')">未完成</span>
              <span v-else-if="ruleTran[v.type].search(/个人投注|总投注/)>-1" class="goBet" @click="$router.push({path:'/lottery/#'+master_lottery})">立即投注</span>
              <span v-else class="goShare" @click="copyText&&copyClick($event)">复制链接</span>
            </div>
          </div>
        </div>
      </article>
    </section>

    <section class="bottom">
      <em class="icon_v3">&#xe6ad;</em>注：完成其中{{numberDict[precondition]}}个任务，即可继续享受{{currentGradeInfo.grade}}权限
    </section>

    <!--弹框  生成海报-->
    <div class="modal_poster" v-if="poster">
      <div class="box" ref="superPartner_download">
        <div class="close" @click="poster=false"></div>
        <div class="title">让他成为你的战友，开始{{$store.state.appConfigData.name}}之旅</div>
        <div class="scanBox">
          <div class="scan">
            <qrcode v-if="scan" :value="scan" :options="{ width: 234,height: 234 }"></qrcode>
          </div>
          <a class="save_btn" :href="realImageSrc" download="海报"><img src="./img/team_posterBtn.png" alt=""></a>
        </div>
      </div>
    </div>
    <!--存放下载海报的位置-->
    <div ref="poster"></div>
  </div>
</template>

<script>
  import qrcode from "@chenfengyuan/vue-qrcode";
  import {mapState, mapMutations, mapActions} from 'vuex';
  import service from "./../../js/service.js";
  import html2canvas from "html2canvas";

  export default {
    components: {qrcode},
    data() {
      return {
        currentGradeInfo: {
          finish: 2,
        },
        scan: '', // 二维码的链接
        copyText: '',
        poster: false, // 生成海报弹框的按钮
        realImageSrc: '',// 下载海报的链接  这个是前端通过canvas自动生成的
        numberDict: {
          1: '一',
          2: '两',
          3: '三',
          4: '四',
          5: '五',
        },

        teamActiveId: 0, // 团队中心的活动id
        teamInfo: {}, // 团队中心的信息
        teamConfig: [], // 团队中心的配置 保级规则
        precondition: '', // 保级条件

        ruleTran: { // 规则类型
          effectiveTeamBets: '团队投注额',
          effectivePersonalBets: '个人投注额',
          totalEffectiveBets: '总投注额',
          activeNumber: '活跃人数',
          numberOfNewUsers: '新增用户数',
        },
        TypeTran: { // 规则类型 对应的枚举
          effectiveTeamBets: 'teamConfirmAmount', // 团队投注额
          effectivePersonalBets: 'personalConfirmAmount', // 个人投注额
          totalEffectiveBets: 'totalBetAmount', // 总投注额
          activeNumber: 'activeCount', // 活跃人数
          numberOfNewUsers: 'addCount', // 新增用户数
        },
        gradeTran: { // 代理类型的枚举字段
          '代理': 'agency',
          '总代理': 'generalAgent',
          '股东': 'shareholder',
          '大股东': 'majorShareholder',
        },
      }
    },
    computed: {
      ...mapState(['root_userCenter','baseInfo']), // 用户等级在baseInfo里面
      // 拿到用户等级
      userInfoGrade(){
        let grade = -1
        let label = ''
        if(this.teamInfo.userAgentType) {
          label = this.teamInfo.userAgentType.replace('会员','')
          grade = Object.keys(this.gradeTran).findIndex((e)=>(e==label))
        }
        return {label: label, img: grade>-1 ? require(`./img/teamOverviewLogo_${grade+1}.png`) : '',}
      },
      master_lottery(){ // 获取集团主营彩种
        return appConfig().master_lottery
      }

    },
    watch: {},
    methods: {
      // 获取复制的文案
      findCopy(){
        service.post(this, 'notice/contentList', {
          platform: 'pcshow',
          page: '0',
          size: '1',
          typeCode: 'go-six',
        }).then((result) => {
          let res = result.data
          if (res.code === 0) {
            res.data.list.length>0 && (this.copyText = res.data.list[0].content.replace(/&nbsp;/g,'').replace(/<p>/g,'').replace(/<\/p>/g,'').replace(/&darr;/g,'↓'))
            this.changeCopyText() // 改变粘贴的文本
          } else {
            this.$Modal.al_default({status: 'warning', content: res.message})
          }
        })
      },
      // 查询代理的扫码地址
      findScan(){
        service.post(this, 'agent/list-user-agent-regist-link', {}).then((result) => {
          let res = result.data
          if (res.code === 0) {
            this.findParentId(res.data.code.split(/[/.]/)[2]) // 查询当前的parentId
          } else {
            this.$Modal.al_default({status: 'warning', content: res.message})
          }
        })
      },
      // 查询当前的parentId
      findParentId(str){
        service.postDefault(this, '/yx/rg/init', {link: str}).then((result) => {
          let res = result.data
          if (res.code === 0) {
            this.scan = location.origin + '/rg/' + res.data.parentId
            this.changeCopyText() // 改变粘贴的文本
          } else {
            this.$Modal.al_default({status: 'warning', content: res.message})
          }
        })
      },
      // 获取团队中心的活动id  --团队中心相当于一个活动
      findTeamActivity(){
        service.postDefault(this, '/yx/api/activity/getList', {isMobile:false,bizType:25}).then((result) => {
          let res = result.data
          if (res.code === 0) {
            this.teamActiveId = res.data[0].id
            this.teamActiveId && this.findActiveDetail() // 查询团队中心 活动的配置
          } else {
            this.$Modal.al_default({status: 'warning', content: res.message})
          }
        })
      },
      // 查询团队中心 活动的配置
      findActiveDetail(){
        service.postDefault(this, '/yx/api/activity/getUserSixActivityRule', {activityId: this.teamActiveId}).then((result) => {
          let res = result.data
          if (res.code === 0) {
            console.log(res.data)
            this.teamInfo = res.data.userInfo
            this.teamInfo.totalBetAmount = this.teamInfo.teamConfirmAmount + this.teamInfo.personalConfirmAmount // 总投注额=团队+个人
            this.teamConfig = res.data.sixActivityRule
            this.precondition = res.data.precondition
          } else {
            this.$Modal.al_default({status: 'warning', content: res.message})
          }
        })
      },

      // 改变粘贴的文本
      changeCopyText(){
        this.copyText && this.scan && (this.copyText = this.copyText.replace(/X+/,this.scan))
      },

      // 点击复制按钮
      copyClick(e){
        let ele = e.target
        let text = ele.innerHTML
        if($(ele).hasClass('noClick')) return // 不让多次点击
        this.copy(this.copyText,()=>{
          ele.innerHTML = '复制成功'
          $(ele).addClass('success noClick')
          setTimeout(()=>{
              ele.innerHTML = text
              $(ele).removeClass('success noClick')
          },2000)
        })
      },
      // 生成海报
      creatPoster() {
        this.poster = true
        // 将海报图拼接成一张整体  方便用户下载
        this.$nextTick(function () {
          // 生成组合图片
          let obj = this.$refs['superPartner_download'] // 这里是要截屏的dom
          let that = this
          html2canvas(obj).then(function (canvas) {
            that.realImageSrc = canvas.toDataURL("image/png") // 这里生成 图片的下载地址
          })
        }.bind(this))
      },


      init(){
        this.findCopy() // 获取复制的文案
        this.findScan() // 查询代理的扫码地址
        // this.findTeamNum() // 查询当前团队人数
        this.findTeamActivity() // 获取团队中心的活动id  --团队中心相当于一个活动
      }
    },
    created() {
      this.init()
    },
    mounted() {
    },
  }
</script>

<style lang='less' scoped>
  @import "./../../css/global.less";
  .teamOverview {
    width: 100%;
    height: 100%;
    .top,.content{
      width: 100%;
      .bor(@userCent_bor);
      .label{
        padding-left: 10px;
        height: 34px;
        display: flex;
        justify-content: left;
        align-items: center;
        border-bottom: 1px solid @userCent_bor;
        background: @userCent_bac;
        color: #333;
        font-size: 16px;
      }
    }
    .top{
      margin-bottom: 20px;
      .box{
        height: 188px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        >div{
          height: 100%;
          width: 34%;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          &:nth-child(2){
            border-left: 1px solid @userCent_bor;
            border-right: 1px solid @userCent_bor;
          }
        }
        .left{
          .photo{
            img{
              width: 110px;
              height: 94px;
            }
          }
          .text{
            font-size: 20px;
            color: #666;
            margin: 5px 0;
          }
          .num{
            span{
              color: #59acf9;
              border-bottom: 1px solid #59acf9;
              cursor: pointer;
              font-size: 14px;
              display: inline-block;
              height: 18px;
            }
          }
        }
        .center{
          >div{
            height: 50%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 0 50px;
            &:first-child{
              border-bottom: 1px solid @userCent_bor;
            }
          }

          .num{
            color: @themeColor;
            font-size: 16px;
            margin-bottom: 5px;
          }
          .text{
            font-size: 14px;
            color: #666;
            cursor: pointer;
          }
        }
        .right{
          display: flex;
          flex-direction: row;
          justify-content: center;
          align-items: center;
          .photo{
            width: 120px;
            height: 120px;
            overflow: hidden;
            >*{
              margin-left: -17px;
              margin-top: -17px;
            }
          }
          .btn{
            margin-left: 10px;
            width: 120px;
            height: 120px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            label{
              font-size: 22px;
              color: #666;
            }
            span{
              width: 100%;
              height: 34px;
              border-radius: 4px;
              display: flex;
              justify-content: center;
              align-items: center;
              color: #fff;
              font-size: 16px;
              cursor: pointer;
            }
            .copy{
              background: #1fbfe2;

            }
            .poster{
              background: #ff958a;
            }
          }
        }
      }
    }
    .content{
      .box{
        max-height: 400px;
        overflow: auto;
        .al_scorll();
        margin-bottom: -1px;
        .item{
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: flex-start;
          width: 100%;
          height: 110px;
          border-bottom: 1px solid @userCent_bor;
          padding: 0 20px 0 10px;
          >div{
            width: 100%;
            height: 40px;
          }
          .text{
            font-size: 16px;
            color: #666;
            display: flex;
            justify-content: left;
            align-items: center;
          }
          .process{
            font-size: 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            .left{
              display: flex;
              justify-content: left;
              align-items: center;
              color: #666;
              width: calc(~"100% - 160px");
              span em{
                color: @themeColor;
              }
              b{
                display: flex;
                position: relative;
                width: 67%;
                height: 15px;
                background: #ededed;
                border-radius: 14px;
                margin: 0 15px 0 5px;
                box-shadow: -1px 1px 0px 0px #ccc inset;
                /*overflow: hidden;*/
                i{
                  position: absolute;
                  top: 0;
                  left: 0;
                  display: flex;
                  height: 100%;
                  background: linear-gradient(to right, #f98968, #f6474f);
                  border-radius: 14px;
                }
                .finished{
                  position: absolute;
                  right: -10px;
                  top: -8px;
                  text-decoration: none;
                  background: #fff;
                  border-radius: 50%;
                  box-shadow: 0px 0px 6px 1px #ccc;
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  width: 30px;
                  height: 30px;
                  em{
                    font-size: 12px;
                    color: #f54b50;
                  }
                }
              }
            }
            .right{
              span{
                width: 130px;
                height: 40px;
                display: flex;
                justify-content: center;
                align-items: center;
                color: #666;
                background: #cbcbcb;
                border-radius: 24px;
                cursor: default;
                &.finish{
                  /*background: #00cc66;*/
                  background: @themeColor_Sec;
                  color: #fff;
                }
                &.goBet{
                  background: @themeColor;
                  color: #fff;
                  cursor: pointer;
                }
                &.goShare{
                  background: #1fbfe2;
                  color: #fff;
                  cursor: pointer;
                }
                &.goShare{
                  background: #1fbfe2;
                  color: #fff;
                  cursor: pointer;
                }

              }
            }
          }

        }
      }
    }
    .bottom{
      height: 34px;
      display: flex;
      justify-content: left;
      align-items: center;
      font-size: 16px;
      color: #666;
      em{
        color: @themeColor;
        margin: 0 5px;
      }
    }
    .noClick{
      cursor: not-allowed !important;
    }
    .success{
      background: @themeColor_Sec !important;
    }
    .modal_poster {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(200, 200, 200, 0.5);
      z-index: 99;
      .box {
        position: relative;
        background: url("./img/team_poster.png");
        background-size: 100% 100%;
        width: 453px;
        height: 622px;
        margin: 160px auto;
        padding-top: 230px;
        font-size: 18px;
        color: #666;
        .close {
          background: url("./img/posterclose.png");
          width: 50px;
          height: 50px;
          top: -50px;
          right: -44px;
          border-radius: 50%;
          position: absolute;
          cursor: pointer;
        }
        .scanBox {
          width: 178px;
          background-size: 100%;
          border-radius: 21px;
          position: absolute;
          right: calc(~"50% - 90px");
          top: 278px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          .scan {
          }
          .save_btn {
            width: 178px;
            height: 40px;
            cursor: pointer;
            img{
              width: 100%;
              height: 100%;
            }
          }
        }
      }
    }
  }
</style>
