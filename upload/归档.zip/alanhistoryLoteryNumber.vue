<template>
  <div class="history">
    <div class="historyTop">
        <em class="icon_v3">&#xe6a7;</em>最近10期开奖号码
    </div>
    <div class="historybox">
      <div class="top">
        <div class="issue">期号</div>
        <div class="lotteryNumber">开奖号码</div>
        <div class="type" v-if="biggerType.search(/sscs|flb|jd/)>-1">{{zuTypeTop?zuTypeTop:""}}</div>
      </div>
      <ul class="content">
        <li  v-for="(v,i) in historyLotteryInfo" :key="i" v-if="i<10">
          <div class="issue">{{v.issue}}</div>
          <div class="lotteryNumberBox" v-if="(i===0&&v.code&&!ssc_openLotteryAnimation)||(i!==0&&v.code)">
            <div class="lotteryNumber" >
              <span v-for="(m,n) in v.code.split(',')" :key="n" :class="{'light':light[n]||biggerType==='pk10'||biggerType==='jd','pk10':biggerType==='pk10'}" v-if="light.length>0">{{m}}</span>
            </div>
          </div>
          <div v-else class="lotteryNumberBox">
            <div  class="lotteryNumber">等待开奖</div>
          </div>
          <div class="type" v-html="v.zuType" :style="`color:#${String(v.zuType).includes('龙')?'e74552':String(v.zuType).includes('虎')?'009267':String(v.zuType).includes('和')?'128beb':'666'}`" v-if="biggerType.search(/sscs|flb|jd/)>-1"></div><!--这里必须写v-html 因为组态会传html片段过来-->
        </li>
      </ul>
    </div>
    <div class="historyBottom"><a :href="currentLottery.id===250?'/trend':`/trendChart?id=${currentLottery.id}&w=1&q=50&chs=${currentLottery.showName}`" target="_blank">更多开奖号码>></a></div>
  </div>
</template>

<script>
	import {mapState, mapMutations, mapActions} from 'vuex';
	export default {
		props: ['historyLotteryInfo','zuTypeTop'],
		data() {
			return {
				light: [],// 点亮号码的状态
      }
		},
		computed: {
      ...mapState(['currentLottery', 'initStatus_history','biggerType','ssc_openLotteryAnimation']),

    },
		watch: {
			initStatus_history(){
				this.init()
      },
    },
		methods: {
			// 查找哪些需要点亮
			findLight(){
				let obj = {};
				// 寻找第一个code部位空的对象
				for(let val of this.historyLotteryInfo){
					if(val.code){
						obj = val
            break
					}
				}
        if(!obj.code) return  // 这里选择1  是因为当开奖的时候  第一个元素的code往往是null  所以取第二个元素的code
        this.light=[];
				for(let i=0;i<obj.code.split(',').length;i++) this.light[i] = false;
				let name = obj.oneMenu // 一级菜单的名字   根据一级菜单来控制点亮哪些球
        switch (name){
	        case '前五':this.changeStatus(0,5);break;
	        case '前四':this.changeStatus(0,4);break;
          case '四星':
          case '后四':this.changeStatus(-4);break;
	        case '三码':
          case '前三':this.changeStatus(0,3);break;
          case '中三':this.changeStatus(1,4);break;
          case '后三':this.changeStatus(-3);break;
	        case '二星':
          case '后二':this.changeStatus(-2);break;
          // case '龙虎':
          case '二码':
          case '前二':this.changeStatus(0,2);break;
          case '前一':this.changeStatus(0,1);break;
          default:
	          if(name==='龙虎'){
		          switch (obj.twoMenu){
			          case '万千':this.changeStatus(0,2);break;
			          case '万百':this.light[0]=true;this.light[2]=true;break;
			          case '万十':this.light[0]=true;this.light[3]=true;break;
			          case '万个':this.light[0]=true;this.light[4]=true;break;
			          case '千百':this.light[1]=true;this.light[2]=true;break;
			          case '千十':this.light[1]=true;this.light[3]=true;break;
			          case '千个':this.light[1]=true;this.light[4]=true;break;
			          case '百十':this.light[2]=true;this.light[3]=true;break;
			          case '百个':this.light[2]=true;this.light[4]=true;break;
			          case '十个':this.light[3]=true;this.light[4]=true;break;
			          default:
				          if(obj.twoMenu.includes('v')){
					          let b=obj.twoMenu.split('v')
					          this.light[Number(b[0])-1]=true;this.light[Number(b[1])-1]=true;
				          }else{
					          for(let j=0;j<obj.code.split(',').length;j++) this.light[j] = true;
				          }
				          break;
		          }
	          }else{
		          for(let j=0;j<obj.code.split(',').length;j++) this.light[j] = true;
	          }
          	break;
        }

      },
			// 改变状态 通过参数
			changeStatus(m, n) {
				!n && (n = this.light.length)
        m<0 && (m += this.light.length)
				for (let i = m; i < n; i++) this.light[i] = true
			},




			init(){
				this.findLight() // 查找哪些需要点亮
      }
    },
		created() {
			this.init()
		},
		mounted() {
		},

	}
</script>

<style lang='less' scoped>
  @import "../../css/global.less";
  .history {
    width: 100%;
    height: 580px;
    overflow: hidden;
    background: #fff;
    .historyTop{
      width: 100%;
      height: 40px;
      line-height: 40px;
      text-align: center;
      background: @methodBox_bor;
      font-size: 14px;
      em{
        color: #F7A421;

      }
    }
    .historybox {
      width: 100%;
      bottom: 0;
      display: -ms-flexbox;
      display: flex;
      -ms-flex-direction: column;
      flex-direction: column;
      height: 502px;
      overflow: hidden;
      .bor(@methodBox_bor);
      .top {
        height: 40px;
        background: #F8F8F8;
        color: @historyColor_Top;
        font-size: 14px;
        border-bottom: 1px solid @methodBox_bor;
        display: flex;
        justify-content: space-around;
        align-items: center;
        div{
          line-height: 40px;
          text-align: center;
          float: left;
          display: inline-block;
        }
        .issue {
          width: 36%;
        }
        .lotteryNumber {
          max-width: 72%;
          min-width: 34%;
        }
        .type{
          width: 22%;
        }
      }


      .content {
        height: calc(~"100% - 40px");
        overflow: auto;
        /*padding: 0 12px 0 15px;*/
        text-align: center;
        .al_scorll();
        font-size: 14px;
        >li {
          overflow: hidden;
          border-bottom: 0px solid #F7F7F7;
          height: 46px;
          border-bottom: 1px dashed @methodBox_bor;
          display: flex;
          justify-content: space-around;
          &:last-child{
            border-bottom:none;
          }
          .issue {
            line-height: 46px;
            float: left;
            text-align: center;
            color: @twoMenuColor_Sel;
            width: 36%;
            font-size: 12px;
          }
          .lotteryNumberBox{
            height: 100%;
            max-width: 72%;
            min-width: 34%;
            margin-top: 0;
            display: flex;
            justify-content: left;
            align-items: center;
            .lotteryNumber {
              display: flex;
              justify-content: space-around;
              align-items: center;
              width: 100%;
              span{
                display: flex;
                justify-content: center;
                align-items: center;
                width: 18px;
                height: 18px;
                margin: 0;
                font-size: 12px;
                border-radius: 50%;
                .bor(@methodBox_bor);
                overflow: hidden;
                &.light{
                  background-color:@themeColor;
                  color: #fff;
                  border: none;
                  line-height: 18px;
                }
                &.pk10:nth-child(1){background: #ffa200;}
                &.pk10:nth-child(2){background: #128beb;}
                &.pk10:nth-child(3){background: #ff6600;}
              }
            }
          }

          .type {
            float: left;
            color: @twoMenuColor_Lab;
            line-height: 46px;
            width: 18%;
          }
        }
      }
    }
    .historyBottom{
      height: 38px;
      line-height: 38px;
      width: 100%;
      border: 1px solid @methodBox_bor;
      border-top:none;
      font-size: 12px;
      color: @historyColor_Top;
      a{
        color: #888;
        &:hover{
          color: @themeColor_Sec;
        }
      }
    }
  }
</style>
































