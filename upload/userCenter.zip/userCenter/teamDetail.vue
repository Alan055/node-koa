<template>
  <div class="teamDetail">
    <div class="top">
      <div class="item">
        <span>用户名：</span>
        <input class="userName" type="text" v-model="userName" placeholder="请输入用户名">
      </div>
      <div class="item">
        <span class="search" @click="pagination_page=0,findData()">搜索</span>
        <span class="reset" @click="reset()">重置</span>
      </div>
    </div>
      <div class="table">
        <!--tableTop: 表格头部 ,tableContent: 表格内容 ,page_total:后台数据总条数 ,page_page: 当前第几页 ,
          page_pageTotal: 总共多少页 ,page_size: 一页显示多少条数据 ,page_change:点击分页时的事件，loading：是否在加载中状态-->
        <alan_table
          :tableTop="tableTop"
          :tableContent="tableContent"
          :page_page="pagination_page"
          :page_pageTotal="Math.ceil(pagination_total / pagination_size)"
          :page_total="pagination_total"
          :page_size="pagination_size"
          :page_change="pagination_change"
          :loading="loading">
          <ul class="tableTop">
            <li v-for="(v,i) in tableTop" :key="i">{{v}}</li>
          </ul>
          <ul class="tableContent" v-for="(v,i) in tableContent" :key="i" v-if="tableContent.length>0&&!loading">
            <li>{{v.cn}}{{v.cn==baseInfo.nickName?agentType:''}}</li>
            <li>{{v.confirm_amount}}</li>
            <li>{{v.award_amount}}</li>
            <li>{{v.rebound_amount}}</li>
            <li>{{v.total_reboun_amount}}</li>
          </ul>
          <!--<ul class="tableContent" v-if="dayTotal!== null">-->
            <!--<li>小计</li>-->
            <!--<li></li>-->
            <!--<li></li>-->
            <!--<li></li>-->
            <!--<li>{{dayTotal}}</li>-->
          <!--</ul>-->
          <!--<ul class="tableContent"  v-if="allTotal!== null">-->
            <!--<li>总计</li>-->
            <!--<li></li>-->
            <!--<li></li>-->
            <!--<li></li>-->
            <!--<li>{{allTotal}}</li>-->
          <!--</ul>-->
        </alan_table>
      </div>
  </div>
</template>

<script>
  import alan_table from "./alan_table";
  import service from "./../../js/service";
  import {mapState, mapMutations, mapActions} from 'vuex';



  export default {
    components: {alan_table},
    data() {
      return {
        userName: '', // 搜索用户名
        tableTop: ['用户名', '投注总额', '派彩总额', '今日收益', '总收益'], // 表格头
        tableContent: [], // 表格内容
        dayTotal: null, // 今日
        allTotal: null, // 总计
        load: false, // 是否出现正在加载中
        pagination_size: 10, // 一页的数据数
        pagination_total: 0, // 后台数据总数
        pagination_page: 0, // 当前页
        loading: false, // 加载中
      }
    },
    computed: {
      ...mapState(['baseInfo']),
      agentType(){
        let obj = ['会员','代理','总代理','股东','大股东']
        return this.baseInfo.mainAccount ? ` (${obj[this.baseInfo.mainAccount.userAgentType/0.005]})`: ''
      }
    },
    watch: {},
    methods: {
      // 点击分页按钮事件
      pagination_change(i) {
        // i是当前点击的页数，但我们后台是从0开始的  所以要减1
        this.pagination_page = i - 1
        this.findData() // 查询数据
      },

      // 获取表格的数据
      findData() {
        this.tableContent = [] // 初始化清空列表数据
        // 整理入参数据
        let obj = {
          cn: this.userName,
          page: this.pagination_page,
          size: this.pagination_size,
        }
        this.loading = true // 打开加载中
        service.postDefault(this, '/yx/api/sixZhouNianActivity/getTeamCentreDetailList', obj).then(function (result) {
          let res = result.data
          if (res.code === 0) {
            this.tableContent = res.data.list
            this.pagination_total = res.data.totalCount
            this.dayTotal = res.data.totalTodayReboundAmount
            this.allTotal = res.data.totalAllReboundAmount
          } else {
            this.$Modal.al_default({status: 'warning', content: res.message})
          }
          this.loading = false // 关闭加载中
        }, function (err) {
          console.log(err)
          this.loading = false // 关闭加载中
        })

        // this.tableContent = [
        //   {name: 'testalan', betAmount: '500.200', xxx: '500', aaa:'23.23',bbb: '456.51'},
        //   {name: 'testalan', betAmount: '500.200', xxx: '500', aaa:'23.23',bbb: '456.51'},
        //   {name: 'testalan', betAmount: '500.200', xxx: '500', aaa:'23.23',bbb: '456.51'},
        //   {name: 'testalan', betAmount: '500.200', xxx: '500', aaa:'23.23',bbb: '456.51'},
        //   {name: 'testalan', betAmount: '500.200', xxx: '500', aaa:'23.23',bbb: '456.51'},
        //   {name: 'testalan', betAmount: '500.200', xxx: '500', aaa:'23.23',bbb: '456.51'},
        //   {name: 'testalan', betAmount: '500.200', xxx: '500', aaa:'23.23',bbb: '456.51'},
        //   {name: 'testalan', betAmount: '500.200', xxx: '500', aaa:'23.23',bbb: '456.51'},
        // ]
        // this.pagination_total = this.tableContent.length
        // this.loading = false // 关闭加载中
      },
      // 重置
      reset(){
        this.userName = ''
      },


      init(){
        this.findData()
      }
    },
    created() {
      this.init()
    },
    mounted() {
    },
  }
</script>

<style lang='less' scoped>
  @import "./../../css/global";
  .teamDetail {
    height: 100%;
    .top{
      display: flex;
      justify-content: left;
      align-items: center;
      .item{
        height: 40px;
        display: flex;
        justify-content: left;
        align-items: center;
        color: #666;
        font-size: 14px;
        .userName{
          .bor(@userCent_bor);
          border-radius: 4px;
          width: 160px;
          height: 32px;
          padding-left: 10px;
          outline: none;
        }
        .search{
          height: 30px;
          border-radius: 16px;
          color: #fff;
          background: @themeColor;
          margin: 0 18px;
          display: flex;
          justify-content: center;
          align-items: center;
          padding: 0 20px;
          cursor: pointer;
        }
        .reset{
          cursor: pointer;
        }
      }
    }
    .table {
      position: relative;
      margin-top: 10px;
      height: calc(~"100% - 64px");
      ul {
        display: flex;
        justify-content: space-between;
        align-items: center;
        li {
          display: flex;
          justify-content: center;
          align-items: center;
          width: 20%;
          border-right: 1px solid #ccc;
          height: 36px;
          font-size: 14px;

          &:last-child {
            border-right: none;
          }
        }
      }
      .tableTop {
        background: #f6f6f6;
        border: 1px solid #ccc;
      }
      .tableContent {
        color: #666;
        border-left: 1px solid #ccc;
        border-right: 1px solid #ccc;
        li {
          border-bottom: 1px solid #ccc;
          border-right: 1px solid #ccc;
        }
      }
    }
  }
</style>
