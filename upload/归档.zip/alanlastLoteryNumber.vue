<template>
  <div class="lastLottery">
    <div class="title" @click="jump()">第 <span>{{historyLotteryInfoFirst.issue}}</span> 期 开奖结果</div>
    <div v-if="historyLotteryInfoFirst.code&&!ssc_openLotteryAnimation" class="code" :class="{'codePk10':name.search(/PK10|飞艇|赛车/i)>-1,'lhc':name.includes('六合彩')}">
      <ul class="ballsBox">
        <li v-for="(v,i) in historyLotteryInfoFirst.code.split(',')" :key="i">{{v}}
          <img :src="`/static/img/lottery/icon_pk${i}_map.png`" v-if="i<3&&name.search(/PK10|飞艇|赛车/i)>-1" class="map" alt="">
        </li>
      </ul>
      <ul class="zodiac" v-if="name.includes('六合彩')&&zodiac.length">
        <li v-for="(v,i) in zodiac" :key="i" v-if="v">{{v.text}}</li>
      </ul>
    </div>
    <div class="waitBox" v-else>
      <div class="wait"></div>
    </div>
  </div>
</template>

<script>
	import {mapState, mapMutations, mapActions} from 'vuex';
	import lhc from "./js/lhcData.js";// 生肖的数据

	export default {
		props: ['name'],
		data() {
			return {
				openLotterting: '',
			}
		},
		computed: {
			...mapState(['biggerType', 'historyLotteryInfoFirst','ssc_openLotteryAnimation']),
			zodiac(){// 生肖的数据
				if(!this.name.includes('六合彩')||!this.historyLotteryInfoFirst.code) return []
        let arr = [];// 开奖号码对应的生肖池 比如1，2，3，4  是龙
				let data = lhc.lotteryData.lhc.find(e=>(e.parentType === 'sx'))
        for(let val of data.list){
	        arr=arr.concat(val)
        }
        let codeArr = this.historyLotteryInfoFirst.code.split(',');// 开奖号码
        let zodiacArr = []
        for(let val of codeArr){
	        zodiacArr.push(arr.find(e=>(e.type.split(',').find(e=>(parseInt(e) == val)))))
        }
        return zodiacArr
      }
		},
		methods: {
			//跳转到走势图
			jump() {
				// this.$Modal.al_openLottery_ssc({openCode: '12345'})
				// window.open(window.location.origin+'/static/lottery-trend.html?id=911&w=1&q=50&chs='+this.name)
			},
			// 相加
      add(v){
				let a = 0
        for(let val of v.split(',')){
        	a += Number(val)
        }
        return a
      }
		},
		created() {
		},
		mounted() {
		},
		watch: {}
	}
</script>

<style lang='less' scoped>
  /** 尾部样式结束 **/
  @-webkit-keyframes twinkling {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }

  @keyframes twinkling {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }

  .openLotteryingURL(@num) {
    @Num: -16 - @num * 85px;
    background-position: 0px @Num;
  }

  @keyframes openLotterying {
    0% {
      background-position: 0px 0px;
    }
    100% {
      background-position: 0px -1785px;
    }
  }
  @keyframes openLotterying_1024 {
    0% {
      background-position: 0px 0px;
    }
    100% {
      background-position: 0px -1680px;
    }
  }

  .lastLottery {
    display: inline-block;
    vertical-align: top;
    padding-top: 19px;
    box-sizing: border-box;
    text-align: center;
    border-right: 1px solid #F53B4A;
    width: 441px;
    height: 100%;
    .title {
      position: relative;
      color: #fff;
      font-size: 14px;
      span {
        color: #fdcd0a;
      }
    }
    .code {
      display: table;
      height: calc(~"100% - 21px");
      margin: 0 auto;
      ul {
        margin: 0 auto;
        /*display: table-cell;*/
        /*vertical-align: middle;*/
        /*padding: 0 38px;*/
        li {
          float: left;
          width: 64px;
          height: 64px;
          line-height: 64px;
          margin: 0 4px;
          background: url("./lotteryImg/bg_number.png") no-repeat 1px 0;
          background-size: 100% 100%;
          border-radius: 50%;
          color: #fff;
          font-size: 26px;
          text-align: center;
          visibility: visible;
          font-weight: 900;
        }
      }

    }
    .lhc{
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      .ballsBox{
        padding: 0;
        li{
          width: 56px;
          height: 56px;
          line-height: 56px;
          margin: 0;
          position: relative;
          margin-right: 6px;
          font-size: 24px;
          &:before{
            position: absolute;
            content: '+';
            right: -14px;
            top: -2px;
          }
          &:last-child{
            &:before{
              display: none;
            }
          }
          &:nth-child(6){
            &:before{
              content: '=';
            }
          }
        }
      }
      .zodiac{
        padding: 0;
        height: 28px;
        li{
          width: 48px;
          height: 28px;
          background: none;
          line-height: 28px;
          margin-right: 10px;
          font-size: 18px;
          font-weight: 400;
        }
      }
    }
    .codePk10 {
      width: 100%;
      display: flex;
      align-items: center;
      ul {
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 0;
        li {
          width: 42px;
          height: 42px;
          line-height: 42px;
          padding-left: 2px;
          font-size: 20px;
          margin: 0;
          position: relative;
          background-image: url("./lotteryImg/icon_pk_normal.png");
          &:nth-child(1){background-image: url("./lotteryImg/icon_pk1.png");}
          &:nth-child(2){background-image: url("./lotteryImg/icon_pk2.png");}
          &:nth-child(3){background-image: url("./lotteryImg/icon_pk3.png");}
          .map{
            position: absolute;
            top: -12px;
            left: 10px;
          }
        }
      }

    }
    .waitBox {
      width: 78%;
      height: 66%;
      margin: 0 auto;
      .wait {
        width: 342px;
        height: 85px;
        animation: openLotterying 0.6s steps(21) infinite;
        background-repeat: no-repeat;
        background-image: url("./lotteryImg/lottery_open.png");
      }
    }

  }

  @media screen and (max-width: 1024px) {
    .lastLottery {
      .code {
        margin: 0 auto;
        ul {
          padding: 0 !important;
        }
      }
      .waitBox{
        .wait{
          width: 284px;
          height: 80px;
          animation: openLotterying_1024 0.6s steps(21) infinite;
          background-repeat: no-repeat;
          background-image: url("./lotteryImg/lotter_open1024.png");
        }
      }
      .lhc{
        .ballsBox{
          li{
            width: 46px;
            height: 46px;
            font-size: 18px;
            line-height: 46px;
            &:before{
              right: -9px;
            }
          }
        }
        .zodiac{
          li{
            width: 38px;
          }
        }
      }
    }
  }
</style>
