<template>
  <div class="fundStatus">
    <div class="top"><img src="./img/ic_zijin.png" alt="">资金状态</div>
    <div class="content" v-if="funds.length">
      <div v-for="(v,i) in funds" :key="i">
        <span class="label">{{v.label}}</span>: <span class="num">{{v.num?v.num.toFixed(2):'0.00'}}</span> 元
      </div>
    </div>
  </div>
</template>

<script>
	export default {
		props: ['funds'],
		data() {
			return {}
		},
		computed: {},
		watch: {},
		methods: {},
		created() {
		},
		mounted() {
		},
	}
</script>

<style lang='less' scoped>
  @import "./../../css/global.less";

  .fundStatus {
    display: flex;
    flex-direction: column;
    justify-content: left;
    .bor(@userCent_bor);
    > div {
      display: flex;
      justify-content: left;
      align-items: center;
      padding-left: 10px;
    }
    .top {
      height: 36px;
      background: @userCent_bac;
      border-bottom: 1px solid @userCent_bor;
      color: #333;
      font-size: 16px;
      img {
        margin-right: 10px;
      }
    }
    .content {
      height: 40px;
      > div {
        padding: 0 20px;
        border-left: 1px dashed @userCent_bor;
        font-size: 14px;
        color: #666;
        &:first-child {
          padding-left: 0;
          border: none;
        }
        .label {
          color: #333;
        }
        .num {
          color: @themeColor;
        }
      }
    }
  }
</style>