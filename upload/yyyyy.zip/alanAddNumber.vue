<template>
  <div class="addNumber">
    <div v-for="(v,i) in btn" :class="{'prohibit':i===0&&number_tableData.length>0,'noClick':note===0}" :key="i" @click="note>0&&v.click()">
      <em class="icon_v3" v-html="v.icon"></em>
      <span>{{v.text}}</span>
    </div>
  </div>
</template>

<script>

	import lotteryComment from "./js/common.js";//引入投注模块公共方法
	import {mapState, mapMutations, mapActions} from 'vuex';
	import lottery_calc from "./js/lottery_calc.js";//引入彩种计算函数
	import {LZString} from "./../../js/common.js";//引入公共方法

	var compressStr = LZString();

	export default {
		data() {
			return {
				btn: [
					{text: '快速投注', icon: '&#xe6cc;', click: this.immediatelyBetting},
					{text: '添加号码', icon: '&#xe6af;', click: this.addNumber},
				],
				modal_bettingNow: false,//快速投注模态框
				maxBouns: 0,//点击投注时弹框的最高限额值

			}
		},
		computed: {
			...mapState([
				'issue', // 当前即将开奖的期号
				'biggerType',//最大的彩种类型  sscs jd flb other elvenY dpc
				'currentLottery',//当前选中的彩种大类  包含中文名字  英文名字  id  三个属性  cqssc 重庆时时彩 11
				'openTime',//openTime  --倒计时
				'currentPlayInfo',//当前玩法的信息，确定投注的时候  可以使用 shortname compress
				'note',//note  --注数
				'chooseNumberData',//chooseNumberData  --选号区的所有数据，这里用于计算出实际投注所展示的选号数据
				'shortName',//shortName  --当前玩法的缩写名字，这里用于计算出实际投注所展示的选号数据  和chooseNumberData一起作为参数
				'multiple',//选注栏的倍数
				'mode',//选注栏的模式  元角分厘
				'total',//选注栏的总金额
				'bonus',//选注栏的进度条   实际是奖金
				'percent',//选注栏的进度条  百分比
				'lottery_method',//当前玩法的彩种（最小一级 如：name五星直选复式 bonus 2000），用于点击投注的时候展示在表格中  还有我要追号的利润率追号
				// 'lottery_type',//当前玩法的类型 比如   五星直选复式
				// 'lottery_Bonus',//当前玩法的彩种奖金 --用于在点击添加号码的时候  显示金额
				'initStatus',//这个状态用来初始化选号区的数据，当我们点击投注或者预投注的时候   改变这个状态，在选号区监听，然后初始化
				'initStatus_tableRecord',//这个状态用来刷新订单记录组件的表格数据  监听其改变时的状态来刷新表格
				'lotteryConfig', //当前玩法的一些配置值
				'number_tableData',//购彩篮里面表格的数据 如果有数据就不能快速投注
			]),
		},
		watch: {},
		methods: {
			...mapMutations(['setData', 'addItem','bonusPool_glodClass']), //在表格上添加数据
			...mapActions(['ajaxBetting']),//快速投注和确认投注的ajax事件
			//快速投注  点击事件
			immediatelyBetting() {
				//购彩篮里面表格的数据 如果有数据就不能快速投注
				if (this.number_tableData.length > 0) return
				// 是否投注弹框
				this.note > 0 ? this.$Modal.al_bettingNow({
					title: '快速投注',
					onOk: this.sendImmediatelyBetting
				}) : this.$Modal.al_default({status: 'warning', content: '您还没有选择号码'})
			},
			//快速投注 出来的模态框确认事件  --模态框点击确定的事件
			sendImmediatelyBetting() {
				//传过去的数据必须是数组的json格式
				let arr = []
				let betStr = this.calcNumber();//选号的数据
				let betArr = betStr.split('|');// 需要分割成数组  龙虎的玩法都是要分割成单个的投注的
				for (let val of betArr) {
					arr.push({
						lottery: this.currentLottery.code,//彩种大类的英文名字  cqssc
						issue: this.issue,//期号
						method: this.shortName,//当前玩法的简写code
						content: val,
						model: this.moneyTranslation[this.mode].text,//选中的钱   元角分厘 要转换成拼音
						multiple: this.multiple,//倍数
						code: this.bonus,//滑块（进度条）的奖金数
						compress: false//这个不知道   翻译是压缩   --原js里面写死的false
					})
				}
				this.ajaxBetting({that: this, arr: arr, class:'.alan_lottery .chooseNumBox .note .addNumber div:nth-child(1)'}); // class是记录当前点击快速投注按钮的class
			},
			//计算当前选中的号码  处理成能发送给后台的格式  "-,-,2,3,4"
			calcNumber() {
				let calc = lottery_calc['lottery_' + this.biggerType]

				return calc().inputFormat(this.shortName, this.chooseNumberData)
			},

			//添加号码点击事件
			addNumber() {
				/*
				* 先取到注数栏的数量（note），判断是否大于0，如果大于0才可以添加号码
				* 然后取到选中的号码，展示在表格中，这个是预投注状态
				* 取投注号码的时候，需要计算一下，通过lottery_calc.js里面的计算函数，传参（玩法shortname，bigarr-选号数据）
				 */
				let that = this
				if (this.note > 0) {
					// 这里的逻辑说明一下，如果选中的注数太多  就不是单挑玩法，也不会弹框
					if (this.note <= this.lottery_method.oooNums) {
						this.maxBouns = lotteryComment.calc_maxBouns(this.currentLottery.id, this.biggerType)
						this.$Modal.al_default({
							status: 'confim',
							content: '您所投注内容属于单挑玩法，最高奖金为<span style="color:#ffdb02">' + that.lottery_method.oooBonus + '元</span>，确认继续投注？',
							onOk() {
								that.addNumber_forTable()
							}
						})

						// this.$Modal.confirm({
						// 	title: '提示',
						// 	content: '<p></p>',
						// 	// content: '<p>您所投注内容属于单挑玩法，最高奖金为' + that.maxBouns + '元，确认继续投注？</p>',
						// 	okText: '确定',
						// 	cancelText: '取消',
						// 	onOk() {
						// 		that.addNumber_forTable()
						// 	}
						// });
					} else {
						that.addNumber_forTable()
					}
				} else {
					that.$Modal.al_default({status: 'warning', content: '您还没有选择号码'})
				}

				// 测试的时候打开下面的
				// console.log(this.note);
				// console.log(calc().inputFormat(this.shortName,this.chooseNumberData));
				// console.log(this.name)
				// console.log(this.multiple)
				// console.log(this.mode)
				// console.log(this.total)
				// console.log(this.bonus)
				// console.log(this.percent)
				// console.log(this.lottery_method.name)
			},
			//将号码添加到与投注的表格中

			addNumber_forTable() {
				let that = this;
				//向表格内容里面添加数据
        let calcNumber = this.calcNumber()
				that.addItem({
					bigType: that.currentLottery.showName,//中文名字  如重庆时时彩
					smallType: that.lottery_method.name, //玩法名称  从后台映射表里面来  如 后三码直选复式
					//选号的数据（计算后） 如 -,-,2,3,4
					//这里如果是单式玩法 手写的数据大于1000注  且玩法里面需要压缩的话  调用函数将str压缩
					chooseNumber: that.currentPlayInfo.compress && that.note >= 1000 ? compressStr.compressToEncodedURIComponent(calcNumber) : calcNumber,
          show_chooseNumber: calcNumber,// 这个用于在购彩篮显示数据  不压缩   压缩了就看不了了
					multiple: that.multiple,//倍数
					mode: that.mode,//元角分厘  模式
					note: that.note,//注数
					total: that.total,//总计金额
					process: that.bonus + '/' + that.percent, //进度条的数据

					//!--以上都是要展示在表格中的数据  下面是提交投注时所需要的一些字段 -->
					lottery: that.currentLottery.code, //彩种大类的英文名字  cqssc
					bonus: that.bonus,//进度条滑块  前面的奖金数
					shortName: that.shortName,//当前玩法的简写名字 code
					// compress: that.currentPlayInfo.compress ? true : false,//当前玩法信息里面的compress  没有的话 就是false
					compress: that.currentPlayInfo.compress && that.note >= 1000 ? true : false,
				})
				//选号提交（投注  追号  添加号码等）之后，需要刷新选号区的数据
				/*
        * 添加完数据之后，需要将选号区的数据清空
        * 这个用vuex来做，给个状态，在选号区监听，当其状态改变的时候  就清空数据
         */
				this.setData({key: "initStatus", value: !this.initStatus})
			},


		},
		created() {
		},
		mounted() {
		},
	}
</script>

<style lang='less' scoped>
  @import "../../css/global.less";

  .addNumber {
    width: 292px;
    float: right;
    height: 100%;
    display: flex !important;
    align-items: center;
    > div {
      display: inline-block;
      width: 130px;
      height: 40px;
      line-height: 40px;
      color: #fff;
      text-align: center;
      border-radius: 20px;
      overflow: hidden;
      cursor: pointer;
      &.noClick{
        cursor: not-allowed;
        background: #ccc !important;
      }
      em {
        font-size: 16px;
      }
      span {
        font-size: 14px;
        vertical-align: top;
      }
      &:first-child {
        background: @themeColor;
      }
      &:last-child {
        margin-left: 18px;
        background: @themeColor_Sec;
      }
      &.prohibit {
        cursor: not-allowed;
        background: #ccc;
      }
    }

  }
</style>
