<template>
  <div class="user-warpper" :class="'skin'+skin">
    <div class="warpper">
      <div class="centerNav fl">
        <div class="user-title">
          <div>
            <div class="userIcon">
              <img  src="../../img/user/icon_youxiang.png" v-if="!skin" />
              <img  src="/static/img/spring/icon_youxiang.png" v-else/>
            </div>
            <div class="userTime">{{baseInfo.userTime}},{{baseInfo.nickName}}</div>
          </div>
        </div>
        <div v-for="(v,i) in Menu" :key="i" class="userCenter" v-if="v.one=='团队中心'?baseInfo.mainAccount&&baseInfo.mainAccount.userAgentType:true">
          <div class="userCenter-title" :class="{'active':MenuIndex===i}" @click="MenuIndex!==i&&(MenuIndex=i,jump(v))">
            <i class="icon_v3" v-html="v.icon"></i><span>{{v.one}}</span><i class="icon_v3 iconRight">&#xe704;</i>
          </div>
          <div class="userCenter-nav" v-show='MenuIndex===i'>
             <!-- <div class="title-nav" v-if="MenuIndex===i"></div> 小三角-->
            <p v-for="(m,n) in v.two" :key="n" :class="{'twoActive':MenuIndex===i&&twoIndex===n}"
                    @click="MenuIndex=i,twoIndex=n,setBreadFn()" v-if="m.show?m.show:vuex_show(m.label)">
              <router-link :to="root_userCenter+m.url">{{m.label}}</router-link>
            </p>
          </div>
        </div>

      </div>

      <div class="centerMain fl">
        <div class="break">
          <breadNav></breadNav>
        </div>
        <div class="content">
          <router-view></router-view>
          <a target="_blank" :href="bindInfo.vipChannelUrl" v-if="bindInfo.vipFlag=='true'" v-show="rechargevip" style="float:right"><img src="/static/img/kefu_gif.gif" alt="充值vip客服" style="width:300px;height:282px;"></a >
        </div>

      </div>
    </div>
  </div>
</template>

<script>
	import {mapState, mapMutations, mapActions} from 'vuex';
	import breadNav from "./breadNav.vue";// 面包屑组件
	import {updaAccoutStatus} from "./../../js/index.js";



	export default {
		data() {
			return {
        userTime:'',  //下午好。。。
				Menu: [ // value用于面包屑展示的名称
					{
						one: '个人中心', icon: '&#xe706;', two: [
							{show: true, label: '账户总览', value:'账户总览', url: '/userOverview',arr:[]},
							{show: true, label: '账户信息', value:'账户信息', url: '/userDetail',arr:['userPhone','addCard','fundsPass']},
							{show: false, label: '超级合伙人', value:'超级合伙人', url: '/superPartner',arr:[]},
							{show: true, label: '我的消息', value:'我的消息', url: '/userMessages',arr:[]},
						],
					},
					{
						one: '财务中心', icon: '&#xe707;', two: [
							{show: true, label: '充值', value:'充值方式', url: '/recharge',arr:['rechargeInfo']},
							{show: true, label: '提现', value:'提现', url: '/withdraw',arr:[]},
							{show: true, label: '转账', value:'转账', url: '/transfer',arr:[]},
						],
					},
					// {
					// 	one: '任务中心', icon: '&#xe703;', two: [
					// 		{label: '任务大厅', value:'任务大厅', url: '/task',arr:[]},
					// 	],
					// },
					{
						one: '报表中心', icon: '&#xe701;', two: [
							{show: true, label: '资金记录', value:'资金记录', url: '/fundsOrder',arr:[]},
							{show: true, label: '投注记录', value:'投注记录', url: '/betOrder',arr:[]},
							{show: true, label: '追号记录', value:'追号记录', url: '/chaseOrder',arr:[]},
							{show: true, label: '盈亏报表', value:'盈亏报表', url: '/ProfitLoss',arr:[]},
							{show: false, label: '奖金池', value:'奖池号码', url: '/bonusPool',arr:[]},
						],
					},
          {
            one: '团队中心', icon: '&#xe623;', two: [
              {show: true, label: '团队总览', value: '团队总览', url: '/teamOverview', arr: []},
              {show: true, label: '团队详情', value: '团队详情', url: '/teamDetail', arr: []},
              {show: true, label: '团队投注记录', value: '团队投注记录', url: '/teamBetRecord', arr: []},
            ],
          }
				],
				MenuIndex: 0,// 当前菜单的选项 一级
				twoIndex: 0,// 当前菜单的选项 二级
			};
		},
		components: {breadNav},
		computed: {
			...mapState([
        'root_userCenter',// 个人中心根路由
        'baseInfo',
        'rechargeGuide',
        'bindInfo', //取vip 客服链接
        'superPartner_show', //取vip 客服链接
        'bonusPool_id', // 奖金池活动的活动id  监听这个，如果变化就去调一下奖金池活动的接口 看看是否开启了活动来判断是否打开奖金池的报表
        'isShow_bonusPool', // 是否打开奖金池报表
        'skin',

			]),
			// 默认出现,切换路由时会消失 vipFlag 变量类型是  string
			rechargevip(){
				return  this.$route.name === this.Menu[1].two[0].url.replace('/','')
      },

		},
    watch:{
	    baseInfo(){
		    !this.rechargeGuide&&this.baseInfo.nickName&&this.getRechargeGuide()// 初始化充值引导-从缓存中读取  并存在vuex中

      },
	    $route(cur){
		    this.findCurrentRouter()
	    },
      bonusPool_id(){
	      this.bonusPool_id && this.isOpen_bonusPool(this)
      },
    },
		methods: {

			...mapMutations(['setData','setBread','setBreadMore','getRechargeGuide']),
      ...mapActions(['findBankList','isOpen_superPartner','isOpen_bonusPool']),
      // 在vuex中查询是否开启这个报表
      vuex_show(label){
			  switch (label) {
          case '奖金池': return this.isShow_bonusPool;
          case '超级合伙人': return this.superPartner_show;
        }
      },
			// 调整路由
			jump(v) {
				if(v.two) { // 说明点击的是一级菜单  -要吧二级菜单给置位第一个
					this.$router.push({path: this.root_userCenter + v.two[0].url})
					this.twoIndex = 0;
				}else{ // 点击的是二级菜单
					this.$router.push({path: this.root_userCenter + v.url})
				}
        this.setBreadFn()
			},
			// 检测当前是哪个页面
			findCurrentRouter() {
        // 使用页面url来判断
				let url = location.pathname
				let num = url.split('/')
				if (num === 2) {
					// 说明当前路由是  /userCenters    所以默认一级和二级菜单都是0
					this.MenuIndex = 0;
					this.twoIndex = 0;
					this.setBreadFn()
				} else {
					// 说明当前路由是  /userCenters/xxxx  所以需要去寻找一级和二级路由
					let oneI = 0;
					for (let val of this.Menu) {
						let twoI = 0;
						for (let str of val.two) {
							if (url.indexOf(str.url)!=-1||str.arr.find(e=>(url.indexOf(e)!=-1))) {
								this.MenuIndex = oneI;
								this.twoIndex = twoI;
                this.setBreadFn()
								return
							}
							twoI++
						}
						oneI++;
					}
				}
			},
			// 写入面包屑
      setBreadFn(){
				this.setBread([
					{label:this.Menu[this.MenuIndex].one},
					this.Menu[this.MenuIndex].two[this.twoIndex]
				])
        this.setBreadMore([])
      },
			init() {
				this.findCurrentRouter(); // 检测当前是哪个页面
        this.baseInfo.nickName&&this.getRechargeGuide() // 初始化充值引导-从缓存中读取  并存在vuex中
				updaAccoutStatus(this) // 更新用户账户状态
        this.findBankList(this) // 获取银行卡（下拉选项，最多卡数等）相关信息
        this.isOpen_superPartner(this) // 从后台查询  是否打开超级合伙人的入口
        this.bonusPool_id && this.isOpen_bonusPool(this) // 从后台查询  是否打开奖金池报表的入口

      }
		},
		created() {
			this.init();

		}
	}

</script>
<style lang="less" scoped>
  @import "../../css/global.less";

  .user-warpper {
    width: 100%;
    min-height: 700px;
    background: #F2F2F2;
    overflow: hidden;
    > .warpper {
      width: 95%;
      max-width: 1200px;
      min-width: 950px;
      height: 800px;
      margin: 0 auto;
      margin-top: 126px;
      margin-bottom: 20px;
      /*overflow: hidden;*/
      background: #fff;
      border: 1px solid @methodBox_bor;
      .centerNav {
        width: 18%;
        // cursor: pointer;
        display: flex;
        flex-direction: column;
        justify-content: start;
        // justify-content: space-between;
        height: 100%;
        .user-title{
          height:140px;
          display: flex;
          justify-content: center;
          align-items: center;
          >div{
            width: 100%;
            height: 100%;
            overflow: hidden;
            color:#666666;
            .userIcon{
              width: 79px;
              height: 76px;
              text-align: center;
              margin: 0 auto;
              display: flex;
              justify-content: center;
              align-items: center;
              overflow: hidden;
              // background: #f53b49;
              border-radius: 50%;
              margin-top: 7%;
              em{
                font-size: 50px;
                color: #fff;
              }
            }
            .userTime{
              color: #666666;
              font-size: 14px;
              margin-top: 12px;
            }
          }
        }
        .userCenter {
          // height: 25%;
          .userCenter-title {
            width: 100%;
            height: 55px;
            background: #fff;
            text-align: center;
            line-height: 55px;
            cursor: pointer;
            font-size: 16px;
            // border-bottom: 1px solid @methodBox_bor;
            .icon_v3 {
              color: @themeColor;
              font-size: 24px;
              vertical-align: bottom;
              margin-right: 20px;
            }
            .iconRight{
              font-size:16px;
              float: right;
              transform: rotate(-90deg);
            }
            &:hover {
              background: @themeColor;
              color: #fff;
              .icon_v3 {
                color: #fff;
              }
            }
          }
          .active {
            background: @themeColor;
            color: #fff;
            .icon_v3 {
              color: #fff;
            }
          }
          .userCenter-nav {
            width: 100%;
            /*max-width: 226px;*/
            /*min-height: 64px;*/
            // height: calc(~"100% - 70px");
            position: relative;
            background-color: #f5f5f5;
            transition: all 2s;
            .title-nav {
              // border-width: 8px;
              // border-style: solid;
              // border-color: transparent transparent #fff transparent;
              width: 33px;
              height: 10px;
              background: url('../../img/home/bnt_choose_a.png') no-repeat;
              position: absolute;
              top: -10px;
              left: 46%;
            }
            p {
              text-align: center;
              // height: 100%;
              display: flex;
              justify-content: center;
              flex-wrap: wrap;
              font-size: 16px;
              height: 44px;
              // span {
              //   display: flex;
              //   justify-content: center;
              //   align-items: center;
              //   width: 50%;
              //   height: 30px;
              //   font-size: 16px;
                a {
                  width: 100%;
                  height: 100%;
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  color: #666666;
                  &:hover {
                    color: @themeColor;
                  }
                }
                &.twoActive a {
                  color: @themeColor;
                  font-weight: bold;
                }
              // }
              .nowActive {
                color: @themeColor;
              }

            }
          }
        }
      }
      .centerMain {
        width: 82%;
        border-left: 1px solid @methodBox_bor;
        height: 100%;
        position: relative;
        z-index: 2;
        .al_scorll();
        padding: 0 20px;
        .break {
          height: 60px;
          line-height: 60px;
        }
        > .content {
          height: calc(~"100% - 60px");
          position: relative;
          >a{
            position: absolute;
            top: 450px;
            right: 10px;
          }
        }
      }
    }
  }
</style>
