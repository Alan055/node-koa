<template>
    <div class="alan_table">
      <div class="table">
        <!--这里面是表格头部和内容的插槽，为了让父组件自定义修改表格每个单元的宽度和高度 样式自定义！-->
        <slot></slot>
        <div class="noData" v-if="tableContent.length == 0 && !loading">
          <div class="picture"><em class="icon_v3">&#xe6a5;</em></div>
          <div class="txt">暂无数据</div>
        </div>
        <div class="loading" v-if="loading"><em class="icon_v3">&#xe6d6;</em>正在加载中</div>
      </div>
      <div class="tableBottom" v-show="tableContent.length>0">
        <span class="total">记录总数：<span>{{page_total}}</span>，页数：<span>{{page_page+1}}</span>/<span>{{page_pageTotal}}</span></span>
        <Page class="table_pagination" @on-change="page_change" :total="page_total" show-elevator
              :page-size="page_size"></Page>
      </div>
    </div>
</template>

<script>
	export default {
	  props:[
      'tableTop', // 表格头部
      'tableContent', // 表格内容
      'page_total', // 后台数据总条数
      'page_page', // 当前第几页
      'page_pageTotal', // 总共多少页
      'page_size', // 一页显示多少条数据
      'page_change', // 点击分页时的事件
      'loading', // 加载中
    ],
		data() {
			return {}
		},
		computed: {},
		watch: {},
		methods: {},
		created() {
		},
		mounted() {
		},
	}
</script>

<style lang='less' scoped>
  @import "./../../css/global.less";
  .alan_table{
    height: 100%;
    .table {
      margin-top: 10px;
      height: calc(~"100% - 64px");
      .noData {
        height: calc(~"100% - 40px");
        display: flex;
        flex-direction: column;
        justify-content: center;
        .picture {
          em {
            color: #888;
            opacity: 0.4;
            font-size: 52px;
          }
        }
        .txt {
          color: #888;
          font-size: 16px;
        }
      }
    }
    .tableBottom {
      position: absolute;
      bottom: 0px;
      padding: 10px 0;
      right: 20px;
      left: 20px;
      border: none;
      display: flex;
      align-items: center;
      justify-content: space-between;
      .total {
        span {
          color: @themeColor;
        }
      }
      .table_pagination {
        border: none;
      }
    }
    .loading{
      width: 100%;
      height: calc(~"100% - 30px");
      /*background: rgba(220, 220, 220, 0.6);*/
      top: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      color: #999;
      font-size: 16px;
      em {
        margin-right: 5px;
        font-size: 20px;
        display: flex;
        animation: tran 0.5s linear alternate infinite;
      }
    }
  }
</style>
