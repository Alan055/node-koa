// 数据词典

export default {
  // 性别
  gender: [
    {value: 0, text: '男'},
    {value: 1, text: '女'}
  ],


}
