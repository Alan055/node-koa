<template>
  <div class="downlast">
    <div class="title">第  <span>{{issue}}</span>  期<br>截止时间还有</div>
    <div class="time">
      <span>
        <i>{{timeArr[0]}}</i><b>:</b><i>{{timeArr[1]}}</i><b>:</b><i>{{timeArr[2]}}</i>
      </span>
    </div>
  </div>
</template>

<script>
	import {mapState, mapMutations,} from 'vuex';

	export default {
		props:['issue'],
		components:{},
		data() {
			return {
				timeArr:['00','00','00'],//时间展示
      }
		},
		computed: {
      ...mapState(['openTime'])
    },
		methods: {
			init(){
				this.timeArr=this.openTime.split('-')
      }
    },
		created() {
			this.init();
		},
		mounted() {
		},
		watch: {
			openTime(){
				this.init();
      }
    }
	}
</script>

<style lang='less' scoped>
  .downlast{
    text-align: center;
    position: relative;
    border-right: 1px solid #F53B4A;
    width: 304px;
    height: 100%;
    border-left: 1px solid #F53B4A;
    text-align: center;
    display: flex !important;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    .title{
      width: 100%;
      font-size: 14px;
      color: #fff;
      margin: 0 auto;
      span{
        color: #fdcd0a;
      }
    }
    .time{
      overflow: hidden;
      position: relative;
      margin: 0 auto;
      width: fit-content;
      margin-top: 12px;
      display: flex;
      justify-content: center;
      span{
        float: left;
        font-size: 30px;
        color: #999999;
        line-height: 31px;
        i{
          display: inline-block;
          vertical-align: top;
          height: 38px;
          line-height: 38px;
          color: #333;
          width: 49px;
          text-align: center;
          font-weight: normal;
          letter-spacing: 4px;
          text-indent: 4px;
          position: relative;
          z-index: 10;
          margin: 0 5px;
          background: url(./lotteryImg/timer_bg.png) no-repeat;
          background-size: 100% 100%;
        }
        b{
          color: #ffbec1;
        }
      }
    }
  }
</style>
