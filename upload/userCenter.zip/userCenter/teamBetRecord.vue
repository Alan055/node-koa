<template>
  <div class="teamBetRecord">
    <div class="top">
      <div class="item">
        <span>用户名：</span>
        <input class="userName" type="text" v-model="userName" placeholder="请输入用户名">
      </div>
      <div class="item">
        <span>时间：</span>
        <DatePicker type="daterange" :clearable="false" v-model="date" :options="dateLimit"
                    placement="bottom-end" placeholder="请选择查询日期"
                    style="width: 200px"></DatePicker>
      </div>
      <div class="item">
        <Select v-model="quickSelect" class="quickSelect" placeholder="快选" @on-change="quickSelectFn">
          <Option v-for="item in quickSelectArr" :value="item.value" :key="item.value">{{ item.label }}</Option>
        </Select>
      </div>
      <div class="item">
        <span class="search" @click="pagination_page=0,findData()">搜索</span>
        <span class="reset" @click="reset()">重置</span>
      </div>
    </div>

    <div class="table">
      <!--tableTop: 表格头部 ,tableContent: 表格内容 ,page_total:后台数据总条数 ,page_page: 当前第几页 ,
        page_pageTotal: 总共多少页 ,page_size: 一页显示多少条数据 ,page_change:点击分页时的事件，loading：是否在加载中状态-->
      <alan_table
        :tableTop="tableTop"
        :tableContent="tableContent"
        :page_page="pagination_page"
        :page_pageTotal="Math.ceil(pagination_total / pagination_size)"
        :page_total="pagination_total"
        :page_size="pagination_size"
        :page_change="pagination_change"
        :loading="loading">
        <ul class="tableTop">
          <li v-for="(v,i) in tableTop" :key="i">{{v}}</li>
        </ul>
        <ul class="tableContent" v-for="(v,i) in tableContent" :key="i" v-if="tableContent.length>0&&!loading">
          <li>{{v.cn}}</li>
          <li>{{v.lottery_name}}/{{v.method_name}}</li>
          <li>{{v.issue_no}}</li>
          <li>{{v.amount}}</li>
          <li>{{v.bonus}}</li>
          <li>{{v.lottery_status}}</li>
          <li>{{v.rebound_amount}}</li>
          <li>{{'已发放'}}</li>
        </ul>
        <ul class="tableContent" style="background-color: #f5f5f5;" v-if="tableContent.length">
          <li>小计</li>
          <li></li>
          <li></li>
          <li>{{al_fi(subtotal.totalAmount)}}</li>
          <li>{{al_fi(subtotal.totalBonus)}}</li>
          <li></li>
          <li>{{al_fi(subtotal.total_rebound_amount)}}</li>
          <li></li>
        </ul>
        <ul class="tableContent" style="background-color: #f5f5f5;" v-if="tableContent.length">
          <li>总计</li>
          <li></li>
          <li></li>
          <li>{{al_fi(total.total_amount)}}</li>
          <li>{{al_fi(total.total_bonus)}}</li>
          <li></li>
          <li>{{al_fi(total.total_rebound_amount)}}</li>
          <li></li>
        </ul>
      </alan_table>
    </div>

  </div>
</template>

<script>
  import alan_table from "./alan_table";
  import service from "./../../js/service";



  export default {
    components:{alan_table},
    data() {
      return {
        userName: '', // 搜索用户名
        date: [moment().add(0, 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')], // 当前选择的日期
        dateLimit: { // 控制时间选择器的可选时间长度
          disabledDate(date) {
            return date && (date.valueOf() > Date.now());
          }
        },
        // 快选
        quickSelectArr: [
          {label: '今日', value: '1'},
          {label: '三日', value: '3'},
          {label: '七日', value: '7'},
        ],
        quickSelect: '',// 当前选中的数据
        tableTop: ['用户名', '彩种/玩法', '期号', '投注额', '派奖额', '状态', '返点额', '返点状态'], // 表格头
        tableContent: [], // 表格内容
        subtotal: {}, // 小计
        total: {}, // 总计
        load: false, // 是否出现正在加载中
        pagination_size: 10, // 一页的数据数
        pagination_total: 0, // 后台数据总数
        pagination_page: 0, // 当前页
        loading: false, // 加载中
      }
    },
    computed: {
    },
    watch: {},
    methods: {
      // 点击分页按钮事件
      pagination_change(i) {
        // i是当前点击的页数，但我们后台是从0开始的  所以要减1
        this.pagination_page = i - 1
        this.findData() // 查询数据
      },

      // 获取表格的数据
      findData() {
        this.tableContent = [] // 初始化清空列表数据
        // 整理入参数据
        let obj = {
          cn: this.userName,
          createTime: moment(this.date[0]).format('YYYY-MM-DD')+' 00:00:00',
          updateTime: moment(this.date[1]).format('YYYY-MM-DD')+' 23:59:59',
          page: this.pagination_page,
          size: this.pagination_size,
        }
        this.loading = true // 打开加载中
        service.postDefault(this, '/yx/api/sixZhouNianActivity/getTeamBetList', obj).then(function (result) {
          let res = result.data
          if (res.code === 0) {
            this.tableContent = res.data.list
            this.pagination_total = res.data.totalCount
            this.subtotal = {
              totalAmount: 0,
              totalBonus: 0,
              total_rebound_amount: 0,
            }
            this.total = res.data.totalList[0]
            for(let val of res.data.list){
              this.subtotal.totalAmount += val.amount
              this.subtotal.totalBonus += val.bonus
              this.subtotal.total_rebound_amount += val.rebound_amount
            }
          } else {
            this.$Modal.al_default({status: 'warning', content: res.message})
          }
          this.loading = false // 关闭加载中
        }, function (err) {
          console.log(err)
          this.loading = false // 关闭加载中
        })
      },
      // 选择快选时
      quickSelectFn(i) {
        this.date = [moment().add(-(i - 1), 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')];// 当前选择的日期
      },

      // 重置
      reset(){
        this.userName = ''
        this.date = [moment().add(0, 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')] // 当前选择的日期
        this.quickSelect = ''
      },
      init(){
        this.findData()
      }
    },
    created() {
      this.init()
    },
    mounted() {
    },
  }
</script>

<style lang='less' scoped>
   @import "./../../css/global";
  .teamBetRecord {
    height: 100%;
    .top{
      display: flex;
      justify-content: left;
      align-items: center;
      .item{
        height: 40px;
        display: flex;
        justify-content: left;
        align-items: center;
        color: #666;
        font-size: 14px;
        margin-right: 5px;
        .userName{
          .bor(@userCent_bor);
          border-radius: 4px;
          width: 160px;
          height: 32px;
          padding-left: 10px;
          outline: none;
        }
        .search{
          height: 30px;
          border-radius: 16px;
          color: #fff;
          background: @themeColor;
          margin: 0 18px;
          display: flex;
          justify-content: center;
          align-items: center;
          padding: 0 20px;
          cursor: pointer;
        }
        .reset{
          cursor: pointer;
        }
      }
    }

    .table {
      position: relative;
      margin-top: 10px;
      height: calc(~"100% - 64px");
      ul {
        display: flex;
        justify-content: space-between;
        align-items: center;
        li {
          display: flex;
          justify-content: center;
          align-items: center;
          width: 20%;
          border-right: 1px solid #ccc;
          height: 36px;
          font-size: 14px;

          &:last-child {
            border-right: none;
          }
        }
      }
      .tableTop {
        background: #f6f6f6;
        border: 1px solid #ccc;
      }
      .tableContent {
        color: #666;
        border-left: 1px solid #ccc;
        border-right: 1px solid #ccc;
        li {
          border-bottom: 1px solid #ccc;
          border-right: 1px solid #ccc;
        }
      }
    }
  }
</style>
