<template>
  <div class="alanSwitch" v-if="currentStutas">
    <div v-for="(v,i) in tab" :key="i"
         :class="{'canClick':(currentStutas-1)!==i&&dictionary[currentStutas-1][currentLottery.id+''],'active':currentStutas===(i+1)}"
         @click="(currentStutas-1)!==i&&dictionary[currentStutas-1][currentLottery.id+'']&&jumpClick(i)">
      {{v.text}}
    </div>
  </div>
</template>

<script>
	import {mapState, mapMutations, mapActions} from 'vuex';

	export default {
		data() {
			return {
				tab: [{text: '官方', url: '/lottery/#'}, {text: '经典', url: '/lottery/#'}],
				currentStutas: 0,// 当前是什么官方玩法还是经典玩法  0代表暂时没有不加载
        // notClick: false,// 暂时不可点击
			}
		},
		computed: {
			...mapState(['currentLottery', 'biggerType']),
		},
		watch: {
			currentLottery() {
				this.init()
			},
			biggerType() {
				this.init()
			}
		},
		methods: {
			jumpClick(i) {
				if (this.currentStutas === 0) return
        // this.notClick = true
				this.$router.push({path: this.tab[i].url + this.dictionary[Math.pow(i - 1, 2)][this.currentLottery.id]})
        // setTimeout(function () {
        //   this.notClick = false
        // }.bind(this),2000)
			},

			init() {
				if (!this.currentLottery || !this.biggerType) return
				this.biggerType == 'jd' ? this.currentStutas = 2 : this.currentStutas = 1;
			}
		},
		created() {
			this.init()
		},
		mounted() {
		},
	}
</script>

<style lang='less' scoped>
  .alanSwitch {
    border-top-left-radius: 8px;
    border-bottom-left-radius: 8px;
    overflow: hidden;
    width: 40px;
    height: 140px;
    position: absolute;
    top: 198px;
    left: calc(~"50% - 644px");
    div {
      cursor: not-allowed;
      height: 70px;
      line-height: 40px;
      font-size: 16px;
      width: 100%;
      writing-mode: tb-rl;
      background: #3B3F42;
      color: #fff;
    }
    .canClick {
      cursor: pointer;
    }
    .active{
      background: #FFDE00;
      color: #333;
    }
  }
  @media screen and (max-width: 1024px){
    .alanSwitch{
      top: 48px;
      left: calc(~"50% - 490px");
    }
  }
</style>