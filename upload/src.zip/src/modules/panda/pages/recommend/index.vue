<template lang="html">
    <div class="view">
        <div class="c-layer" v-show="headerRgba == 0" v-if="homeData.apiFinish">
            <div class="pull-down-bg" :style='{height: activeHeight}'></div>
        </div>

        <div class="c-layer" v-show="headerRgba != 0">
            <c-header ref="transparentHeader" class="header transparent"
                      :style="`color: rgba(0, 0, 0, ${headerRgba}); background: rgba(255, 255, 255, ${headerRgba}); opacity: ${headerOpacity}`"
                      :title="appName2" :show="true">
            </c-header>
        </div>

        <div id="spaceDiv" style="display: block; height: 120vh;"></div>

        <scroller v-if="homeData.apiFinish" class="c-view-content" id="scrollerContent" :enableRefresh="true"
                  :on-refresh="refresh" :offset="120" :bounce="80" :maxScrollerHeight="160" :power="2"
                  @refreshFinsh="refreshFinsh" @onScroll="onScroll" @onPulling="onPulling">
            <div class="recommend-content">
                <div id="blockHeaderContent" class="block-header" ref="transparentBlock"></div>

                <div class="header-content">
                    <span class="center">
                        <img src="../../assets/images/header-logo@2x.png"/>
                    </span>
                    <span class="posi-r right" v-sina-ads='stat.recommend.message.mess'
                          @click="$root.openUrl(messageUrl);redIcon=false;">
                        <img class="c-icon icon_a" src="../../assets/images/message-white.png"/>
                        <span v-if="redIconShow"
                              :class="['red-icon', ['red-icon-one', 'red-icon-two', 'red-icon-three'][redIconCount.length - 1]]">{{redIconCount}}</span>
                    </span>

                    <broadcast :resdata="homeData"/>

                    <record class="section transparent-gap" :resdata="homeData" v-if="homeData.withdrawProducts"/>

                <!--    <newcards id="newCardContent" class="section" :resdata="homeData" v-if="homeData.newcards"
                    />-->


                </div>
            </div>

            <!-- 获取更多额度 -->
            <multi-apply id="multiApplyContent" class="section" :resdata="homeData" v-if="homeData"/>
            <offline-product class="section" :resdata="homeData"/>

            <!-- 贷超 -->
            <credit-card class="section iframe-section" :style="`height: ${creditCardHeight};`"
                         v-if="iframeUrl && isShowIframeUrl == 1" :iframeUrl="iframeUrl"/>
        </scroller>
        <rongze-dialog :visibility="homeData.xm_driverPopConfig != ''"
                       :data="homeData.xm_driverPopConfig"></rongze-dialog>


        <jitter v-if="jitterArgs.isShow" :start.sync="jitterArgs.isStart" @jitterClick="jitterClick" :icon="driver.xm_driverSuspensionWindowConfig.imgurl"/>
    </div>
</template>

<script>
    import record from "./components/record";
    import broadcast from "./components/broadcast";
    import offlineProduct from "./components/offlineProduct";
    import multiApply from "./components/multiApply";
    import secondRemittance from "./components/secondRemittance";
    import creditCard from "@/components/view/cMarket";

    import storage from "@/utils/storage";
    import scroller from "@/components/view/scroller";
    import helper from "@/utils/helper";
    import util from "@/utils";
    import api from "@/services/api";
    import EventBus from "@/services/EventBus";
    import {Toast, Indicator} from "@/utils/helper";

    import AppBridge from "@/services/AppBridge.js";
    import MaxentSDK from "@/services/MaxentSDK";

    import newcards from "./components/newcards";
    import jitter from "@/components/business/jitter";
    import {mapGetters, mapMutations, mapState} from "vuex";
    import rongzeDialog from "@/components/business/rongzeDialog";

    export default {
        data() {
            return {
                messageUrl: process.env.kingPath + "/pages/panda/#/message", //消息中心
                onlineServiceUrl: "",
                redIconShow: false,
                redIconCount: "0",
                isShowIframeUrl: util.getParams("isShowIframeUrl") || 0,
                pullDown: true,
                headerOpacity: 0,
                headerRgba: 0,
                activeHeight: "30vh",
                homeData: {
                    apiFinish: false,
                    applyproducts: [],
                    withdrawProducts: [],
                    repayProducts: [],
                    otherProducts: [],
                    welfareInfo: [],
                    newcards: "",
                    onekeyapplypage: {
                        url: ""
                    },

                    xm_driverPopConfig: '',
                    mxkproducts: "",
                    rejectpage: "", //拒件记录跳转地址
                    thirdproducts: "",
                    productext: [],
                    resecondproducts: [],


                }, //首页数据汇总
                iframeUrl: "", //商业化地址
                creditCardHeight: "0", //商业地址高度

                //抖动小球参数
                jitterArgs: {
                    isShow: false,
                    isStart: false,
                },
            };
        },
        mixins: [require("../../mixins").default],

        components: {
            record,
            broadcast,
            offlineProduct,
            multiApply,
            creditCard,
            secondRemittance,
            scroller,
            rongzeDialog,
            jitter,
            newcards,
        },

        computed: {
            ...mapState([
                'driver'
            ]),
        },

        methods: {
            ...mapMutations(['setDriverConfig',]),

            //解析首页导流参数
            parseHomeDriver(res){


                console.error('parseHomeDriver===>',res.data.xm_driverSuspensionWindowConfig);

                //new卡导流-联合登录
                this.PubDriver('xm_newcardsconfig', res.data.xm_newcardsconfig)

                //弹窗导流-联合登录
                this.PubDriver('xm_driverPopConfig', res.data.xm_driverPopConfig)

                //小球导流-联合登录
                this.jitterDriver(res.data.xm_driverSuspensionWindowConfig)
            },

            //小球点击
            jitterClick() {
                this.sinaAds.click({currEvent: this.stat_diversion.diversion.jitter.click,}, () => {});

                console.log('jumpLink==>', this.driver.xm_driverSuspensionWindowConfig.url);

                //联合登录
                this.beforeDriver(this.driver.xm_driverSuspensionWindowConfig.unloginUrl)

                // "type": "1", //1 内联 2外联打开
                this.driver.xm_driverSuspensionWindowConfig.url && AppBridge.activityView({
                    type: "open",
                    url: this.driver.xm_driverSuspensionWindowConfig.url,
                    open_inner: this.driver.xm_driverSuspensionWindowConfig.type==1,
                });
            },

            //小球导流-联合登录
            jitterDriver(params) {

                this.PubDriver('xm_driverSuspensionWindowConfig', params)

                this.jitterArgs = {
                    isShow: true,
                    isStart: true,
                }
                this.sinaAds.display({currEvent: this.stat_diversion.diversion.jitter.show,}, () => {
                    console.error('埋点发送完成==》', this.stat_diversion.diversion.jitter.show);
                });
                setInterval(() => this.jitterArgs.isStart = !this.jitterArgs.isStart, 5000)
            },

            //联合登录-公共处理【new卡、小球、】
            PubDriver(key, params) {
                if (!(params && params.unloginUrl)) return
                this.setDriverConfig({
                    key,
                    data: params
                })
            },


            init(tag) {
                try {
                    //this.initHomeData()
                    //this.getApplyList();
                    //this.getSecondProductList();
                    //this.getRejectApplyList();
                    //this.getMXKConfig();
                    this.fetchData(tag).then(res => {
                        //this.queryHomePageWelfareInfo();
                    });

                    this.getmarketinfo();
                    //this.getEntranceConfig();
                    this.redData();
                } catch (error) {
                    this.loadingClose();
                }
            },
            //初始化首页数据
            initHomeData() {
                this.homeData = this.$options.data().homeData;
                console.log("重置了数据", this.homeData);
            },
            //关闭loading
            loadingClose() {
                this.$nextTick(() => {
                    document.getElementById("spaceDiv").style.height = "0px";
                });
                this.$root.loadingClose();
            },
            //刷新
            refresh(cb) {
                //this.initHomeData();
                this.headerOpacity = 0;
                this.init();
                setTimeout(() => {
                    this.headerOpacity = 1;
                    cb && cb();
                }, 1000);
            },
            //top 距离顶部的像素点
            onPulling(top) {
                if (top && top > 20) {
                    this.headerOpacity = 0;
                }
            },
            //滚动中
            onScroll(e) {
                let scrollTop = e.target.scrollTop;
                if (scrollTop <= 100) {
                    this.headerRgba = scrollTop / 100;
                } else {
                    this.headerRgba = 1;
                    this.headerOpacity = 1; //解决正在刷新时又上滑透明度不还原问题
                }
            },
            //刷新完成
            refreshFinsh() {
                setTimeout(() => {
                    this.headerOpacity = 1;
                }, 200);
            },

            //获取借还款记录
            getApplyList() {
                return new Promise((resolve, reject) => {
                    api.home.getApplyList().then(res => {
                        if (helper.isSuccess(res)) {
                            this.homeData.applyproducts = res.data.applyproducts || [];
                            this.resolveQueue(res.data.productext);

                            resolve(res);
                        }
                    });
                });
            },
            //资方特殊流程
            resolveQueue(data) {
                if (!data) return;
                data.forEach(item => {
                    // 玖富
                    if (item.type == 1) {
                        this.resolveMaxent(item);
                    }
                });
            },
            // 保存玖富tick
            resolveMaxent(data) {
                let tick = util.getParams("fromUserId") + new Date().getTime();
                MaxentSDK.init(util.getParams("fromUserId"));
                MaxentSDK.active(tick).then(status => {
                    if (!status) return;
                    api.loan.jiufu.saveTicket({
                        requestType: "1",
                        productid: data.productid,
                        type: "1",
                        tick,
                        fundproductid: util.getParams()["productid"] || ""
                    });
                });
            },

            //获取二级商户
            getSecondProductList() {
                return new Promise((resolve, reject) => {
                    api.home.getSecondProductList().then(res => {
                        if (helper.isSuccess(res)) {
                            if (!res.data) return;
                            this.homeData.resecondproducts = res.data.resecondproducts || [];
                            this.homeData.newcards = res.data.newcards;
                            this.homeData.onekeyapplypage = res.data.onekeyapplypage;
                        }
                        resolve(res);
                    });
                });
            },
            //获取秒下款
            getMXKConfig() {
                return new Promise((resolve, reject) => {
                    api.home.getMXKConfig().then(res => {
                        if (helper.isSuccess(res)) {
                            if (res.data) {
                                this.homeData.mxkproducts = res.data.mxkproducts;
                            }
                        }
                        resolve(res);
                    });
                });
            },

            //接受iframe回调方法
            postMessageHandle(value) {
                if (value && typeof value == "number") {
                    this.$nextTick(() => {
                        setTimeout(() => {
                            this.creditCardHeight = value + "px";

                            this.loadingClose();
                        }, 1000);
                    });
                }
            },
            //获取贷超地址
            getmarketinfo() {
                return new Promise((resolve, reject) => {
                    api.activity
                        .getAppMarketInfo({
                            pageid: "1001",
                            token: util.getParams("token") || storage.get("token") || ""
                        })
                        .then(res => {
                            if (res.code == 200 && res.data) {
                                this.iframeUrl = res.data.jumplink;

                                setTimeout(() => {
                                    this.loadingClose();
                                }, 3000);
                            }
                            resolve(res);
                        });
                });
            },
            //拒件列表
            getRejectApplyList() {
                return new Promise((resolve, reject) => {
                    api.home.getRejectApplyList().then(res => {
                        if (res.code == 200 && res.data) {
                            this.homeData.rejectpage = res.data.rejectpage;
                        }
                        resolve(res);
                    });
                });
            },
            //获取三级商户（线下贷款）配置
            getEntranceConfig() {
                return new Promise((resolve, reject) => {
                    api.home.getEntranceConfig().then(res => {
                        if (!helper.isSuccess(res)) return;
                        if (res.data && res.data.thirdproducts) {
                            this.homeData.thirdproducts = res.data.thirdproducts;
                        }
                        resolve(res);
                    });
                });
            },



            // 获取首页数据大接口
            fetchData(tag) {
                return new Promise((resolve, reject) => {
                    if (tag) {
                        console.log(`return 伪协议 调用 `);
                        AppBridge.getHomeData({}, res => {
                            if (helper.isSuccess(res)) {
                                console.log("收到伪协议的数据了！");
                                this.homeData = Object.assign(this.homeData, res.data);
                                this.homeData.apiFinish = true;
                                this.formatData(this.homeData);

                                this.parseHomeDriver(res)

                                this.$nextTick(() => {
                                    this.pageShow = true;
                                });
                                this.resolveQueue(res.data.productext);
                                resolve(res);
                            }
                        });
                    } else {

                        api.home
                            .getHomePage({
                            //    mjbname:'suppanda'
                            })
                            .then(res => {

                                //res= this.mock.home

                                if (helper.isSuccess(res)) {
                                    this.homeData = Object.assign(this.homeData, res.data);
                                    this.homeData.apiFinish = true;

                                    this.formatData(this.homeData);
                                    this.parseHomeDriver(res)

                                    this.$nextTick(() => {
                                        this.pageShow = true;
                                    });
                                    this.resolveQueue(res.data.productext);



                                    resolve(res);
                                }
                            })
                            .finally(() => {
                                this.loadingClose();
                            });
                    }
                });
            },


            formatData(data) {

                /*    data = {
                        "resecondproducts": [],
                        "onekeyapplypage": {
                            "showmodel": "2",
                            "url": "http://static.sinawallent.com/v1.1.0/pages/home/index.html#/level2"
                        },
                        "rejectpage": {
                            "showmodel": "2",
                            "url": "http://static.sinawallent.com/v1.1.0/pages/home/index.html#/refuse"
                        },
                        "userstatus": 10,
                        "mxkproducts": {
                            "img": {
                                "pcode": "img",
                                "pname": "专区下面的图案",
                                "pvalue": "http://static.sinawallent.com/v1.1.0/data/imgs/offline_ent.png",
                                "porder": 2
                            },
                            "open_flag": {
                                "pcode": "open_flag",
                                "pname": "秒下款开关",
                                "pdesc": "秒下款开关",
                                "pvalue": "1",
                                "porder": 2
                            },
                            "btn_plan": {
                                "pcode": "btn_plan",
                                "pname": "秒下款申请按钮文案",
                                "pdesc": "申请按钮文案",
                                "pvalue": "申请放款",
                                "porder": 2
                            },
                            "content_plan2": {
                                "pcode": "content_plan2",
                                "pname": "秒下款文案二",
                                "pdesc": "秒下款文案二",
                                "pvalue": "绿色通道，金额直接入账银行卡",
                                "porder": 2
                            },
                            "content_plan1": {
                                "pcode": "content_plan1",
                                "pname": "秒下款文案一",
                                "pdesc": "秒下款文案一",
                                "pvalue": "额度范围:1000-2万",
                                "porder": 1
                            },
                            "url": {
                                "pcode": "url",
                                "pname": "秒下款访问url",
                                "pdesc": "秒下款访问url",
                                "pvalue": "http://static.sinawallent.com/v1.1.0/pages/home#/miaodai/index",
                                "porder": 2
                            }
                        },

                        "thirdproducts": {
                            "entrancepic": "http://static.sinawallent.com/v1.1.0/data/imgs/offline_ent.png",
                            "nextpage": {
                                "showmodel": "2",
                                "url": "http://k8s-xindai-test.sinaif.com/h5/activity/monkeyKing/levelMerchants/#/otherLevel"
                            },
                            "status": -1
                        },
                        "currentpage": {
                            "showmodel": "2",
                            "url": "http://static.sinawallent.com/v1.1.0/king/pages/home/index.html#/recommend?showLog=1"
                        },
                        "initConfig": {
                            "panda_down_url_ios": "https://itunes.apple.com/cn/app/id1248677862?mt=8",
                            "app_start_banner": "http://static.sinawallent.com/king/imgs/app-start-banner-3x.png",
                            "login_subtitle": "登录领取专属熊猫额度卡",
                            "can_update_idcard": "1",
                            "drversion_down_url_ios": "https://apps.apple.com/cn/app/id1467714676",
                            "statistics_server_count": "10",
                            "face_recognition_method": "1",
                            "app_name": "大王贷款",
                            "app_start_url": "https://www.baidu.com",
                            "app_home_tips": "年化利率低于36%，具体以实际利率为准",
                            "login_title": "HI 欢迎来到极速熊猫",
                            "panda_down_url_android": "http://static.sinawallent.com/v1.1.0/king/pages/home/#/upgrade",
                            "home_plans": "本产品不为在校学生提供服务。",
                            "is_show_progress_view": "1",
                            "drversion_down_url_android": "https://www.baidu.com",
                            "last_title": "助力生活 随心分期",
                            "panda_tip_count": "1",
                            "loan_title": "专属熊猫额度卡",
                            "loan_subtitle": "随心分期 额度高达20万"
                        },
                        "isNeedNoviceTips": "0",
                        "newHomeConfig": {
                            "titleType": 0,
                            "contentString": "200,000.00元",
                            "buttonString": "立即前往提现",
                            "payBackButtonString": "立即还款",
                            "describe": "",
                            "title": "可用额度",
                            "contentType": 0
                        },
                        "applyproducts": [{
                            "billdaycount": -307,
                            "channel": "xm",
                            "copywrites": [{
                                "type": 1,
                                "content": "本期应还(元)"
                            }, {
                                "remark": "1",
                                "type": 2,
                                "content": "距离还款日还有<span class='c-red'>-307天</span>"
                            }, {
                                "remark": "1",
                                "type": 3,
                                "content": "立即还款"
                            }],
                            "id": "3000701",
                            "deadline": "2018-09-06 00:00:00",
                            "createtime": "2019-07-04 14:21:40",
                            "orderid": "156222128754767248",
                            "statusurl": 16,
                            "maxamount": 525.58,
                            xmdriver: 1,
                            "classification": 2,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=3000701&orderid=156222128754767248&billid=156222154108782309"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/lexinicon.png",
                            "name": "乐花大王贷",
                            "updatetime": "2019-07-04 15:08:34",
                            "desc": "授信速度超过99%产品",
                            "status": 16
                        }, {
                            "billdaycount": -18,
                            "channel": "xm",
                            "copywrites": [{
                                "type": 1,
                                "content": "本期应还(元)"
                            }, {
                                "remark": "1",
                                "type": 2,
                                "content": "距离还款日还有<span class='c-red'>-18天</span>"
                            }, {
                                "remark": "1",
                                "type": 3,
                                "content": "立即还款"
                            }],
                            "id": "1001901",
                            "deadline": "2019-06-22 00:00:00",
                            "createtime": "2019-07-04 14:18:43",
                            "orderid": "156222111053802882",
                            "statusurl": 16,
                            "maxamount": 1661.38,
                            "classification": 1,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=1001901&orderid=156222111053802882&billid=156222178574090260"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/jiexinlogo.png",
                            "name": "捷信超贷",
                            "updatetime": "2019-07-04 14:29:46",
                            "desc": "专为优质客户提供大额贷款",
                            "status": 16
                        }, {
                            "billdaycount": -257,
                            "channel": "xm",
                            "copywrites": [{
                                "type": 1,
                                "content": "本期应还(元)"
                            }, {
                                "remark": "1",
                                "type": 2,
                                "content": "距离还款日还有<span class='c-red'>-257天</span>"
                            }, {
                                "remark": "1",
                                "type": 3,
                                "content": "立即还款"
                            }],
                            "id": "3001201",
                            "deadline": "2018-10-26 23:59:59",
                            "createtime": "2019-07-04 14:17:28",
                            "orderid": "156222103540573356",
                            "statusurl": 16,
                            "maxamount": 3000.0,
                            "classification": 3,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=3001201&orderid=156222103540573356&billid=156222200832253154"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/binfenlogo.png",
                            "name": "缤纷贷",
                            "updatetime": "2019-07-04 15:08:58",
                            "desc": "30秒审核，3分钟下款",
                            "status": 16
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 1,
                                "content": "可用额度(元)"
                            }, {
                                "type": 2,
                                "content": "审核通过提现秒下款"
                            }, {
                                "remark": "1",
                                "type": 3,
                                "content": "立即提现"
                            }],
                            "id": "1002201",
                            "createtime": "2019-07-04 15:13:56",
                            "orderid": "156222443618272966",
                            "statusurl": 10,
                            "maxamount": 5000.0,
                            "classification": 1,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=1002201&orderid=156222443618272966"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/zhongyoulogo.png",
                            "name": "中邮极速贷",
                            "updatetime": "2019-07-04 15:16:51",
                            "desc": "信用生活 乐享由你",
                            "status": 10
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 1,
                                "content": "可用额度(元)"
                            }, {
                                "type": 2,
                                "content": "审核通过提现秒下款"
                            }, {
                                "remark": "1",
                                "type": 3,
                                "content": "立即提现"
                            }],
                            "id": "2000301",
                            "createtime": "2019-07-04 14:18:43",
                            "orderid": "156222111027973266",
                            "statusurl": 10,
                            "maxamount": 1000.0,
                            "classification": 2,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=2000301&orderid=156222111027973266"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/niwodailogo.jpg",
                            "name": "你我分期",
                            "updatetime": "2019-07-10 15:00:45",
                            "desc": "凭身份证就能借3万元",
                            "status": 10
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 1,
                                "content": "可用额度(元)"
                            }, {
                                "type": 2,
                                "content": "审核通过提现秒下款"
                            }, {
                                "remark": "1",
                                "type": 3,
                                "content": "立即提现"
                            }],
                            "id": "3001601",
                            "createtime": "2019-07-04 14:18:42",
                            "orderid": "156222110994297633",
                            "statusurl": 10,
                            "maxamount": 1000.0,
                            "classification": 1,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=3001601&orderid=156222110994297633"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/mochouhuaicon.png",
                            "name": "莫愁花",
                            "updatetime": "2019-07-04 14:20:50",
                            "desc": "想花就花，莫愁花",
                            "status": 10
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 1,
                                "content": "可用额度(元)"
                            }, {
                                "type": 2,
                                "content": "审核通过提现秒下款"
                            }, {
                                "remark": "1",
                                "type": 3,
                                "content": "立即提现"
                            }],
                            "id": "2001501",
                            "createtime": "2019-07-04 14:17:29",
                            "orderid": "156222103620633572",
                            "statusurl": 10,
                            "maxamount": 3000.0,
                            "classification": 2,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=2001501&orderid=156222103620633572"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/quhuaicon.png",
                            "name": "趣花贷",
                            "updatetime": "2019-07-04 14:19:32",
                            "desc": "有实名手机号即可申请",
                            "status": 10
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 1,
                                "content": "可用额度(元)"
                            }, {
                                "type": 2,
                                "content": "审核通过提现秒下款"
                            }, {
                                "remark": "1",
                                "type": 3,
                                "content": "立即提现"
                            }],
                            "id": "2004001",
                            "createtime": "2019-07-04 14:10:02",
                            "orderid": "156222058904444297",
                            "statusurl": 10,
                            "maxamount": 10000.0,
                            "classification": 2,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=2004001&orderid=156222058904444297"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/dmdwlogo.png",
                            "name": "微贷多米贷",
                            "updatetime": "2019-07-04 14:11:43",
                            "desc": "无需抵押，最快10分钟放款",
                            "status": 10
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 2,
                                "content": "审批处理中"
                            }, {
                                "type": 1,
                                "content": "最高额度(元)"
                            }, {
                                "remark": "2",
                                "type": 3,
                                "content": "查看详情"
                            }],
                            "id": "3004501",
                            "createtime": "2019-07-04 14:21:40",
                            "orderid": "156222128734004618",
                            "statusurl": 1,
                            "maxamount": 2000.0,
                            "classification": 3,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=3004501&orderid=156222128734004618"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/hongshilogo.jpeg",
                            "name": "红狮信用贷",
                            "updatetime": "2019-07-06 13:28:40",
                            "desc": "高额度 秒审批 秒放贷",
                            "status": 1
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 2,
                                "content": "审批处理中"
                            }, {
                                "type": 1,
                                "content": "最高额度(元)"
                            }, {
                                "remark": "2",
                                "type": 3,
                                "content": "查看详情"
                            }],
                            "id": "3004101",
                            "createtime": "2019-07-04 14:18:42",
                            "orderid": "156222110939878375",
                            "statusurl": 1,
                            "maxamount": 3000.0,
                            "classification": 3,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=3004101&orderid=156222110939878375"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/shandianjielogo.png",
                            "name": "闪电借钱包",
                            "updatetime": "2019-07-06 13:28:34",
                            "desc": "现金分期 秒到账",
                            "status": 1
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 2,
                                "content": "审批处理中"
                            }, {
                                "type": 1,
                                "content": "最高额度(元)"
                            }, {
                                "remark": "2",
                                "type": 3,
                                "content": "查看详情"
                            }],
                            "id": "3002401",
                            "createtime": "2019-07-04 14:18:42",
                            "orderid": "156222110958160150",
                            "statusurl": 1,
                            "maxamount": 2000.0,
                            "classification": 1,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=3002401&orderid=156222110958160150"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/miaojie.png",
                            "name": "秒借贷",
                            "updatetime": "2019-07-04 14:18:30",
                            "desc": "资金周转首选",
                            "status": 1
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 2,
                                "content": "审批处理中"
                            }, {
                                "type": 1,
                                "content": "最高额度(元)"
                            }, {
                                "remark": "2",
                                "type": 3,
                                "content": "查看详情"
                            }],
                            "id": "3002301",
                            "createtime": "2019-07-04 14:18:42",
                            "orderid": "156222110974332736",
                            "statusurl": 1,
                            "maxamount": 5000.0,
                            "classification": 2,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=3002301&orderid=156222110974332736"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/lijidailogo.png",
                            "name": "立即贷",
                            "updatetime": "2019-07-06 13:27:49",
                            "desc": "国内领先的极速贷款平台",
                            "status": 1
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 2,
                                "content": "审批处理中"
                            }, {
                                "type": 1,
                                "content": "最高额度(元)"
                            }, {
                                "remark": "2",
                                "type": 3,
                                "content": "查看详情"
                            }],
                            "id": "3003901",
                            "createtime": "2019-07-04 14:17:29",
                            "orderid": "156222103605132300",
                            "statusurl": 1,
                            "maxamount": 1500.0,
                            "classification": 3,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=3003901&orderid=156222103605132300"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/duohaologo.png",
                            "name": "多好贷",
                            "updatetime": "2019-07-06 12:58:43",
                            "desc": "仅凭身份证3分钟下款",
                            "status": 1
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 2,
                                "content": "审批处理中"
                            }, {
                                "type": 1,
                                "content": "最高额度(元)"
                            }, {
                                "remark": "2",
                                "type": 3,
                                "content": "查看详情"
                            }],
                            "id": "1003401",
                            "createtime": "2019-07-04 14:17:28",
                            "orderid": "156222103565385796",
                            "statusurl": 1,
                            "maxamount": 5000.0,
                            "classification": 3,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=1003401&orderid=156222103565385796"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/diandainlogo.png",
                            "name": "点点分期",
                            "updatetime": "2019-07-06 13:28:31",
                            "desc": "让生活好一点",
                            "status": 1
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 2,
                                "content": "审批处理中"
                            }, {
                                "type": 1,
                                "content": "最高额度(元)"
                            }, {
                                "remark": "2",
                                "type": 3,
                                "content": "查看详情"
                            }],
                            "id": "2002901",
                            "createtime": "2019-07-04 14:17:28",
                            "orderid": "156222103582738170",
                            "statusurl": 1,
                            "maxamount": 20000.0,
                            "classification": 2,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=2002901&orderid=156222103582738170"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/ppdwlogo.jpg",
                            "name": "及贷",
                            "updatetime": "2019-07-06 13:28:44",
                            "desc": "审批快，月入2千也能贷",
                            "status": 1
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 2,
                                "content": "审批处理中"
                            }, {
                                "type": 1,
                                "content": "最高额度(元)"
                            }, {
                                "remark": "2",
                                "type": 3,
                                "content": "查看详情"
                            }],
                            "id": "1004401",
                            "createtime": "2019-07-04 14:10:02",
                            "orderid": "156222058920438096",
                            "statusurl": 1,
                            "maxamount": 50000.0,
                            "classification": 1,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=1004401&orderid=156222058920438096"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/zljrlogo.png",
                            "name": "招联好借钱",
                            "updatetime": "2019-07-06 13:23:48",
                            "desc": "有信用就能借到钱",
                            "status": 1
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 2,
                                "content": "审批处理中"
                            }, {
                                "type": 1,
                                "content": "最高额度(元)"
                            }, {
                                "remark": "2",
                                "type": 3,
                                "content": "查看详情"
                            }],
                            "id": "1000902",
                            "createtime": "2019-07-04 14:10:02",
                            "orderid": "156222058950930329",
                            "statusurl": 1,
                            "maxamount": 50000.0,
                            "classification": 1,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=1000902&orderid=156222058950930329"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/lizhilogo.png",
                            "name": "荔枝闪贷1.2",
                            "updatetime": "2019-07-04 14:09:50",
                            "desc": "专为优质客户提供大额贷款",
                            "status": 1
                        }, {
                            "channel": "xm",
                            "copywrites": [{
                                "type": 2,
                                "content": "审批处理中"
                            }, {
                                "type": 1,
                                "content": "最高额度(元)"
                            }, {
                                "remark": "2",
                                "type": 3,
                                "content": "查看详情"
                            }],
                            "id": "3003101",
                            "createtime": "2019-07-04 14:10:01",
                            "orderid": "156222058888257501",
                            "statusurl": 1,
                            "maxamount": 1500.0,
                            "classification": 3,
                            "nextpage": {
                                "url": "http://static.sinawallent.com/v1.1.0/pages/getNextPage/index.html#/?productid=3003101&orderid=156222058888257501"
                            },
                            "iconurl": "http://static.sinawallent.com/v1.1.0/data/imgs/icon/julaimilogo.png",
                            "name": "来米贷",
                            "updatetime": "2019-07-06 13:28:40",
                            "desc": "信用变钱 轻松提现",
                            "status": 1
                        }],
                        "productext": []
                    };*/

                let withdrawProducts = [];
                let repayProducts = [];
                let otherProducts = [];
                if (data.applyproducts) {
                    let repayArray = [16, 17, 18, 19, 20, 21, 22, 25, 26, 27, 31];
                    data.applyproducts.forEach(item => {
                        /*
                                      if(item.status == 10) {
                                          withdrawProducts.push(item)
                                      }else if(repayArray.includes(item.status)){
                                          repayProducts.push(item);
                                      }else {
                                          otherProducts.push(Object.assign({isOneProduct: true}, item));
                                      }*/
                        if (repayArray.includes(item.status)) {
                            repayProducts.push(item);
                        } else {
                            withdrawProducts.push(Object.assign({isOneProduct: true}, item));
                        }
                    });
                    this.homeData.withdrawProducts = withdrawProducts;
                    this.homeData.repayProducts = repayProducts;
                    helper.set(
                        "homeData-repayProducts",
                        JSON.stringify(this.homeData.repayProducts)
                    );
                }
                if (data.resecondproducts && data.resecondproducts.length > 0) {
                    otherProducts = otherProducts.concat(data.resecondproducts);
                }
                this.homeData.otherProducts = otherProducts;
            },
            queryHomePageWelfareInfo() {
                api.home
                    .queryHomePageWelfareInfo({
                        type: "list",
                        token: util.getParams("token") || storage.get("token") || ""
                    })
                    .then(res => {
                        if (helper.isSuccess(res)) {
                            if (res.data) {
                                this.homeData = Object.assign({}, this.homeData, {
                                    welfareInfo: res.data.realData
                                });
                            }
                        }
                    });
            },
            //消息红点查询
            redData() {
                return new Promise((resolve, reject) => {
                    api.user.message
                        .redDot({
                            pageCode: 2001004, //活动消息
                            productId: 2001,
                            token: util.getParams("token") || storage.get("token") || ""
                        })
                        .then(res => {
                            if (!helper.isSuccess(res)) return;
                            if (
                                res.data.messageCenterTotal &&
                                res.data.messageCenterTotal > 0
                            ) {
                                this.redIconShow = true;
                                if (res.data.messageCenterTotal > 99) {
                                    this.redIconCount = "99+";
                                } else {
                                    this.redIconCount = String(res.data.messageCenterTotal);
                                }
                            } else {
                                this.redIconShow = false;
                            }
                            resolve(res);
                        });
                });
            },

            // 获取在线客服地址
            getOnlineService() {
                AppBridge.getVisitUrl(
                    {
                        pageName: "ONLINESERVICE"
                    },
                    res => {
                        if (!res || !res.data) return;
                        let data = res.data;
                        if (typeof data == "string") {
                            data = JSON.parse(data);
                        }

                        if (data && data.url) {
                            this.onlineServiceUrl = data.url;
                        }
                    }
                );
            }
        },
        created() {
            this.init();
            this.getOnlineService();

            EventBus.$on("postMessage", this.postMessageHandle);
        },
        destroyed() {
            EventBus.$off("postMessage");
        },
        mounted() {
            this.$root.setStatusColor("white");
            this.$nextTick(() => {
                this.loadingClose();
            });
        },
        onRefresh(tag, data) {
            if (tag == "home" || tag == "refresh") {
                this.init(tag);
            }
        },
        watch: {}
    };
</script>

<style lang="scss" scoped>
    @-webkit-keyframes loadingRotate {
        0% {
            -webkit-transform: rotateZ(0deg);
        }
        100% {
            -webkit-transform: rotateZ(360deg);
        }
    }

    .view {
        transform: translateX(0);

        /deep/ .inner {
            margin-top: -22px !important;
            position: relative;

            .pull-refresh {
                background-color: transparent !important;
                height: 24px !important;
                padding: 0 !important;
            }
        }

        .c-view-content {
            transition: all 0.5s;
        }

        /deep/ .broadcast-wrap {
            margin: 14px 0 !important;
        }

        .recommend-content {
            background: url("../../assets/images/recommend-bg@2x.png") no-repeat;
            background-size: 100%;
            width: 100%;
            min-height: 230px;

            .header-content {
                text-align: center;

                .center {
                    display: inline-block;
                    width: 100px;

                    img {
                        width: 100%;
                    }
                }

                .right {
                    position: absolute;
                    right: 0;
                    margin-right: 16px;
                    margin-top: -4px;
                }
            }
        }
    }

    .bg {
        height: 100vh;
        background: white;
        position: relative;
        z-index: -1;

        img {
            display: block;
            width: 100%;
            position: relative;
            z-index: -1;
        }
    }

    .pull-down-bg {
        background-image: linear-gradient(-190deg, #7164cb 0%, #3961d6 100%);
        position: absolute;
        z-index: -1;
        width: 100%;
    }

    .header {
        position: relative;
        z-index: 1;
        // transition: background .3s;
        &.show {
            background: #514353 !important;
            color: white !important;
        }
    }

    .block-header {
        display: block;
        background: transparent;
        height: 40px;

        /*@media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
          height: 60px;
        }
        @media only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3) {
          height: 88px;
        }*/
    }

    .section + .section {
        border-top: 8px solid #f4f4f4;
    }

    .iframe-section {
        border-top: 0 !important;
    }

    .kefu-content {
        background-color: white;
        padding: 10px 13px;

        img {
            width: 100%;
        }
    }

    .posi-r {
        position: relative;
    }

    .red-icon {
        font-size: 18px;
        color: #ffffff;
        position: absolute;
        display: inline-block;
        text-align: center;
        background-color: #e72427;
        transform: scale(0.5);
    }

    .red-icon-one {
        padding: 2px 8px 3px 6px;
        top: -11px;
        right: -10px;
        border-radius: 50%;
    }

    .red-icon-two {
        padding: 2px 9px 3px 6px;
        border-radius: 36px;
        top: -10px;
        right: -18px;
    }

    .red-icon-three {
        padding: 2px 9px 3px 6px;
        border-radius: 40px;
        top: -13px;
        right: -22px;
    }

    .king-home-floatimg {
        position: fixed;
        top: 60%;
        right: 0;
        height: 67px;
        width: 67px;
        // transition: all .5s;
        img {
            width: 100%;
            height: auto;
        }
    }
</style>
