<template>
  <div class="alan_recentGame">
    <span class="text" >最近游戏:</span>
    <div class="game" :class="{'first':v.active,}" v-if="data&&data.length" v-for="(v,i) in data" :key="i" @click="handel(v)" :style="`left:${v.left}px;`">
      <div class="gameBox" :class="{'first':v.active,}">
        <img v-if="v.showName.includes('经典')" class="icon_v3" :src="`/static/img/lottery/recent_icon${i===0?'1':'2'}.png`"/>
        <label class="txt" :title="v.showName">{{v.showName.replace('经典','')}}</label>
        <p class="surplusTime" v-if="String(v.surplusTime).includes('停彩中')||v.surplusTime > 5">{{!String(v.surplusTime).includes('停彩中')?transformationTime(Number(v.surplusTime)):v.surplusTime}}</p><p class="wait" v-else>开奖中</p>
        <em class="icon_v3 close" @click.stop="close(v,i)" v-if="!v.active">&#xe648;</em>
      </div>
    </div>
  </div>
</template>

<script>
	import service from "./../../js/service.js";
	import {mapState, mapMutations, mapActions} from 'vuex';

	export default {
		props: ['recentGame'],
		data() {
			return {
				data: null,// 所有展示的数据
				minTimeData: null,// 时间最短的一条数据
				timer: null,// 定时器
				// notClick: false,// 禁止点击   限制疯狂点击
			}
		},
		computed: {
			...mapState(['initStatus_recentGame', 'baseInfo', 'currentLottery', 'openTimeS']),
		},
		watch: {
			initStatus_recentGame() {
				this.init()
			},
			baseInfo() {
				!this.data&&this.init()
			}
		},
		methods: {
			// 跳转
			handel(v) {
				this.$router.push('/lottery/#' + v.id)
			},
			close(v, i) {
				for(let val of this.data){
					if(this.data[i].left<val.left&&val.left!==1200){
						val.left -= 110
					}
				}
				this.data[i].left = 1200
				// this.data.splice(i, 1)
				let str = 'tc_' + this.baseInfo.nickName + '_recent' // 缓存里面的key值
				window.localStorage.setItem(str, JSON.stringify(this.data))
			},
			// 获取我的喜爱（最近游戏）数据  缓存中取
			findRecentGame() {
				// 先取到缓存  判断用户名是否存在
				if (!this.baseInfo || !this.baseInfo.nickName) return
				let str = 'tc_' + this.baseInfo.nickName + '_recent' // 缓存里面的key值
				let arr = window.localStorage.getItem(str);
				arr = arr ? JSON.parse(arr) : []
        // 处理兼容性 之前的版本（没有动画）不是绝对定位的  所以没有left  现在有了就可能会报错 所以要处理一下兼容性
        if(arr.length&&!arr[0].left){
					let left0 = 100
					for(let val of arr){
						val.left = left0
            left0 += 110
					}
					arr[0].active = true
        }
				let i = 0;
				for (let val of arr) {
					if (arr[i].id === this.currentLottery.id) break
					i++
				}
				// 如果存在就删除这个元素
				// i !== arr.length && (arr.splice(i, 1))
				// 这块做成画之后，就不能删除了  要变成left互动换
				if (i !== arr.length){ // 切换
          for(let val of arr){
          	if(val.left<arr[i].left&&val.left!==1200){
		          val.left += 110
		          val.active = false
            }
          }
          arr[i].left = 100
          arr[i].active = true
        }else{ // 添加一个新的元素
					for(let val of arr){
						val.left += 110
            val.active = false
					}
					this.currentLottery.left = 100
					this.currentLottery.active = true
					arr.push(this.currentLottery)
        }


				// // 然后从前面添加当前游戏  并缓存起来  最多只能缓存10个
				// arr.unshift(this.currentLottery)
				// arr = arr.splice(0, 10)
				// for(let val of arr){
				// 	val.left = left
				// 	left += 110;
				// }
				window.localStorage.setItem(str, JSON.stringify(arr))
				this.searchTime(arr)
			},
			// 处理开奖倒计时数据
			transformationTime(v) {
				if (v > 0) {
					let h = parseInt(v / 3600) + '';
					let m = parseInt((v - h * 3600) / 60) + '';
					let s = parseInt((v % 60)) + '';
					return `${(h).padStart(2, '0')} : ${(m).padStart(2, '0')} : ${(s).padStart(2, '0')}`;
				}
				return '00 : 00 : 00'
			},
			// 查询开奖倒计时的时间
			searchTime(arr) {
				this.initTimer();  // 初始化定时器
				let str = '';
				for (let val of arr) {
					str += val.id + ','
				}
				service.get(this, 'lottery/lottery-timer', {lotterys: str}).then(function (result) {
					let res = result.data
					if (res.code === 0) {
						// 添加开奖倒计时时间
						arr.forEach(function (v, i) {
							v.surplusTime = res.data[i]?res.data[i].timer:'停彩中'
							// 查找最短开奖倒计时彩种
							this.minTimeData = i === 0 ? v : this.minTimeData.surplusTime > v.surplusTime ? v : this.minTimeData;
						}.bind(this))
						arr.find(e=>(e.left === 100)).surplusTime = this.openTimeS
						this.data = []
						this.data = arr;// 渲染页面
						this.Countdown();// 实例化倒计时
					} else {
						console.log(res.message)
					}
				}, function (err) {
					console.log(err)
				})
			},
			// 倒计时
			Countdown() {
				// 定时器不存在的时候才会初始化定时器
				let that = this;
				!this.timer && (this.timer = setInterval(function () {
				  if(!that.timer) return
					that.data.forEach(function (v, i) {
						!String(v.surplusTime).includes('停彩中')&&v.surplusTime--;
					})
					if (that.minTimeData.surplusTime <= 0) {
						//最近的一个倒计时为0时  要刷新所有的倒计时时间
            that.searchTime(JSON.parse(JSON.stringify(that.data)))
					}
				}, 1000))
			},
			// 初始化定时器
			initTimer() {
				this.timer && clearInterval(this.timer)
				this.timer = null;
			},

			init() {
				this.initTimer();  // 初始化定时器
				// 获取最近游戏数据  缓存中取
				this.findRecentGame()
			}
		},
		created() {
			this.init()
		},
		mounted() {
		},
		destroyed() {
			this.initTimer();  // 初始化定时器
		}
	}
</script>

<style lang='less' scoped>
  @import "../../css/global.less";

  @keyframes twinklings {
    0% {
      font-size: 12px;
      letter-spacing: 0px
    }
    100% {
      font-size: 14px;
      letter-spacing: 1px;
      padding-top: 2px
    }
  }

  .bg_change() {
    background: url("./lotteryImg/btn_normal_bg1.png") no-repeat;;
    background-position: 110px;
  }

  @keyframes bgChange {
    0% {
      background: url("./lotteryImg/btn_normal_bg1.png") no-repeat;
      background-position: 0px
    }
    100% {
      .bg_change();
    }
  }

  .change_scale() {
    width: 110px;
    height: 42px;
    margin: 3px 0px;
    border: 1px solid @themeColor;
  }

  @keyframes changeScale {
    0% {
      width: 100px;
      height: 38px;
      margin: 5px;
    }
    100% {
      .change_scale();
    }
  }

  @labelMarTop: 15px;
  @keyframes labelMar {
    0% {
      margin-top: 4px;
    }
    100% {
      margin-top: @labelMarTop
    }
  }

  .pchange() {
    margin-top: 3px;
    opacity: 0;
  }

  @keyframes pChange {
    0% {
      margin-top: 0px;
      opacity: 1;
    }
    100% {
      .pchange();
    }
  }

  .alan_recentGame {
    width: 1200px;
    height: 48px;
    line-height: 48px;
    margin: 0 auto;
    background: rgba(240, 240, 240, 0.4);
    position: relative;
    overflow: hidden;
    .text {
      display: inline-block;
      float: left;
      width: 100px;
      line-height: 48px;
      font-size: 18px;
      color: #fff;
    }
    .game {
      position: absolute;
      transition: left 0.4s;
      display: inline-block;
      float: left;
      margin: 5px;
      width: 100px;
      /*border: 1px solid #ecc0c3;*/
      background: url("./lotteryImg/btn_normal_bg.png") no-repeat;
      /*background-position: 0px;*/
      background-size: 100% 100%;
      border-radius: 6px;
      overflow: hidden;
      height: 38px;
      cursor: pointer;
      /*line-height: 38px;*/

      .gameBox {
        width: 100%;
        height: 100%;
        position: relative;
        padding: 0 12px;
        cursor: pointer;
        /*background: url("./lotteryImg/btn_normal_bg1.png") no-repeat;*/
        img {
          position: absolute;
          left: 0;
          top: 0;
        }
        label {
          cursor: pointer;
          float: left;
          height: 14px;
          display: inline-block;
          font-size: 14px;
          overflow: hidden;
          line-height: 14px;
          width: 100%;
          margin-top: 4px;
          margin-bottom: 3px;
          color: #333333;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        p {
          float: left;
          height: 14px;
          overflow: hidden;
          line-height: 10px;
          display: inline-block;
          font-size: 12px;
          width: 100%;
          color: @themeColor;
        }
        p.wait {
          font-weight: 600;
          animation: twinklings 0.2s infinite linear alternate;;
        }
        .close {
          position: absolute;
          top: 0;
          right: 0;
          border-radius: 50%;
          width: 15px;
          height: 15px;
          text-align: center;
          line-height: 15px;
          /*background: #ccc;*/
          color: #ccc;
          display: none;
        }
      }
      &:hover {
        animation: changeScale 0.2s linear;
        .change_scale();
        .gameBox {
          animation: bgChange 6s linear;
          .bg_change();
          label {
            animation: labelMar 0.2s linear;
            margin-top: @labelMarTop;
          }
          p {
            animation: pChange 0.2s linear;
            .pchange();
          }
          em {
            display: inline-block;
          }
        }
      }

    }
    /*.game:nth-child(2){left: 100px}*/
    /*.game:nth-child(3){left: 210px}*/
    /*.game:nth-child(4){left: 320px}*/
    /*.game:nth-child(5){left: 430px}*/
    /*.game:nth-child(6){left: 540px}*/
    /*.game:nth-child(7){left: 650px}*/
    /*.game:nth-child(8){left: 760px}*/
    /*.game:nth-child(9){left: 870px}*/
    /*.game:nth-child(10){left: 980px}*/
    /*.game:nth-child(11){left: 1090px}*/
    .notClick {
      cursor: not-allowed !important;
    }
    .first {
      background: #F53B4A !important;
      pointer-events: none;
      * {
        color: #fff !important;
      }
    }
  }

  @media screen and (max-width: 1024px) {
    .alan_recentGame {
      width: 100%;
      overflow: hidden;
      .game {
        margin: 6px;
      }
    }

  }
</style>
