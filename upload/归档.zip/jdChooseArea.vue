<template>
  <div class="jd-choose-area-wrapper">
    <div class="nav-menu-box">
      <div class="nav-item" :class="{active:currentType === item.type}" v-for="item in typeArr"
           @click="currentType = item.type;zu(item.title, zuType, '')">{{item.title}}
      </div>
      <div class="nav-item" v-if="switchFn" @click="$router.push({path:'/lottery/#'+switchFn})">官方</div>
      <!-- <router-link :to="`/playDetails#${helpId}`" target="_blank" class="help"><i class="icon_v3">&#xe645;</i>玩法说明
      </router-link> -->
      <div class="help" @mouseenter="showPlayDetailJd=true" @mouseleave="showPlayDetailJd=false"><i class="icon_v3">&#xe645;</i>玩法说明
        <div class="helpMain" v-if="showPlayDetailJd">
          <span class="sanjiao"></span>
          <div class="playTitle" v-html="playDetails[currentType][0].title"></div>
          <div class="playMian" v-html="playDetails[currentType][0].value"></div>
        </div>
      </div>
    </div>
    <div class="action-btn-box">
      <div class="yb-kj">
        <div :class="{active:simpleFast}" @click="simpleFast = !simpleFast">一般</div>
        <div :class="{active:!simpleFast}" @click="simpleFast = !simpleFast">快捷</div>
      </div>
      <div class="tz-clear">
        <div class="input" v-show="!simpleFast">金额:<input maxlength="7" type="text" v-model="kjMoney" min="0"></div>
        <div class="active" :class="{'noClick':!canBet}" @click="canBet&&submit()">投注</div>
        <div @click="resetData">清除</div>
      </div>
    </div>
    <div class="choose-area">
      <table class="outer-table" :class="key" v-for="(value,key) in listData" v-show="key === currentType">
        <tbody>
        <tr v-for="item in value" v-if="getType(item)">
          <td class="outer-table-td" :class="obj.class" v-for="obj in item">
            <table class="inner-table">
              <thead>
              <tr>
                <th colspan="3">{{obj.title}}</th>
              </tr>
              </thead>
              <tbody>
              <tr class="title">
                <td>号码</td>
                <td>赔率</td>
                <td v-show="simpleFast">金额</td>
              </tr>
              <tr class="common" v-for="des in obj.list"
                  :class="[{active:(!simpleFast && des.active) || (simpleFast && des.input)},{normal:simpleFast}]"
                  @click="!simpleFast && (des.active = !des.active)" v-if="des.type">
                <td class="one" v-html="getHtml(obj.title,des.type)"><span
                  :class="{long:isLong(des.type)}">{{des.type}}</span></td>
                <td class="two">{{des.rate}}</td>
                <td class="three" v-show="simpleFast"><input maxlength="7" v-model="des.num" type="text"
                                                             min="0"/></td>
              </tr>
              <tr class="common" v-else>
                <td class="one"><span style="opacity: 0;">1</span></td>
                <td class="two"></td>
                <td class="three" v-show="simpleFast"></td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr v-else>
          <td class="outer-table-td full">
            <table class="inner-table">
              <thead>
              <tr>
                <th :colspan="item.list.length">{{item.title}}</th>
              </tr>
              </thead>
              <tbody>
              <tr>
                <td class="top" v-for="des in item.list">
                  <table>
                    <tbody>
                    <tr class="title">
                      <td>号码</td>
                      <td>赔率</td>
                      <td v-show="simpleFast">金额</td>
                    </tr>
                    <tr class="common" v-for="obj in des"
                        :class="[{active:(!simpleFast && obj.active) || (simpleFast && obj.input)},{normal:simpleFast}]"
                        @click="!simpleFast && (obj.active = !obj.active)" v-if="obj.type">
                      <td class="one" v-html="getHtml(item.title,obj.type)"></td>
                      <td class="two">{{obj.rate}}</td>
                      <td class="three" v-show="simpleFast"><input maxlength="7" v-model="obj.num" type="text" min="0"/>
                      </td>
                    </tr>
                    <tr class="common" v-else>
                      <td class="one"><span style="opacity: 0;">1</span></td>
                      <td class="two"></td>
                      <td class="three" v-show="simpleFast"></td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        </tbody>
      </table>
    </div>
    <div class="action-btn-box kj-input" v-show="!simpleFast">
      <div class="tz-clear">
        <div class="input">金额:<input maxlength="7" type="text" v-model="kjMoney"></div>
        <div class="active" :class="{'noClick':!canBet}" @click="canBet&&submit()">投注</div>
        <div @click="resetData">清除</div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import mockData from './js/data'
  import {mapState, mapMutations, mapActions} from 'vuex';
  import {userInit, Prompt, noticeInit} from '../../js/index.js'
  import jd_play from './js/jd_play.js'

  let init = userInit();

  // 判断是否有牛牛 返回牛之外的其他两个数字     总共10种方法
  function hasNiuNiu(arr) {
    let retArr = [] // --因为牛牛的玩法可能有种形成牛的方法  我们应该取最大的那个牛  所以是push  不能直接return的
    for (let [i, v] of arr.entries()) {
      arr[i] = Number(v)
    }
    if ((arr[0] + arr[1] + arr[2]) % 10 === 0) {
      retArr.push(arr[3] + arr[4])
    }
    if ((arr[0] + arr[1] + arr[3]) % 10 === 0) {
      retArr.push(arr[2] + arr[4])
    }
    if ((arr[0] + arr[1] + arr[4]) % 10 === 0) {
      retArr.push(arr[2] + arr[3])
    }
    if ((arr[0] + arr[2] + arr[3]) % 10 === 0) {
      retArr.push(arr[1] + arr[4])
    }
    if ((arr[0] + arr[2] + arr[4]) % 10 === 0) {
      retArr.push(arr[1] + arr[3])
    }
    if ((arr[0] + arr[3] + arr[4]) % 10 === 0) {
      retArr.push(arr[1] + arr[2])
    }
    if ((arr[1] + arr[2] + arr[3]) % 10 === 0) {
      retArr.push(arr[0] + arr[4])
    }
    if ((arr[1] + arr[2] + arr[4]) % 10 === 0) {
      retArr.push(arr[0] + arr[3])
    }
    if ((arr[1] + arr[3] + arr[4]) % 10 === 0) {
      retArr.push(arr[0] + arr[2])
    }
    if ((arr[2] + arr[3] + arr[4]) % 10 === 0) {
      retArr.push(arr[0] + arr[1])
    }
    for (let [i, v] of retArr.entries()) {
      retArr[i] = v % 10;
    }
    return retArr
  }

  let translationNum = ['牛', '一', '二', '三', '四', '五', '六', '七', '八', '九'];

  let initData = JSON.parse(JSON.stringify(mockData))
  export default {
    props: ['currentLotteryId', 'zu'],
    data() {
      return {
        // 玩法集合
        typeArr: [],
        // 数据集合
        listData: {},
        currentType: '', // 当前玩法种类
        simpleFast: true, // 一般快捷玩法
        kjMoney: 1, // 快捷投注的金额
        lotteryCode: '', // 彩种编码
        // lines: [], // 路珠参数
        // ballsNumber: {}, // 号码显示次数
        total: '', // 投注总金额
        note: '', // 投注总注数
        // maxBouns: 0,// 点击投注时弹框的最高限额值
        data: [], // 投注数据
        switchFn: 0, // 切换官方和经典玩法后的id
        helpId: 0,
        playDetails: [],  // 玩法介绍内容
        showPlayDetailJd: false,  // 是否显示玩法介绍内容
        // 组态方法
        zuType: {
          zuTypeMaping: { // 这个是显示组态上方的标题
            '牛牛': '牛牛组态',
            '梭哈': '梭哈组态',
          },
          zuTypeMethod: {
            '牛牛'(str) {
              if (!str) return '---'
              // 先算有没有牛
              // 计算有没有牛
              let arr = hasNiuNiu(str.split(','))
              if (arr.length) {
                return '牛' + (arr.includes(0) ? '牛' : translationNum[Math.max(eval(arr.join(',')))])
              } else {
                return '没牛'
              }
            },
            '梭哈'(str) {
              if (!str) return '---'
              // 直接用去重就好
              let arr = [...new Set(str.split(','))]
              switch (arr.length) {
                case 1:
                  return '五条';
                  break;
                case 2:
                  if (str.match(new RegExp(arr[0], "g")).length == 1 || str.match(new RegExp(arr[0], "g")).length == 4) {
                    return '四条'
                  }
                  return '葫芦';
                  break;
                case 3:
                  if (str.match(new RegExp(arr[0], "g")).length == 3 || str.match(new RegExp(arr[1], "g")).length == 3 || str.match(new RegExp(arr[2], "g")).length == 3) {
                    return '三条'
                  }
                  return '两对';
                  break;
                case 4:
                  return '一对';
                  break;
                case 5:
                  // 补全0 --10
                  for (let [i, v] of arr.entries()) {
                    v == 0 && (arr[i] = 10)
                  }
                  // 排序  最大值-最小值=4  就是顺子
                  arr.sort(function (a, b) {
                    return a - b
                  })
                  if (arr[4] - arr[0] == 4) {
                    return '顺子';
                    break;
                  }
                  return '散号';
                  break;
                default :
                  return '';
              }

              return '梭哈'
            },
          }
        }
      }
    },
    computed: {
      ...mapState([
        'issue', // 当前即将开奖的期号
        'maxBouns', // 点击投注时弹框的最高限额值
        'initStatus_tableRecord',// 这个状态用来刷新订单记录组件的表格数据  监听其改变时的状态来刷新表格
      ]),
      // 是否可以点击投注按钮
      canBet() {
        let data = {
          betParameters: [],
          lotteryId: this.lotteryCode
        }
        let middle = {
          BetContext: '',
          BetType: 1,
          IsForNumber: false,
          IsTeMa: false,
          Lines: '',
          Money: '',
          gname: '',
          id: '',
          mingxi_1: 0
        }
        this.listData[this.currentType].forEach(outer => {
          if (Object.prototype.toString.call(outer) === '[object Object]') {
            //if (toString.apply(outer) === '[object Object]') {
            outer.list.forEach(item => {
              item.forEach(val => {
                if (this.simpleFast) {
                  if (Number(val.num) > 0) {
                    data.betParameters.push(Object.assign({}, middle, {
                      BetContext: val.type,
                      Lines: val.rate,
                      gname: outer.title,
                      Money: val.num,
                      id: Number(val.code.slice(1))
                    }))
                  }
                } else {
                  if (val.active) {
                    data.betParameters.push(Object.assign({}, middle, {
                      BetContext: val.type,
                      Lines: val.rate,
                      gname: outer.title,
                      Money: this.kjMoney,
                      id: Number(val.code.slice(1))
                    }))
                  }
                }
              })
            })
          } else {
            outer.forEach(val => {
              val.list.forEach(obj => {
                if (this.simpleFast) {
                  if (Number(obj.num) > 0) {
                    data.betParameters.push(Object.assign({}, middle, {
                      BetContext: obj.type,
                      Lines: obj.rate,
                      gname: val.title,
                      Money: obj.num,
                      id: Number(obj.code.slice(1))
                    }))
                  }
                } else {
                  if (obj.active) {
                    data.betParameters.push(Object.assign({}, middle, {
                      BetContext: obj.type,
                      Lines: obj.rate,
                      gname: val.title,
                      Money: this.kjMoney,
                      id: Number(obj.code.slice(1))
                    }))
                  }
                }
              })
            })
          }
        })
        this.note = data.betParameters.length
        this.total = 0
        data.betParameters.forEach(item => {
          this.total += Number(item.Money)
        })
        this.data = data

        return this.simpleFast ? data.betParameters.length > 0 : this.kjMoney > 0 && data.betParameters.length > 0
      }
    },
    methods: {
      ...mapMutations(['setData']),
      isLong(type) {
        let reg = /^[0-9]+$/
        if (reg.test(type)) {
          return false
        }
        if (type.length > 1) {
          return true
        }
        return false
      },
      getHtml(type, current) {
        // k3彩种
        if ((this.helpId === 2) && (type === '两连' || type === '豹子' || type === '对子') && (current !== '任意豹子')) {
          let html = ''
          let arr = current.split(',').map(Number)
          arr.forEach(item => {
            html += `<div class="icon_${item}"></div>`
          })
          return html
        } else {
          let long = this.isLong(current) ? 'long' : ''
          return `<span class="${long}">${current}</span>`
        }
      },
      isInput(item) {
        item.num = item.num ? String(item.num) : ''
        if (item.num === '') {
          item.input = false
          return false
        }
        let reg = /^[1-9][0-9]*$/
        if (!reg.test(item.num)) {
          let a = item.num.slice(0, -1)
          item.input = reg.test(a)
          item.num = a
          return false
        }
        item.input = true
      },
      // 获取彩种id
      getLotteryId() {
        this.switchFn = this.dictionary[1][this.currentLotteryId]
        if (this.currentLotteryId === 0) {
          return false
        }
        this.lotteryCode = initData.lotteryCode[this.currentLotteryId]
        switch (this.currentLotteryId) {
          case 60:
          case 70:
          case 71:
          case 72:
          case 80:
          case 82:
          case 85:
          case 86:
          case 87:
          case 88:
          	// 经典时时彩
            this.typeArr = initData.typeArr.ssc
            this.listData = initData.lotteryData.ssc
            this.helpId = 0
            this.playDetails = jd_play.jd_sscs
            break
          case 90:
          	// 经典快三
            this.typeArr = initData.typeArr.k3
            this.listData = initData.lotteryData.k3
            this.helpId = 2
            this.playDetails = jd_play.jd_k3
            break
          case 100:
          case 102:
          case 103:
          case 104:
          case 105:
            this.typeArr = initData.typeArr.eleven11x5
            this.listData = initData.lotteryData.eleven11x5
            this.helpId = 1
            this.playDetails = jd_play.jd_elvenY
            break
          case 110:
            this.typeArr = initData.typeArr.pk10
            this.listData = initData.lotteryData.pk10
            this.helpId = 4
            this.playDetails = jd_play.jd_pk10
            break
        }
        this.currentType = this.typeArr[0].type
        this.lotteryCode && this.initGameLottery()
      },
      getType(item) {
        // console.log(Object.prototype.toString.call(item), 'getTypegetType');
        // return toString.apply(item) === '[object Object]' ? false : true
        return Object.prototype.toString.call(item) === '[object Object]' ? false : true
      },
      // 获取初始化的数据
      initGameLottery() {

        this.$http.post('/yx/u/api/xjw-lottery/init-game-lottery', JSON.stringify({lotteryId: this.lotteryCode}), {
            emulateJSON: true,
            headers: {'Content-Type': 'application/json; charset=UTF-8'}
          }
        ).then((response) => {
          let data = response.body;
          try {
            for (let key in this.listData) {
              this.listData[key].forEach(outer => {
                if (Object.prototype.toString.call(outer) === '[object Object]') {
                  //if (toString.apply(outer) === '[object Object]') {
                  outer.list.forEach(item => {
                    item.forEach(val => {
                      val.rate = data.Obj.Lines[val.code]
                    })
                  })
                } else {
                  outer.forEach(item => {
                    item.list.forEach(val => {
                      val.rate = data.Obj.Lines[val.code]
                    })
                  })
                }
              })
            }
	          this.zu(this.typeArr[0].title, this.zuType, '')
            // this.lines = data.Obj.LuZhu
            // this.ballsNumber = data.Obj.ZongchuYilou.hit ? data.Obj.ZongchuYilou.hit : []
          } catch (ex) {
            throw new Error('初始化数据失败')
          }
        })
      },
      // 重新设置money
      resetData() {
        this.kjMoney = 1
        for (let key in this.listData) {
          this.listData[key].forEach(outer => {
            if (Object.prototype.toString.call(outer) === '[object Object]') {
              //if (toString.apply(outer) === '[object Object]') {
              outer.list.forEach(item => {
                item.forEach(val => {
                  val.input = false
                  val.active = false
                  val.num = ''
                })
              })
            } else {
              outer.forEach(item => {
                item.list.forEach(val => {
                  val.input = false
                  val.active = false
                  val.num = ''
                })
              })
            }
          })
        }
      },
      // 投注
      submit() {
        // 快捷玩法
        if (!this.simpleFast) {
          if (Number(this.kjMoney) <= 0 || isNaN(Number(this.kjMoney))) {
            this.$Modal.al_default({
              status: 'warning',
              content: '请输入投注金额',
              time: 4000
            })
            return false
          }
        }
        // let data = {
        // 	betParameters: [],
        // 	lotteryId: this.lotteryCode
        // }
        // let middle = {
        // 	BetContext: '',
        // 	BetType: 1,
        // 	IsForNumber: false,
        // 	IsTeMa: false,
        // 	Lines: '',
        // 	Money: '',
        // 	gname: '',
        // 	id: '',
        // 	mingxi_1: 0
        // }
        // this.listData[this.currentType].forEach(outer => {
        // 	if (Object.prototype.toString.call(outer) === '[object Object]') {
        // 		//if (toString.apply(outer) === '[object Object]') {
        // 		outer.list.forEach(item => {
        // 			item.forEach(val => {
        // 				if (this.simpleFast) {
        // 					if (Number(val.num) > 0) {
        // 						data.betParameters.push(Object.assign({}, middle, {
        // 							BetContext: val.type,
        // 							Lines: val.rate,
        // 							gname: outer.title,
        // 							Money: val.num,
        // 							id: Number(val.code.slice(1))
        // 						}))
        // 					}
        // 				} else {
        // 					if (val.active) {
        // 						data.betParameters.push(Object.assign({}, middle, {
        // 							BetContext: val.type,
        // 							Lines: val.rate,
        // 							gname: outer.title,
        // 							Money: this.kjMoney,
        // 							id: Number(val.code.slice(1))
        // 						}))
        // 					}
        // 				}
        // 			})
        // 		})
        // 	} else {
        // 		outer.forEach(val => {
        // 			val.list.forEach(obj => {
        // 				if (this.simpleFast) {
        // 					if (Number(obj.num) > 0) {
        // 						data.betParameters.push(Object.assign({}, middle, {
        // 							BetContext: obj.type,
        // 							Lines: obj.rate,
        // 							gname: val.title,
        // 							Money: obj.num,
        // 							id: Number(obj.code.slice(1))
        // 						}))
        // 					}
        // 				} else {
        // 					if (obj.active) {
        // 						data.betParameters.push(Object.assign({}, middle, {
        // 							BetContext: obj.type,
        // 							Lines: obj.rate,
        // 							gname: val.title,
        // 							Money: this.kjMoney,
        // 							id: Number(obj.code.slice(1))
        // 						}))
        // 					}
        // 				}
        // 			})
        // 		})
        // 	}
        // })
        // if (data.betParameters.length === 0) {
        // 	this.$Modal.al_default({
        // 		status: 'warning',
        // 		content: '请至少选择一个投注类型',
        // 		time: 4000
        // 	})
        // 	return false
        // }
        // this.note = data.betParameters.length
        // this.total = 0
        // data.betParameters.forEach(item => {
        // 	this.total += Number(item.Money)
        // })
        // this.data = data
        // console.log(this.data.betParameters);

        this.$Modal.al_jdbetting({
          title: '快速投注',
          status: 'confim',
          onOk: this.sendImmediatelyBetting,
          data: {
            note: this.note,
            total: this.total,
            list: this.data.betParameters,
          }
        })
      },
      sendImmediatelyBetting() {
        this.$http.post('/yx/u/api/xjw-lottery/bet', JSON.stringify(this.data), {
            emulateJSON: true,
            headers: {'Content-Type': 'application/json; charset=utf-8'}
          }
        ).then((response) => {
          let data = response.body;
          if (data.result !== 1) {
            this.$Modal.al_default({
              status: 'warning',
              content: data.message ? data.message : data.msg,
              time: 4000
            })
          } else {
            this.resetData()
            this.$Modal.al_default({
              status: 'success',
              content: '您的订单投注成功',
              time: 4000
            })
            this.setData({key: "initStatus_tableRecord", value: !this.initStatus_tableRecord})
            // 刷新用户金额
            init.initlotteryBalance(this)

          }
        })
      }
    },
    created() {
      this.getLotteryId()
    },
    mounted() {
    },
    watch: {
      '$route'(val) {
        this.simpleFast = true
        this.resetData()
        this.getLotteryId()
      },
      currentLotteryId() {
        this.getLotteryId()
      },
      listData: {
        deep: true,
        handler() {
          let key = this.currentType
          if (!this.simpleFast || !key || !this.listData[key]) {
            return false
          }
          this.listData[key].forEach((outer, ix) => {
            if (toString.apply(outer) === '[object Object]') {
              outer.list.forEach((item, jx) => {
                item.forEach((val, kx) => {
                  this.isInput(val)
                })
              })
            } else {
              outer.forEach((item, jx) => {
                item.list.forEach((val, kx) => {
                  this.isInput(val)
                })
              })
            }
          })
        }
      },
      kjMoney(val, last) {
        if (val === '') {
          this.kjMoney = ''
          return false
        }
        let reg = /^[1-9][0-9]*$/
        if (!reg.test(val)) {
          this.kjMoney = last
          return false
        }
      }
    }
  }
</script>

<style lang="less">
  @import "../../css/global.less";

  .jd-choose-area-wrapper {
    font-size: 0;
    line-height: 1;
    text-align: left;
    user-select: none;
    background-color: #fff;
    .nav-menu-box {
      background: rgba(243, 226, 227, 1);
      line-height: 1;
      position: relative;
      .nav-item {
        display: inline-block;
        vertical-align: top;
        line-height: 40px;
        padding: 0 27px;
        font-size: 14px;
        color: #555555;
        position: relative;
        cursor: pointer;
        &.active {
          color: @themeColor;
          font-size: 16px;
          background: #fff;
          position: relative;
          .al_navWood;
        }
      }
      .help {
        position: absolute;
        right: 22px;
        top: 0;
        line-height: 40px;
        font-size: 14px;
        color: #333333;
        i {
          vertical-align: middle;
          color: #ff6a76;
          margin-right: 2px;
          position: relative;
          top: -1px;
        }
        .helpMain {
          // transform: rotateY(180deg);
          position: absolute;
          width: 500px;
          // background: url("./lotteryImg/bg_play_prompt_kuang.png") no-repeat;
          // background-size: 100% 100%;
          border: 1px solid #f53b4a;
          border-radius: 2px;
          box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.2);
          background-color: #fcf5f5;
          line-height: 24px;
          // padding: 14px 15px 18px 15px;
          z-index: 10;
          top: 40px;
          left: -404px;
          text-align: left;
          color: #666666;
          font-size: 14px;
          .sanjiao {
            display: inline-block;
            border-width: 6px;
            border-style: solid;
            border-color: transparent transparent #f53b4a transparent;
            position: absolute;
            top: -12px;
            right: 44px;
          }
          .playTitle {
            height: 44px;
            line-height: 44px;
            text-align: center;
            background: #fff;
            font-size: 16px;
          }
          .playMian {
            padding: 0 10px 10px;
            overflow: hidden;
          }
        }
      }
    }
    .action-btn-box {
      line-height: 1;
      margin: 12px 12px 0 12px;
      position: relative;
      z-index: 6;
      &.kj-input {
        margin: 10px 0 20px 0;
        text-align: center;
        .tz-clear {
          float: none;
        }
      }
      > div > div {
        display: inline-block;
        vertical-align: top;
        font-size: 14px;
        color: #333333;
        width: 50px;
        line-height: 30px;
        text-align: center;
        background-color: #E8E8E8;
        cursor: pointer;
        &.active {
          color: #fff;
          background-color: @themeColor;
          &.noClick {
            cursor: not-allowed;
            background: #ccc !important;
          }
        }
      }
      .yb-kj {
        background-color: #E8E8E8;
        border-radius: 4px;
        overflow: hidden;
        display: inline-block;
        vertical-align: top;
      }
      .tz-clear {
        float: right;
        div {
          border-radius: 4px;
          margin-right: 12px;
          &:last-child {
            margin-right: 0;
          }
          &.input {
            width: auto;
            background-color: transparent;
            input {
              width: 80px;
              height: 30px;
              background: rgba(255, 241, 241, 1);
              border-radius: 4px;
              outline: none;
              font-size: 12px;
              border: 1px solid @themeColor;
              padding: 0 5px;
              margin-left: 4px;
              &:focus {
                background: rgba(255, 241, 241, 1);
                border-color: @themeColor;
              }
            }
          }
        }
      }
    }
    .choose-area {
      line-height: 1;
      margin: 6px 12px 20px 12px;
      table {
        border-collapse: collapse;
        border-spacing: 0;
        empty-cells: show;
        width: 100%;
        background: transparent;
        text-align: center;
        th {
          line-height: 30px;
          font-size: 14px;
          color: #fff;
          text-align: center;
          background-color: @themeColor;
        }
      }
      .outer-table {
        &.qwzy {
          margin-top: 12px;
        }
        > tbody > tr, > thead > tr, > thead > tr th {
          display: block;
          width: 100%;
        }
        .outer-table-td {
          padding: 0 3px;
          margin-top: 6px;
          vertical-align: top;
          display: inline-block;
          min-width: 20%;
          background: #e5e5e5;
          &:first-child {
            padding-left: 0;
          }
          &:last-child {
            padding-right: 0;
          }
          &.full {
            width: 100%;
            td.top {
              vertical-align: top;
            }
          }
          &.k3-dd-bz-dz, &.lhd-o-t-f, &.nn-m, &.sh-o {
            width: 25%;
          }
          .inner-table {
            background-color: #E6E6E6;
            tr {
              &.title {
                background: #e6e6e6;
                td {
                  line-height: 30px;
                  font-size: 13px;
                  color: rgba(102, 102, 102, 1);
                  border: 1px solid #F5F5F5;
                }
              }
              &.common {
                background: #fff;
                &.active {
                  background-color: #ffd3d7;
                  &.normal {
                    background-color: #ffa5ac;
                    input {
                      border-color: #fff;
                    }
                  }
                }
                td {
                  height: 40px;
                  border: 1px solid #F5F5F5;
                  &.one {
                    div {
                      display: inline-block;
                      vertical-align: middle;
                      width: 22px;
                      height: 22px;
                      margin-left: 2px;
                      &:first-child {
                        margin-left: 0;
                      }
                      &.icon_1 {
                        background-image: url('../../img/pankou/ball_1.png');
                      }
                      &.icon_2 {
                        background-image: url('../../img/pankou/ball_2.png');
                      }
                      &.icon_3 {
                        background-image: url('../../img/pankou/ball_3.png');
                      }
                      &.icon_4 {
                        background-image: url('../../img/pankou/ball_4.png');
                      }
                      &.icon_5 {
                        background-image: url('../../img/pankou/ball_5.png');
                      }
                      &.icon_6 {
                        background-image: url('../../img/pankou/ball_6.png');
                      }
                    }
                    span {
                      box-sizing: border-box;
                      display: inline-block;
                      font-size: 12px;
                      height: 20px;
                      min-width: 20px;
                      background-color: @themeColor;
                      line-height: 20px;
                      border-radius: 50%;
                      text-align: center;
                      color: #fff;
                      font-weight: bold;
                      &.long {
                        padding: 0 4px;
                        border-radius: 4px;
                      }
                    }
                  }
                  &.two {
                    font-size: 12px;
                    font-weight: bold;
                    color: rgba(51, 51, 51, 1);
                  }
                  &.three input {
                    width: 44px;
                    height: 20px;
                    background: #fff;
                    border: solid 1px #d0d0d0;
                    border-radius: 2px;
                    outline: none;
                    font-size: 12px;
                    padding: 0 5px;
                    &:focus {
                      background: rgba(255, 241, 241, 1);
                      border-color: @themeColor;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    .line-box {
      margin-top: 30px;
    }
  }

  @media screen and (max-width: 1024px) {
    .jd-choose-area-wrapper .nav-menu-box .nav-item {
      padding: 0 18px;
    }
  }
</style>
