<template>
  <keep-alive>
      <router-view></router-view>
  </keep-alive>
</template>

<script>
export default {
	name: "publicInfo"
};
</script>

<style>
</style>
