let prefix_common = 'DW_clickH400_4';
let prefix_index = prefix_common + '1';

let index = {
  clickBankCardToggle: prefix_index + '01', // 点击“银行卡展开/收起”
};

export default {
  index
};
