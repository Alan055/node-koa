<template>
  <div class="al_writeNumberBet" :class="{'noClick':biggerType.search(/sscs|flb/)===-1}" @click="biggerType.search(/sscs|flb/)>-1&&write()">
    <Modal v-model="writeNumberBet" class="writeNumberBet" width="800px"
           :mask-closable="false"
           :closable="closable"
           class-name="vertical-center-modal"
           title="做号投注">
      <div class="modalBox">
        <div class="top">
          <al_countdown :issue="issue" class="countdown"></al_countdown>
          <al_lastLoteryNumber class="lastLoteryNumber" :name="currentLottery.showName"></al_lastLoteryNumber>
        </div>
        <!--一级菜单-->
        <div class="oneMenu">
          <span v-for="(v,i) in oneMenu" :key="i" class="item" :class="{'active':oneMenuIndex===i}"
                @click="oneMenuIndex=i;oneMenuClick(i)" v-if="lotteryTwoMenuMapping[v.value]">{{v.label}}</span>
          <div class="btnBox">
            <span class="btn" @click="showAndHide($event)">{{isShow?'隐藏':'展示'}}</span>
            <span class="btn" @click="oneMenuClick(oneMenuIndex)">清除</span>
          </div>
        </div>
        <!--二级菜单和选号区-->
        <div class="twoMenuBox">
          <div v-for="(v,i) in layout" :key="i" class="layoutItem" :class="isShow?'Expand':'Collapse'"
               v-if="v.methods.length>0&&v.methods[0].Number.length>0">
            <div class="twoMenu">{{v.label}}</div>
            <div class="twoMenuContent">
              <div v-for="(m,n) in v.methods" :key="n" class="item">
                <div class="label">{{m.name}}</div>
                <div class="chooseNumber"><span v-for="(a,b) in m.Number" :key="b" :class="{'active':a.value}" v-show="isShow || (m.value!=='yierlu') || (!isShow&&b<8)"
                                                @click="a.value=!a.value">{{a.label}}</span></div>
                <div class="tool" v-if="v.isTool">
                  <span v-for="(a,b) in tools" :key="b" @click="a.click(m.Number)">{{a.label}}</span>
                </div>
              </div>
            </div>
          </div>
          <!--选注栏-->
          <div class="writeNote">
            <al_chooseNote :note="note">
              <div class="writeBtn">
                <span class="produceNumber" @click="writeNumberData='',produceNumber()">立即生成</span>
                <span class="clearNumber" @click="writeNumberData='',clearNumber()">清除号码</span>
              </div>
            </al_chooseNote>
          </div>
          <div class="writeNumberData">
            <div class="writeNumberData_top">单式投注号码:</div>
            <div class="writeNumberData_content">
              <textarea class="text" @input="writeNumberData_writeChange()" v-model="writeNumberData"></textarea>
            </div>
          </div>

        </div>
      </div>
      <p class="prompt"><span>温馨提示：</span>本期最高奖金限额<span>{{ maxBouns?maxBouns:400000 }}元</span>，请会员谨慎投注！</p>
      <div slot="footer">
        <span class="cancel" @click="cancel()">取消</span>
        <span class="ok" @click="ok()">确认投注</span>
      </div>
    </Modal>

  </div>
</template>

<script>
	import {mapState, mapMutations, mapActions} from 'vuex';
	import al_countdown from "./alanCountdown.vue";
	import al_lastLoteryNumber from "./alanlastLoteryNumber.vue";
	import al_chooseNote from "./alanChooseNote.vue";//引入选注栏组件
	import lottery_calc from "./js/lottery_calc.js";//引入计算函数

	let writeBet = lottery_calc.writeBet()
	export default {
		components: {al_countdown, al_lastLoteryNumber, al_chooseNote},
		data() {
			return {
				writeNumberBet: false,// 弹框状态
				closable:true,// 弹框是否可以按 Esc 键关闭
				oneMenu: [
					{label: '前二', value: 'exzhixdsq', nums: 'q2'},
					{label: '后二', value: 'exzhixdsh', nums: 'h2'},
					{label: '前三', value: 'sxzhixdsq', nums: 'q3'},
					{label: '中三', value: 'sxzhixdsz', nums: 'z3'},
					{label: '后三', value: 'sxzhixdsh', nums: 'h3'},
					{label: '前四', value: 'sixzhixdsq', nums: 'q4'},
					{label: '后四', value: 'sixzhixdsh', nums: 'h4'},
					{label: '五星', value: 'wxzhixds', nums: 'wx'},
				], // 一级菜单数据
				oneMenuIndex: 0, // 当前选中的一级菜单下标
				isShow: true, // 一级菜单右侧按钮的下标  当前选中值
				//各种玩法数据
				layout: [
					{
						label: '定位杀', isTool: true, methods: []
					},
					{
						label: '和跨胆', isTool: false, methods: []
					},
					{
						label: '和值杀', isTool: false, methods: [
							{
								name: '和值', value: 'hezhi', Number: []
							},
						]
					},
					{
						label: '杀排列', isTool: false, methods: [
							{
								name: '大小', value: 'daxiao', Number: []
							}
						]
					},
					{
						label: '杀012路', isTool: false, methods: [
							{
								name: '012', value: 'yierlu', Number: []
							}
						]
					},
					{
						label: '特别排除', isTool: false, methods: [
							{
								name: '排除', value: 'lianxu', Number: []
							}
						]
					},
				],
				tools: [
					{label: '全', click: this.click_all},
					{label: '大', click: this.click_big},
					{label: '小', click: this.click_small},
					{label: '单', click: this.click_odd},
					{label: '双', click: this.click_even},
					{label: '清', click: this.click_close},
				],//全大小单双清  工具条
				// 将layout的数据分离出来  用来动态加载  也方便初始化  不需要遍历初始化状态
				// 定位杀数据
				data_DWS: [
					{
						name: '万位', value: 'wan', Number: [
							{label: 0, value: false},
							{label: 1, value: false},
							{label: 2, value: false},
							{label: 3, value: false},
							{label: 4, value: false},
							{label: 5, value: false},
							{label: 6, value: false},
							{label: 7, value: false},
							{label: 8, value: false},
							{label: 9, value: false},
						]
					},
					{
						name: '千位', value: 'qian', Number: [
							{label: 0, value: false},
							{label: 1, value: false},
							{label: 2, value: false},
							{label: 3, value: false},
							{label: 4, value: false},
							{label: 5, value: false},
							{label: 6, value: false},
							{label: 7, value: false},
							{label: 8, value: false},
							{label: 9, value: false},
						]
					},
					{
						name: '百位', value: 'bai', Number: [
							{label: 0, value: false},
							{label: 1, value: false},
							{label: 2, value: false},
							{label: 3, value: false},
							{label: 4, value: false},
							{label: 5, value: false},
							{label: 6, value: false},
							{label: 7, value: false},
							{label: 8, value: false},
							{label: 9, value: false},
						]
					},
					{
						name: '十位', value: 'shi', Number: [
							{label: 0, value: false},
							{label: 1, value: false},
							{label: 2, value: false},
							{label: 3, value: false},
							{label: 4, value: false},
							{label: 5, value: false},
							{label: 6, value: false},
							{label: 7, value: false},
							{label: 8, value: false},
							{label: 9, value: false},
						]
					},
					{
						name: '个位', value: 'ge', Number: [
							{label: 0, value: false},
							{label: 1, value: false},
							{label: 2, value: false},
							{label: 3, value: false},
							{label: 4, value: false},
							{label: 5, value: false},
							{label: 6, value: false},
							{label: 7, value: false},
							{label: 8, value: false},
							{label: 9, value: false},
						]
					},
				],
				// 和跨胆 数据
				data_HKD: [
					{
						name: '和尾杀', value: 'hewei', Number: [
							{label: 0, value: false},
							{label: 1, value: false},
							{label: 2, value: false},
							{label: 3, value: false},
							{label: 4, value: false},
							{label: 5, value: false},
							{label: 6, value: false},
							{label: 7, value: false},
							{label: 8, value: false},
							{label: 9, value: false},
						]
					},
					{
						name: '跨度杀', value: 'kuadu', Number: [
							{label: 0, value: false},
							{label: 1, value: false},
							{label: 2, value: false},
							{label: 3, value: false},
							{label: 4, value: false},
							{label: 5, value: false},
							{label: 6, value: false},
							{label: 7, value: false},
							{label: 8, value: false},
							{label: 9, value: false},
						]
					},
					{
						name: '胆码选', value: 'danma', Number: [
							{label: 0, value: false},
							{label: 1, value: false},
							{label: 2, value: false},
							{label: 3, value: false},
							{label: 4, value: false},
							{label: 5, value: false},
							{label: 6, value: false},
							{label: 7, value: false},
							{label: 8, value: false},
							{label: 9, value: false},
						]
					},
				],
				// 和值杀数据
				data_HZS: [
					{label: 0, value: false},
					{label: 1, value: false},
					{label: 2, value: false},
					{label: 3, value: false},
					{label: 4, value: false},
					{label: 5, value: false},
					{label: 6, value: false},
					{label: 7, value: false},
					{label: 8, value: false},
					{label: 9, value: false},
					{label: 10, value: false},
					{label: 11, value: false},
					{label: 12, value: false},
					{label: 13, value: false},
					{label: 14, value: false},
					{label: 15, value: false},
					{label: 16, value: false},
					{label: 17, value: false},
					{label: 18, value: false},
					{label: 19, value: false},
					{label: 20, value: false},
					{label: 21, value: false},
					{label: 22, value: false},
					{label: 23, value: false},
					{label: 24, value: false},
					{label: 25, value: false},
					{label: 26, value: false},
					{label: 27, value: false},
					{label: 28, value: false},
					{label: 29, value: false},
					{label: 30, value: false},
					{label: 31, value: false},
					{label: 32, value: false},
					{label: 33, value: false},
					{label: 34, value: false},
					{label: 35, value: false},
					{label: 36, value: false},
					{label: 37, value: false},
					{label: 38, value: false},
					{label: 39, value: false},
					{label: 40, value: false},
					{label: 41, value: false},
					{label: 42, value: false},
					{label: 43, value: false},
					{label: 44, value: false},
					{label: 45, value: false},
				],
				//012
				data_012S: [
					{label: '000', value: false},
					{label: '100', value: false},
					{label: '200', value: false},
					{label: '010', value: false},
					{label: '110', value: false},
					{label: '200', value: false},
					{label: '020', value: false},
					{label: '120', value: false},
					{label: '220', value: false},
					{label: '001', value: false},
					{label: '101', value: false},
					{label: '201', value: false},
					{label: '011', value: false},
					{label: '111', value: false},
					{label: '211', value: false},
					{label: '021', value: false},
					{label: '121', value: false},
					{label: '221', value: false},
					{label: '002', value: false},
					{label: '102', value: false},
					{label: '202', value: false},
					{label: '012', value: false},
					{label: '112', value: false},
					{label: '212', value: false},
					{label: '022', value: false},
					{label: '122', value: false},
					{label: '222', value: false},
				],
				// 杀排列数据
				data_SPL: [
					// 两位
					[
						{label: '大大', value: false},
						{label: '大小', value: false},
						{label: '小大', value: false},
						{label: '小小', value: false},
					],
					// 三位
					[
						{label: '大大大', value: false},
						{label: '小大大', value: false},
						{label: '大小大', value: false},
						{label: '小小大', value: false},
						{label: '大大小', value: false},
						{label: '小大小', value: false},
						{label: '大小小', value: false},
						{label: '小小小', value: false},
					],
					// 四位
					[
						{label: '大大大大', value: false},
						{label: '小大大大', value: false},
						{label: '大小大大', value: false},
						{label: '小小大大', value: false},
						{label: '大大小大', value: false},
						{label: '小大小大', value: false},
						{label: '大小小大', value: false},
						{label: '小小小大', value: false},
						{label: '大大大小', value: false},
						{label: '小大大小', value: false},
						{label: '大小大小', value: false},
						{label: '小小大小', value: false},
						{label: '大大小小', value: false},
						{label: '小大小小', value: false},
						{label: '大小小小', value: false},
						{label: '小小小小', value: false},
					],
					// 五位
					[
						{label: '大大大大大', value: false},
						{label: '小大大大大', value: false},
						{label: '大小大大大', value: false},
						{label: '大小大大大', value: false},
						{label: '小小大大大', value: false},
						{label: '大大小大大', value: false},
						{label: '小大小大大', value: false},
						{label: '大小小大大', value: false},
						{label: '小小小大大', value: false},
						{label: '大大大小大', value: false},
						{label: '小大大小大', value: false},
						{label: '大小大小大', value: false},
						{label: '小小大小大', value: false},
						{label: '大大小小大', value: false},
						{label: '小大小小大', value: false},
						{label: '大小小小大', value: false},
						{label: '小小小小大', value: false},
						{label: '大大大大小', value: false},
						{label: '小大大大小', value: false},
						{label: '大小大大小', value: false},
						{label: '小小大大小', value: false},
						{label: '大大小大小', value: false},
						{label: '小大小大小', value: false},
						{label: '大小小大小', value: false},
						{label: '小小小大小', value: false},
						{label: '大大大小小', value: false},
						{label: '小大大小小', value: false},
						{label: '大小大小小', value: false},
						{label: '小小大小小', value: false},
						{label: '大大小小小', value: false},
						{label: '小大小小小', value: false},
						{label: '大小小小小', value: false},
						{label: '小小小小小', value: false},
					],
				],
				// 特别排除
				data_TBPC: [
					[
						{rel: '01', label: '不连', value: false},
						{rel: '02', label: '两连', value: false},
					],
					[
						{rel: '03', label: '豹子', value: false},
						{rel: '04', label: '组三', value: false},
						{rel: '05', label: '组六', value: false},
						{rel: '06', label: '三连', value: false},
					],
					[
						{rel: '09', label: '豹子', value: false},
						{rel: '10', label: '不连', value: false},
						{rel: '11', label: '二连', value: false},
						{rel: '12', label: '三连', value: false},
						{rel: '13', label: '散号', value: false},
						{rel: '14', label: '对子号', value: false},
						{rel: '15', label: '三同号', value: false},
						{rel: '16', label: '两个对子', value: false},
					],
					[
						{rel: '17', label: '不连', value: false},
						{rel: '18', label: '二连', value: false},
						{rel: '19', label: '三连', value: false},
						{rel: '20', label: '四连', value: false},
						{rel: '21', label: '五连', value: false},
						{rel: '22', label: 'AAAAA', value: false},
						{rel: '23', label: 'AABCD', value: false},
						{rel: '24', label: 'AABBC', value: false},
						{rel: '25', label: 'AAABB', value: false},
						{rel: '25', label: 'AAABC', value: false},
						{rel: '27', label: 'AAAAB', value: false},
						{rel: '28', label: 'ABCDE', value: false},
					]
				],

				note: 0,// 注数
				writeNumberData: '',// textarea区的数据
				shortName: '', // 将已经计算了的玩法简写名称存起来
				betArr: null, // 投注时所用的数据
				calc: null,//计算函数
			}
		},
		computed: {
			...mapState([
				'issue',
				"maxBouns",
				"maxBouns1",
				'currentIssue',
				'currentLottery',
				'biggerType',
				'mode',
				'multiple',
				'bonus',
        'writeNumber_Menu',// 做号投注菜单名 --主页面的菜单应和做号投注里面的菜单保持一致
        'writeNumber_Data',// 做号投注的数据 --用于做号投注生成号码之后将生成的号码同步到主页面上
        'initStatus',// 这个状态用来初始化选号区的数据，当我们点击投注或者预投注的时候   改变这个状态，在选号区监听，然后初始化
        'lotteryTwoMenuMapping', // 这个是当前彩种开启的二级菜单  这个在做号投注里面会使用到，需要筛选一些是否可以放开
			]),
		},
		watch: {
		},
		methods: {
      ...mapMutations(['setData']),
			...mapActions(['ajaxBetting']),
			// 打开弹框
			write() {
				this.init();
				this.oneMenuClick(0);//初始化表格
				this.writeNumberBet = true; // 打开弹出框
			},
			// 弹框点击确认
			ok() {
				// 是否投注弹框
				this.note > 0 ? (this.closable=false,this.$Modal.al_bettingNow({
					title: '快速投注',
					onOk: this.sendAjax,
          onCancel: this.al_bettingNow_cancel,
				})) : this.$Modal.al_default({status: 'warning', content: '您还没有选择号码或所选号码不全！'})
			},
			sendAjax() {
				//传过去的数据必须是数组的json格式
				let arr = []
				arr[0] = {
					lottery: this.currentLottery.code,//彩种大类的英文名字  cqssc
					issue: this.issue,//期号
					method: this.shortName,//当前玩法的简写code
					content: this.calcNumber(),//选号的数据
					model: this.moneyTranslation[this.mode].text,//选中的钱   元角分厘 要转换成拼音
					multiple: this.multiple,//倍数
					code: this.bonus,//滑块（进度条）的奖金数
					compress: false//这个不知道   翻译是压缩   --原js里面写死的false
				}
				this.ajaxBetting({that: this, arr: arr});
				//关闭弹框
				this.cancel()
			},
			//关闭弹框
			cancel() {
				this.setData({key: "writeNumber_Menu", value: ''})
				this.writeNumberBet = false; // 打开弹出框
			},
			//计算当前选中的号码  处理成能发送给后台的格式  "-,-,2,3,4"
			calcNumber() {
				return this.calc().inputFormat(this.shortName, this.betArr)
			},
			al_bettingNow_cancel(){
				this.setData({key: "writeNumber_Menu", value: ''})
				this.closable = true
      },
			//tools的事件  大小单双清事件
			click_all(arr) {
				for (let val of arr) {
					val.value = true
				}
			},
			click_close(arr) {
				for (let val of arr) {
					val.value = false
				}
			},
			click_big(arr) {
				let length = arr.length;
				for (let val of arr) {
					val.value = val.label >= length / 2 ? true : false
				}
			},
			click_small(arr) {
				let length = arr.length;
				for (let val of arr) {
					val.value = val.label < length / 2 ? true : false
				}
			},
			click_odd(arr) {
				for (let val of arr) {
					val.value = val.label % 2 === 1 ? true : false
				}
			},
			click_even(arr) {
				for (let val of arr) {
					val.value = val.label % 2 === 0 ? true : false
				}
			},
      // 清除号码
			clearNumber(){
				this.setData({key: "writeNumber_Data", value: {label:''}})
        this.note = 0
      },
			//切换一级菜单
			oneMenuClick(i) {
				// 这里需要做各种适配  加载不同的数据
				let index;// 玩法号码的数量   // 第几类玩法  按数字分类  两位数一类  三位数一类...
				// if (i <= 1) {
				// 	index = 0;
				// } else if (i <= 4) {
				// 	index = 1;
				// } else if (i === 5) {
				// 	index = 2;
				// } else {
				// 	index = 3;
				// }
				// 处理 定位杀 数据  --这个最麻烦，每个的数据都不一样  //深复制
				this.layout[0].methods = i === 0 ? (index = 0, JSON.parse(JSON.stringify(this.data_DWS.slice(0, 2)))) :// 前二  万千
					i === 1 ? (index = 0, JSON.parse(JSON.stringify(this.data_DWS.slice(-2)))) :// 后二  十个
						i === 2 ? (index = 1, JSON.parse(JSON.stringify(this.data_DWS.slice(0, 3)))) :// 前三  万千百
							i === 3 ? (index = 1, JSON.parse(JSON.stringify(this.data_DWS.slice(1, 4)))) :// 中三 千百十
								i === 4 ? (index = 1, JSON.parse(JSON.stringify(this.data_DWS.slice(-3)))) :// 后三 百十个
									i === 5 ? (index = 2, JSON.parse(JSON.stringify(this.data_DWS.slice(0,4)))) :// 前四 万千百十
									i === 6 ? (index = 2, JSON.parse(JSON.stringify(this.data_DWS.slice(-4)))) :// 后四 千百十个
										i === 7 ? (index = 3, JSON.parse(JSON.stringify(this.data_DWS))) : []; // 五星 万千百十个

				// 处理 定位杀 数据
				this.layout[1].methods = JSON.parse(JSON.stringify(this.data_HKD));  //深复制
				// 处理 和值杀 数据
				this.layout[2].methods[0].Number = JSON.parse(JSON.stringify(this.data_HZS.slice(0, (index + 2) * 9 + 1)));
				// 处理 杀排列 数据
				this.layout[3].methods[0].Number = JSON.parse(JSON.stringify(this.data_SPL[index]));
				// 处理 杀012路 数据
				this.layout[4].methods[0].Number = index === 1 ? JSON.parse(JSON.stringify(this.data_012S)) : [];
				// 处理 特别排除 数据
				this.layout[5].methods[0].Number = JSON.parse(JSON.stringify(this.data_TBPC[index]));
			},
			//生成号码 ---核心逻辑
			produceNumber() {
				this.shortName = this.oneMenu[this.oneMenuIndex].value
				// 整理数据
				let obj = this.mergeData()
				// 传入到计算函数中
				let nums = this.oneMenu[this.oneMenuIndex].nums
				let rel = this.oneMenu[this.oneMenuIndex].value
				if (nums.search(/q4|h4|wx/)===-1) { // 不存在四星和五星   即三星和二星
					this.writeNumberData = writeBet.maingenNumbers(rel, nums, obj).replace(/ /g,',');
					this.writeNumberDataChange()
				} else {
					if (nums.includes('4')) { // 四星
						this.writeNumberData = writeBet.manualNumbersShi(rel, nums, obj).replace(/ /g,',');
						this.writeNumberDataChange()
					}
					if (nums == 'wx') {   // 五星的算法是放在webwork里面  有一套算法，所以返回的是异步的事件  传入this
						writeBet.manualWxNumbers(rel, nums, obj, this);
					}
				}
			},
			// 数据改变时  去计算需要投注的注数和数据格式
			writeNumberDataChange(){
				let arr = this.writeNumberData.split(',').sort(function (a,b) {
          return parseInt(a) - parseInt(b)
				})
				this.writeNumberData = arr.join(',')
				this.setData({key: "writeNumber_Menu", value: this.oneMenu[this.oneMenuIndex].label})// 做号投注的菜单传到主页面   --让主页面的菜单和做号投注页面的菜单保持一致
				this.setData({key: "writeNumber_Data", value: {label:this.writeNumberData}})

				this.betArr = this.writeNumberData.split(',');
				this.calc = lottery_calc['lottery_' + this.biggerType]
				this.note = this.calc().inputNumbers(this.shortName, this.betArr);
      },
      // 数据通过手写变化时
			writeNumberData_writeChange(){
				this.betArr = this.writeNumberData.split(',');
				!this.calc&&(this.calc = lottery_calc['lottery_' + this.biggerType])
				this.note = this.calc().inputNumbers(this.shortName, this.betArr);
				this.setData({key: "writeNumber_Data", value: {label:this.writeNumberData}})
      },
			// 整理数据
			mergeData() {
				let obj = {}
				// 整理 定位杀 和跨胆 和值杀  012路
				let i = 0;
				for (let v of this.layout) {
					i++
					if (i === 4 || i === 6) continue
					for (let val of v.methods) {
						let key = `gen-${val.value}-without`
						obj[key] = []
						for (let m of val.Number) {
							m.value === true && obj[key].push(Number(m.label))
						}
					}
				}
				// 整理 杀排列  大小
				for (let val of this.layout[3].methods) {
					let key = `gen-${val.value}-without`;
					obj[key] = []
					for (let m of val.Number) {
						m.value && obj[key].push(m.label.replace(/大/g, 1).replace(/小/g, 0).split('').join('|'))
					}
				}
				// 整理 特别排除
				for (let val of this.layout[5].methods) {
					let key = `gen-${val.value}-without`;
					obj[key] = []
					for (let m of val.Number) {
						m.value && obj[key].push(m.rel)
					}
				}
				return obj
			},
      //展示与隐藏的点击功能
			showAndHide(){
        this.isShow=!this.isShow;
        // 动画效果

        if(this.isShow){

        }
				$('.writeNumberBet .layoutItem').height(this.isShow? 'auto' : 32).css('align-items',this.isShow ? 'center' : 'flex-start');
				$('.writeNumberBet .layoutItem .twoMenuContent').height(this.isShow? 'auto' : 32);
				$('.writeNumberBet .layoutItem .twoMenuContent .chooseNumber').css('height',this.isShow? 'auto' : '28px').css('overflow','hidden');
      },

			// 初始化各种状态
			init() {
				this.closable=true
				this.writeNumberData = '';
				this.oneMenuIndex = 0;
				this.betArr = null;
				this.setData({key: "mode", value: '元'})
				this.setData({key: "initStatus", value: !this.initStatus})
			}
		},
		created() {
		},
		mounted() {
		},
	}
</script>

<style lang='less' scoped>
  @import "../../css/global.less";

  .al_writeNumberBet {
    position: absolute;
    width: 40px;
    height: 140px;
    border-top-right-radius: 10px;
    border-bottom-right-radius: 10px;
    overflow: hidden;
    /*background: #2396F7;*/
    top: 198px;
    right: calc(~"50% - 644px");
    background: url("./lotteryImg/btn_Betting_cai.png") no-repeat;
    background-size: 100% 100%;
    cursor: pointer;
    &.noClick {
      cursor: not-allowed;
    }
  }
  @media screen and (max-width: 1024px){
    .al_writeNumberBet{
      right: calc(~"50% - 490px");
    }
  }
</style>