<template>
  <div class="order">
    <div class="tab">
      <span v-for="(v,i) in tab" :key="i" :class="{'active':tabIndex===i}"
            @click="tabIndex!==i&&(tabIndex=i);tabClick(i)">
        {{v.text}}
      </span>
      <div class="cancelBtn" :class="{'prohibit':checkAllGroup.length===0}" @click="checkAllGroup.length>0&&batchCancel()">批量撤单</div>
      <!--<span @click="orderClick()">订单记录</span>-->
    </div>
    <div class="table" :class="'table'+tabIndex">
      <ul class="tableTop">
        <li><Checkbox
          :indeterminate="indeterminate"
          :value="checkAll"
          :disabled="isDisabled"
          @click.prevent.native="handleCheckAll"></Checkbox></li>
        <li v-for="(v,i) in tableTop[tabIndex]" :key="i">{{v}}</li>
      </ul>
      <div class="tableContent" v-if="mask" :class="{'tableContent_noData':tableContent.length===0}">
        <ul v-for="(v,i) in tableContent" :key="i">
          <li><CheckboxGroup @on-change="checkAllGroupChange(v) "><Checkbox v-model="v.value" :disabled="!v.allowCancel"></Checkbox></CheckboxGroup></li>
          <li><span class="billo" title="点击查看订单详情" @click="openModal_orderDetail(v.billno)">{{v.billno.substr(-6,6)}}</span></li>
          <!--<li v-else>{{v.billno}}</li>-->
          <li>{{tabIndex!==2?v.issue:v.startIssue}}</li>
          <li>{{v.lottery+'/'+v.method}}</li>
          <li>{{v.content}}</li>
          <li>{{tabIndex!==2?v.orderTime:(v.clearCount+'/'+v.totalCount)}}</li>
          <li>{{'¥'+(tabIndex!==2?v.money:v.totalMoney).toFixed(3)}}</li>
          <li v-if="tabIndex==1" :style="`color:${v.statusRemark!=='未开奖'&&v.winMoney>0?'#F53B4A':'#333'}`">{{v.statusRemark!=='未开奖'?('¥'+v.winMoney.toFixed(4)):'-'}}</li>

          <li :class="{'bingo':v.statusRemark==='已派奖'}">{{tabIndex!==2?v.statusRemark:v.statusStr}}</li>
          <li>
            <span class="btn" v-if="tabIndex!==2&&v.allowCancel" @click="$Modal.withdraw(v,1)">撤单</span>
            <span class="btn" title="再来一注" v-if="tabIndex!==2&&v.lottery.search(/经典|11选5|快3|六合彩/)===-1&&!v.method.includes('任选')&&currentLottery.showName===v.lottery" @click="againNote(v)">
              <em class="icon">&#xe6c3;</em>
              <!--<span>撤单</span>-->
            </span>
            <span v-if="tabIndex==2" :class="{'btn':v.allowCancel}" @click="v.allowCancel&&$Modal.withdraw(v,2)">{{v.allowCancel?'撤单':'无操作'}}</span>
          </li>
        </ul>
        <div class="tableBottom" v-if="tableContent.length>0">
          <span class="total">记录总数：<span>{{pagination_total}}</span>，页数：<span>{{pagination_page+1}}</span>/<span>{{pagination_pageTotal}}</span></span>
          <Page class="table_pagination" @on-change="pagination_change" :total="pagination_total" show-elevator
                :page-size="pagination_size"></Page>
        </div>
        <div class="noData" v-if="!tableContent.length">
          <div><em class="icon_v3">&#xe6a5;</em></div>
          <div class="txt">暂无数据</div>
        </div>
      </div>

      <div class="readyLoad" v-if="!mask"><em class="icon_v3">&#xe6d6;</em>正在加载中</div>
    </div>
    <div class="order_bottom"><a :href="`/userCenters/${tabIndex!==2?'betOrder':'chaseOrder'}`" target="_blank">更多记录>></a></div>

    <!--模态框   -->
    <!--订单详情-->


    <!--订单表格中的再来一注弹框-->
    <Modal class="modal_againNote"
           v-model="modal_againNote"
           width="500"
           title="再来一注"
           :mask-closable="false"
           class-name="vertical-center-modal"
           ok-text="确定投注"
           @on-ok="ok_againNote()"
           @on-cancel="">
      <div class="box" v-if="currentOperate">
        <div class="item_title">彩种：{{currentOperate.lottery}}</div>
        <div class="item_content">
          {{currentOperate.method}}：{{currentOperate.content}}
        </div>
        <div class="item_title">付款总金额：{{currentOperate.money}}元</div>
        <div class="item_content">模式：
          <div class="moneyMode">
            <span :class="{'active':currentMoneyModeIndex===i}" @click="currentMoneyModeIndex=i;totalMoney()"
                  v-for="(v,i) in moneyMode" :key="i">{{v.text}}</span>
          </div>
        </div>
        <div class="item_content">倍数：
          <div class="multipleBox">
            <span @click="againNote_multiple>1&&againNote_multiple--" class="reduce">-</span>
            <input type="number" v-model.trim.number="againNote_multiple">
            <span @click="againNote_multiple<9999&&againNote_multiple++" class="add">+</span>
          </div>
        </div>
      </div>

    </Modal>


  </div>
</template>

<script>
	import moment from 'moment';//引入时间处理插件
	import service from "./../../js/service.js";//引入ajax方法
	import {mapState, mapMutations} from 'vuex';
	// import {userInit} from './../../js/index.js'//刷新金额

	export default {
		props: ['issue'],
		data() {
			return {
				//页签的数据
				tab: [
					{text: '未开奖订单', ajax: 'game-lottery/search-order'},
					{text: '订单记录', ajax: 'game-lottery/search-order'},
					{text: '追号记录', ajax: 'game-lottery/search-chase'},
				],
				tabIndex: 0,//当前页签
				//表格数据
				tableTop: [
					['订单号', '期号', '彩种/玩法','投注号码', '下单时间', '投注金额（元）', '状态', '操作'],//未开奖订单表头
					['订单号', '期号', '彩种/玩法','投注号码', '下单时间', '投注金额（元）', '中奖金额（元）', '状态', '操作'],//游戏记录表头
					['订单号', '期号', '彩种/玩法','投注号码', '订单进程', '投注金额（元）', '状态', '操作'],//追号记录表头
				],
				tableContent: [],//表格内容的数据
				indeterminate: false,//选择了一部分
				checkAll: false,// 全选状态
				checkAllGroup:[],//选中的元素  一开始是[]
				moreOrder:'',// 更多订单的url
				mask: false,//当表格正在请求时，展示“正在加载中”
				timer_order: null, //订单的定时器
				//表格分页
				pagination_size: 5,//每一页有多少条
				pagination_total: 0,//后台总共有多少条数据
				pagination_page: 0,//当前查看的是第几页
				pagination_pageTotal: 0,//后台总共有多少页

				//订单详情模态框
				closable:true,// 是否可以按 Esc 键关闭
				modal_orderDetail: false,//订单详情  模态框的开关
				modal_chaseDetail: false,//追号详情  模态框的开关

				everyIssue_tableTop: ['期号', '倍数', '投注金额', '中奖金额', '状态', '开奖号码', '操作'],//追号详情订单列表里面的表格头部
				everyIssue_tableContent: null,////追号详情订单列表里面的表格内容数据


				//公共弹框 --在撤单中有用到
				modal_title: '',//公共弹框的标题
				modal_content: '',//公共弹框的内容
				// modal_public: false, //控制公共弹框的开关
				// modal_data: null,//公共数据存起来  方便调用

				//操作订单表格时的当前数据--存起来  之后调用时使用
				currentOperate: null,

				//再来一注弹框
				modal_againNote: false,//控制再来一注弹框的开关
				//金额模式  元角分厘
				moneyMode: [
					{text: '元', code: 'yuan', rate: 1},
					{text: '角', code: 'jiao', rate: 0.1},
					{text: '分', code: 'fen', rate: 0.01},
					{text: '厘', code: 'li', rate: 0.001},
				],
				currentMoneyModeIndex: 0,//当前选中金钱模式下标
				againNote_multiple: 1,//再来一注里面的倍数

        // 批量撤单
				isDisabled: false,// 是否点击全选checkbox
			}
		},
		computed: {
			...mapState([
				'initStatus_tableRecord',//这个状态用来刷新订单记录组件的表格数据  监听其改变时的状态来刷新表格
        'currentLottery',// 当前选中的彩种大类  包含中文名字  英文名字  id  三个属性  cqssc 重庆时时彩 11
        'allLotteryList',// 所有的彩种
        'biggerType',// 最大的彩种类型  sscs jd flb other elvenY dpc
			])
		},
		watch: {
			//这个状态用来刷新订单记录组件的表格数据  监听其改变时的状态来刷新表格
			initStatus_tableRecord() {
				this.tabClick(this.tabIndex)
			},
			//再来一注的倍数改变事件
			againNote_multiple(aft, pre) {
				let num = parseInt(aft)
				if (isNaN(num)) {
					this.againNote_multiple = 1
				} else {
					this.againNote_multiple = num > 9999 ? 9999 : num < 1 ? 1 : num
				}
				this.currentOperate.multiple = this.againNote_multiple
				this.totalMoney()
			},
		},
		methods: {
			...mapMutations(['setData']),
			//点击订单记录的事件  跳转到订单报表页面去
			orderClick() {
				window.open('/userReport#page=0_report')
			},
			//页签的点击事件
			tabClick(i) {
				//先将状态修改为“正在加载...”
				this.mask = false;
				//初始化表格数据 --即清空
				this.tableContent = [];
				//表格分页数据初始化
				this.pagination_total = 0
				this.pagination_pageTotal = 0
				this.pagination_page = 0
				//最后从后台获取表格数据
				this.findtableContent(i)
			},
      // 是否可以点击全选按钮  --过滤器
			findDisabled() {
				for (let val of this.tableContent) {
					if (val.allowCancel) return this.isDisabled = false;// 可以点击全选的复选框
				}
				this.checkAllGroup = []// 已选中的数据清空
				this.checkAll = false; // 去掉全选
				this.indeterminate = false // 去掉半选的状态
				return this.isDisabled = true// 不可以点击全选的复选框
			},
      // 全选点击事件
			handleCheckAll() {
				// 如果是半选的时候  就全部取消
				if (this.indeterminate) {
					this.checkAll = false; // 半选就全部取消
				} else {
					this.checkAll = !this.checkAll; // 不是半选  就改变全选或者无选的状态
				}
				this.indeterminate = false; // 去掉半选
				let arr = []
				if (this.checkAll) {
					// 改变成全选的时候
					for (let val of this.tableContent) {
            val.allowCancel && (val.value = true,arr.push(val)) // 能撤单的就打钩
					}
					this.checkAllGroup = JSON.parse(JSON.stringify(arr)) // 深复制
				} else {
					// 改变成无选状态
					for (let val of this.tableContent) {
						val.allowCancel && (val.value = false) //全部改成非选中状态
					}
					this.checkAllGroup = []
				}
			},
      // 刷新选中的撤销订单  --当订单刷新的时候才会取刷新这个选中的订单
      updataBatch(){
				// 全部没选的话  退出
				if(!this.checkAllGroup.length||!this.tableContent.length) {
					this.indeterminate = false; // 去掉半选
					this.checkAll = false; // 无选
					return
				}
        let arr = [];// 新的撤单容器
        for(let val of this.checkAllGroup){
        	let item = this.tableContent.find(e=>(e.billno === val.billno&&e.allowCancel))
          item && (item.value = true,arr.push(item))
        }
	      this.checkAllGroup = JSON.parse(JSON.stringify(arr))
        // 刷新全选的状态
        if(this.tableContent.length ===this.checkAllGroup.length){
	        this.checkAll = true;// 全选
        }else if(this.checkAllGroup.length>0){
	        this.indeterminate = true; // 半选
	        this.checkAll = false; // 无选
        }else{
	        this.indeterminate = false; // 去掉半选
	        this.checkAll = false; // 无选
        }
      },
      // 单个选中事件
			checkAllGroupChange (v) {
        // 这里有个问题   当点击复选框的边缘的时候  会出现不改变状态  但是会进入这个事件
        // 所以这个做一个去重
        if(this.checkAllGroup.find(e=>(e.billno===v.billno&&v.value))) return  // 已存在的话  就返回
				//如果选中  就添加到选中的数组集合里面，如果没有选中  就从数组集合里面删除掉
				if(v.value){
					this.checkAllGroup.push(v)
        }else {
          for(let s=0;s<this.checkAllGroup.length;s++){
          	if(v.billno===this.checkAllGroup[s].billno){
		          this.checkAllGroup.splice(s,1)
              break
            }
          }
        }
        //判断是不是全选
				let i=0;//有几个选中
				this.indeterminate=false
        if(v.value){
	        for(let val of this.tableContent){(val.value||!val.allowCancel)&&i++}
	        i===this.tableContent.length? this.checkAll=true:this.indeterminate=true
        }else{
	        for(let val of this.tableContent){(!val.value||!val.allowCancel)&&i++}
	        i===this.tableContent.length? this.checkAll=false:this.indeterminate=true
        }
				// this.indeterminate=false//是否选了一部分
        // i===0?this.checkAll=false:
			},
      //批量撤单事件
			batchCancel(){
        let that = this
				this.$Modal.al_default({
					status: 'confim', content: '确定要批量撤销订单？',
					onOk() {
						let url = that.tabIndex === 2 ? 'game-lottery/cancel-chase' : 'game-lottery/cancel-order';// 请求的url
						let obj = {} // 创建对象
						that.tabIndex === 2 && (obj.type = 'chase')// 如果是追号的 要加类型  写为追号订单撤销
						let p = [];
						for (let val of that.checkAllGroup) {

							obj.billno = val.billno
              p.push(service.post(that, url, obj))
						}
						p.length > 0 && Promise.all(p).then(function (result) {
              let n=0 // 成功撤单的个数
              for(let val of result){
                val.data.code === 0 && n++
              }
              if(n === result.length){
	              that.$Modal.al_default({status:'success',content:'全部撤单成功！'})// 全部撤单成功
              }else if(n > 0){
	              that.$Modal.al_default({status:'warning',content:'部分撤单成功！'})// 部分撤单成功
              }else {
	              that.$Modal.al_default({status:'warning',content:'全部撤单失败！'})// 全部撤单失败
              }
              that.findtableContent(that.tabIndex)// 重新请求订单的数据
						}).catch(function (err) {
							console.log(err)
						})
					},
				})

      },

			//获取当前页签的表格数据
			findtableContent(i) {
				let obj = {}
				//这里第三个页签（追号记录）请求的参数是不同的
				if (i != 2) {
					obj = {
						sTime: moment().format('YYYY-MM-DD') + " 00:00:00",
						eTime: moment().add(1, 'days').format('YYYY-MM-DD') + " 23:59:59",
					}
				} else {
					obj = {sTime: moment().format('YYYY-MM-DD'), eTime: moment().add(1, 'days').format('YYYY-MM-DD'),}
				}
				obj = Object.assign(obj, {lotteryType: 1, page: this.pagination_page, size: this.pagination_size})//后面这个对象是写死的数据
				i === 0 && (obj.status = 0);//区分未开奖订单和游戏记录
				this.ajaxData(obj, i)//通过ajax获取数据
				this.timer_order && (clearInterval(this.timer_order))//如果定时器存在，就先清除这个定时器（这一步是更新定时器）
				this.timer_order = setInterval(function () {
					this.ajaxData(obj, i)
				}.bind(this), 15000)//15秒刷新一次
			},
			//ajax请求
			ajaxData(obj, i) {
				let that = this;
				service.post(this, this.tab[i].ajax, obj).then(function (result) {
					let res = result.data
					if (res.code === 0) {
						//分页器
						that.pagination_total = res.data.totalCount;//存储一下后台总数据条数
						that.pagination_pageTotal = Math.ceil(res.data.totalCount / that.pagination_size);//存储一下后台总页数
						//处理订单时间
						for (let val of res.data.list) {
							val.value = false
							val.orderTime = moment(val.orderTime).format('YYYY-MM-DD HH:mm:ss')
						}
						that.tableContent = res.data.list//给表格内容添加数据
						that.mask = false;//将"正在加载..."去掉
            that.findDisabled(); // 是否可以点击全选按钮
						that.updataBatch();// 刷新批量撤单的数据
					} else {
             this.$Modal.al_default({status:'warning',content:res.message})
					}
					that.mask = true
				}, function (err) {
					console.log(err)
					that.mask = true
				})
			},
			//分页器改变的时候
			pagination_change(i) {
				//i是当前点击的页数，但我们后台是从0开始的  所以要减1
				this.pagination_page = i - 1
				this.findtableContent(this.tabIndex)
			},
      // 订单详情打开弹框
			openModal_orderDetail(v) {
				let url = ''
				this.modal_chaseDetailTable = []
				if (this.tabIndex === 2) {
					this.modal_chaseDetail = true
					url = 'game-lottery/get-chase'
					this.$Modal.al_chaseDetail(v,url)
				} else {
					// this.modal_orderDetail = true
					url = 'game-lottery/get-order'
					this.$Modal.al_orderDetail(v,url)
				}
			},


			//订单表格的撤单的点击事件
			Withdrawal(v, i) {
				// 转到弹框组件的撤单事件

			},
			// // 是否撤销订单的模态框  确认事件
			// ok_WithdrawalOrder(v) {
			// 	let obj = {billno: v.billno}
			// 	let url = ''
			// 	//这里做一个适配  兼容追号的撤单和追号单里面单个期数的撤单  总共是三个
			// 	//用al_type来做适配 al_type   1是订单撤单  2是追号撤单   3个追号里面的期数撤单
			// 	if (v.al_type === 1) {
			// 		url = 'game-lottery/cancel-order'
			// 	}
			// 	if (v.al_type === 2) {
			// 		obj.type = 'chase'
			// 		url = 'game-lottery/cancel-chase'
			// 	}
			// 	if (v.al_type === 3) {
			// 		obj.type = 'general'
			// 		url = 'game-lottery/cancel-single-chase'
			// 	}
			// 	service.post(this, url, obj).then(function (result) {
			// 		if (result.data.code === 0) {
       //      this.$Modal.al_default({status:'success',content: '撤单成功！'})
			// 			if(v.al_type !== 1){
			// 				//将追号详情的模态框关闭
			// 				this.modal_chaseDetail = false
       //        this.modal_chaseDetailTabIndex=0//追号详情订单里面的页签  当前选中的第几个页签  初始化
			// 			}
			// 			this.modal_data = null;////操作订单表格时的当前数据清空 避免下一次使用时出错
			// 			this.tabClick(this.tabIndex)//刷新订单框 当前表格的数据
			// 			userInit().initlotteryBalance(this)//刷新金额
			// 		} else {
       //      this.$Modal.al_default({status:'warning',content:result.data.message})
			// 		}
			// 	}, function (err) {
			// 		console.log(err)
			// 	})
			// },



			//订单表格的再来一注的点击事件
			againNote(v) {
				this.currentOperate = Object.assign({}, v) //操作订单表格时的当前数据--深复制存起来 用于渲染在模态框中和之后调用数据
				this.currentMoneyModeIndex = parseInt(Math.log(Number(this.currentOperate.money / this.currentOperate.multiple / this.currentOperate.nums)) / Math.log(0.1))// 资金模式
				this.againNote_multiple = this.currentOperate.multiple  //倍数赋值
				this.modal_againNote = true;//打开再来一注模态框
			},
			// 再来一注的  资金模式变化时的事件  其实就是计算一下金额
			totalMoney() {
				// 总金额= 倍数*注数*金额模式  取三位小数
				this.currentOperate.money = (this.currentOperate.multiple * this.currentOperate.nums * this.moneyMode[this.currentMoneyModeIndex].rate).toFixed(3)
			},
			// 再来一注的弹框确定事件  投注的号码要从订单详情的接口里面调   订单列表的接口没有投注的号码字段
			ok_againNote() {
				service.post(this, 'game-lottery/get-order', {billno: this.currentOperate.billno}).then(function (result) {
					let res = result.data
					if (res.code === 0) {
            this.currentOperate.content1=res.data.content;
            this.againNoteAjax(); // 再来一注发送请求
					} else {
						this.$Modal.al_default({status:'warning',content:res.message})
					}
				}, function (err) {
					console.log(err)
				})
			},
      // 再来一注发送请求
			againNoteAjax(){
				let v = this.currentOperate
				let obj = {
					"lottery": this.allLotteryList.find((e) => (e.id === v.lotteryId)).code, //通过id去查找彩种大类的code  CQSSC
					"issue": this.issue,//取当前开奖的期数
					"method": v.methodCode,
					// "content": v.method.includes('单式') ? v.content1.replace(/,/g, '').replace(/\|/g, ','): v.content1,// 这里要特殊处理一下  单式的时候  需要做一个过滤转换
          // 这里11选5不能追号  其实可以去掉 --this.biggerType.search(/elvenY/)>-1?v.content1.replace(/,/g, ' ').replace(/\|/g, ','): --去掉的代码
					"content": this.biggerType.search(/sscs|flb/)>-1&&v.method.search(/和值|特殊号/)==-1&&v.content1.search(/总和/)===-1?v.content1.replace(/,/g, '').replace(/\|/g, ','):v.content1,// 这里要特殊处理一下  单式的时候  需要做一个过滤转换
					"model": this.moneyMode[this.currentMoneyModeIndex].code,
					"multiple": v.multiple,
					"code": v.code,
					"compress": v.compress
				}
				service.post(this, 'game-lottery/add-order', {text: JSON.stringify([obj])}).then(function (result) {
					let res = result.data
					if (res.code === 0) {
						this.$Modal.al_default({status:'success',content: '投注成功！'})
						// this.setData({key: 'lotteryBalance', value: res.data})//刷新金额
						this.$store.commit('setBaseInfo', {lotteryBalance: res.data})//刷新金额
						this.tabClick(this.tabIndex) // 刷新表格的数据
					} else {
						this.$Modal.al_default({status:'warning',content:res.message})
					}
				}, function (err) {
					console.log(err)
				})
      },

			init() {
				this.findtableContent(this.tabIndex)
			}

		},
		created() {
			this.init()
		},
		mounted() {

		},
    destroyed(){
	    this.timer_order&&(clearInterval(this.timer_order))
    }
	}
</script>

<style lang='less' scoped>
  @import "../../css/global.less";

  @keyframes transitionSelf {
    0%{transform: rotate(0deg)}
    100%{transform: rotate(360deg)}
  }
  .order {
    /*padding: 0 10px;*/
    .bor(@methodBox_bor);
    width: 100%;
    background: #fff;
    .tab {
      font-size: 0;
      background-color: @orderTabBg;
      text-align: left;
      /*margin: 0 10px;*/
      span {
        display: inline-block;
        vertical-align: top;
        text-align: center;
        font-size: 14px;
        cursor: pointer;
        color: @orderColor;
        height: 40px;
        width: 120px;
        /*padding: 0 30px;*/
        line-height: 40px;
        /*margin-right: 4px;*/
        &.active {
          background: #fff;
          color: @themeColor;
          position: relative;
          .al_navWood;
        }
      }
      .cancelBtn{
        float: right;
        display: inline-block;
        width: 84px;
        height: 28px;
        line-height: 26px;
        color: @themeColor_Sec;
        .bor(@methodBox_bor);
        background: #fff;
        border-radius: 14px;
        font-size: 14px;
        text-align: center;
        margin-right: 12px;
        margin-top: 6px;
        cursor: pointer;
      }
      .prohibit{
        cursor: not-allowed;
      }
    }
    .table {
      background: #fff;
      width: 100%;
      /*height: 248px;*/
      /*height: 443px;*/
      border-top: 1px solid @methodBox_bor;
      ul {
        overflow: hidden;
        li {
          display: inline-block;
          float: left;
          text-align: center;
          height: 40px;
          line-height: 40px;

          border-right: 1px solid #e6e6e6;
          .btn {
            /*background: #6fade0;*/
            /*border-radius: 4px;*/
            /*border: 1px solid #6fade0;*/
            text-decoration: none;
            cursor: pointer;
            display: inline-block;
            font-size: 12px;
            padding: 0px 4px;
            /* padding-bottom: 2px; */
            height: 17px;
            line-height: 15px;
            color: @themeColor_Sec;
            margin-top: 2px;
            em {
              font-size: 14px;
              vertical-align: middle;
            }
          }
        }
        li:nth-child(1) {
          width: 4.5%;
          /*display: none;*/
          label{
            margin: 0;
          }
        }
        li:nth-child(2) {
          width: 7.2%;
        }
        li:nth-child(3) {
          /*width: 9.2%;*/
          width: 12.2%;
        }
        li:nth-child(4) {
          width: 18.2%;
        }
        li:nth-child(5) {
          width: 8%;
          overflow:hidden;
          text-overflow:ellipsis;
          white-space:nowrap
        }
        li:nth-child(6) {
          width: 18%;
        }
        li:nth-child(7) {
          width: 14%;
        }
        li:nth-child(8) {
          width: 8.4%;
        }
        li:nth-child(9) {
          width: 9.5%;
          border-right: none;
        }
      }
      .tableTop {
        color: @orderColor_Sec;
        border-bottom: 1px solid #e6e6e6;
        font-size: 14px;
      }
      .tableContent {
        height: 323px;
        overflow: auto;
        position: relative;
        font-size: 12px;
        &.tableContent_noData{
          height: 174px;
          display: flex;
          flex-direction: column;
         justify-content: center;
        }
        >ul {
          border-bottom: 1px solid #e6e6e6;
          color: @orderColor;
          &:hover{
            background: @methodBox_bor;
          }
          li {
            height: 30px;
            line-height: 30px;
            .billo{
              cursor: pointer;
              color: @themeColor_Sec;
            }
          }
          .bingo {
            color: @themeColor;
          }
          li:nth-child(6) {
            color: @themeColor;
            /*cursor: pointer;*/
          }
          li:last-child{
            color: @themeColor_Sec;
          }
        }
        .noData{
          em{
            color: #888;
            opacity: 0.4;
            font-size: 52px;
          }
          .txt{
            color: #888;
            font-size: 16px;
          }
        }
        .tableBottom {
          position: absolute;
          bottom: 0px;
          padding: 10px 20px;
          border: none;
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: space-between;
          .total {
            span {
              color: @themeColor;
            }
          }
          .table_pagination {
            border: none;
          }
        }
        .al_scorll();
      }

    }
    .table1{
      ul{
        li:nth-child(2){width: 6.2%}
        li:nth-child(3){width: 11.2%}
        li:nth-child(4){width: 18.2%}
        li:nth-child(5){width: 8%;overflow:hidden;
          text-overflow:ellipsis;
          white-space:nowrap}
        li:nth-child(6){width: 10%}
        li:nth-child(7){width: 13%}
        li:nth-child(8){width: 13%}
        li:nth-child(9){width: 6.4%; border-right: 1px solid @methodBox_bor;}
        li:nth-child(10){width: 9.5%; border-right: none;}
      }
      .tableContent{
        ul{
          li:nth-child(7){color: @themeColor}
        }
      }
    }
    .table2{
      ul{
        li:nth-child(2){width: 6.2%}
        li:nth-child(3){width: 11.2%}
        li:nth-child(4){width: 20.2%}
        li:nth-child(5){width: 8%}
        li:nth-child(6){width: 14%}
        li:nth-child(7){width: 9.9%}
        li:nth-child(8){width: 13%}
        li:nth-child(9){width: 13%;border-right: none !important; }
      }
      .tableContent{
        ul{
          li:nth-child(7){color: @themeColor}
        }
      }
    }
    .order_bottom{
      border-top: 1px solid @methodBox_bor;
      height: 38px;
      line-height: 38px;
      a{
        color: #888;
        &:hover{
          color: @themeColor_Sec;
        }
      }
    }
    .readyLoad {
      display: flex;
      justify-content: center;
      align-items: center;
      height: calc(~"100% - 40px");
      font-size: 14px;
      color: #888;
      em{
        color: #CFCFCF;
        font-size: 24px;
        animation: transitionSelf 0.7s linear infinite;
        margin-right: 8px;
      }
    }

  }
  @media screen and (max-width: 1024px){

  }
</style>