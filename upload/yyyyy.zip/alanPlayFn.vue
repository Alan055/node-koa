<template>
  <div class="playFn" v-if="layout">
    <!--这里有四层！！！！！！！！！-->
    <div class="oneMenu">
      <!--一级菜单展示--有个映射表过滤（v-if）-->
      <span v-for="(v,i) in layout" :key="i" @click="oneMenuClick(v,i)" v-if="filterOneMenu(v)"
            :class="{'active':oneMenu===i}">{{v.title}}</span>
      <span v-if="switchFn" @click="$router.push({path:'/lottery/#'+switchFn})">经典</span>
    </div>
    <div class="twoMenu" v-if="twoMenuInfo&&twoRow_show(v[0].columns)" v-for="(v,i) in twoMenuInfo" :key="i">
      <div class="twoMenuRows" v-for="(s,t) in v" :key="t">
        <label>{{s.title}} :</label>
        <span v-for="(m,n) in s.columns" v-if="gameData.twoMenuMapping[m.shortname]"
              :class="{'active':twoMenu===i&&fourMenu===n&&threeMenu==t}" :key="n"
              @click="twoMenuClick(layout[oneMenu],m,i,t,n)">{{m.showname}}</span>
      </div>
    </div>
    <!--选号区-->
    <al_chooseNumer v-if="currentPlayInfo" :oneMenu="layout[oneMenu].title" :config="gameData.config"
                    :data="currentPlayInfo"></al_chooseNumer>
  </div>
</template>

<script>
  import {getLotteryType} from "../../js/common.js";//公共方法
  import mapping from "./js/mapping.js";//引入映射表--通过id映射表里面获取彩种大类，来展示的玩法
  import service from "../../js/service.js";//引入http请求
  import al_chooseNumer from "./alanChooseNumer.vue";//引入选号页面
  import {mapState, mapMutations} from 'vuex';

  export default {
    props: ['zu'],
    components: {al_chooseNumer},
    data() {
      return {
        biggerLotteyType: '',//通过id查找到的彩种类型 最大的彩种类型  sscs jd flb other elvenY dpc
        mappingType: null,//映射表大类
        layout: null,//所有的一级菜单、二级菜单、玩法介绍等数据
        // oneMenuMaping: null,//一级菜单映射表
        oneMenu: 0,//一级菜单的选中项
        twoMenu: 0,//对应一级菜单不同的玩法加载出不同的页面
        threeMenu: 0,//二级菜单对应的三级选项
        fourMenu: 0,//三级菜单对应的四级数据
        twoMenuInfo: null,//二级菜单的数据
        currentPlayInfo: null,//当前玩法的所有信息
        gameData: null,//游戏数据
        switchFn: 0,//切换官方和经典玩法后的id
      }
    },
    computed: {
      ...mapState(['currentLottery', 'biggerType', 'writeNumber_Menu']),
    },
    watch: {
      currentLottery() {
        this.biggerType !== 'jd' && this.init();
      },
      writeNumber_Menu(cur) {
        if (!cur) return
        // 遍历一级菜单  调整到指定的菜单中去
        let oneI = 0;
        let obj = null;
        for (let val of this.layout) {
          if (val.title === this.writeNumber_Menu && this.gameData.oneMenuMapping[val.title]) {
            obj = val
            this.oneMenuClick(obj, oneI, '单式')
            break
          }
          oneI++
        }

      },
    },
    methods: {
      ...mapMutations(['setData']),
      // 过滤器
      filterOneMenu(v) {
        //这里快3需要做特殊处理，快3的一级菜单是和映射表的包含判断   其他的彩种  一级菜单是相等判断！！！！！！
        if (this.biggerLotteyType.search(/k3/) > -1) {
          for (let key in this.gameData.oneMenuMapping) {
            if (v.title.includes(key) && this.filterTwoMenu(v)) {
              return true
            }
          }
          return false
        } else {
          //这里的验证规则要验证一下是否存在二级菜单  没有就不显示
          return this.gameData.oneMenuMapping[v.title] && this.filterTwoMenu(v)
        }
      },

      // 获取一级和二级菜单的映射表，这个从接口里面取
      findMapping_mapping() {
        this.biggerLotteyType = getLotteryType(this.currentLottery.id) //最大的彩种类型  sscs jd flb other elvenY dpc
        this.setData({key: "biggerType", value: this.biggerLotteyType})
        service.post(this, 'game-lottery/init-game-lottery', {name: this.currentLottery.id}).then(function (result) {
          let data = result.data
          if (data.code === 0) {
            /*
                        * 获取映射表，在this.gameData里面
                        * 菜单映射表使用方法：v-if=obj.xxx
                        * （其实这里并需要通过二级菜单过滤，直接过滤第四级即可，下面的这个方法就是这么做的）
                         */
            this.handleData_twoMenu(data.data)//执行完可以得到映射表
            // 然后开始渲染页面
            this.findMenu();
          } else {
            this.$Modal.al_default({status: 'warning', content: data.message})
          }
        }.bind(this), function (err) {
          console.log(err)
        })
      },
      // 处理四级菜单的映射表数据--其实就是拿的v.method的属性值做筛选，有就展示（写在html里面了span的v-if）
      handleData_twoMenu(v) {
        let obj = {
          info: v.info,
          oneMenuMapping: {},//玩法细类列表--第四级菜单,
          twoMenuMapping: {},//玩法列表--第二级列表
          method: v.method,
        }
        let method = v.method;
        let arr = [];//存放的是一级菜单的映射表
        for (let a in method) {
          let shortName = method[a].name.substr(0, 3);
          let longName = method[a].name;
          longName.includes('3D') && (shortName = longName.replace('3D', '').substr(0, 4));
          shortName === '前四' && (shortName = '前四');
          obj.info.shortName.search(/PK10|11Y|BJPK10/) > -1 && (shortName = longName.substr(0, 5));
          shortName.includes('五星') && (shortName = '五星');
          shortName.includes('不定胆') && (shortName = '不定胆');
          if (shortName.search(/前二|后二|二星后|二星前/) > -1) {
            shortName = (longName.includes('3D') || obj.info.shortName.includes('11Y')) ? '二码' : '二星';
            obj.info.shortName.includes('PK10') && (shortName = '前二');
          }
          shortName.includes('任选') && (shortName = '任选');
          shortName.includes('单式任') && (shortName = '任选');
          shortName.includes('大小') && (shortName = '大小');
          shortName.includes('单双') && (shortName = '单双');
          shortName.search(/组选组六|组选组三/) > -1 && (shortName = longName.includes('3D') ? '三码' : '三星')
          shortName.includes('后三') && !longName.includes('不定胆') && (shortName = '后三');
          longName.includes('不定胆') && (shortName = '不定胆');
          //快3要特殊处理一下
          if (this.biggerLotteyType.search(/k3|pk10/) > -1) {
            shortName.search(/定位胆|后五定|前五定/) > -1 && (shortName = '定位胆');
          } else {
            shortName.includes('定位胆') && (shortName = '定位胆');
          }
          if (shortName.includes('前三')) {
            shortName = '前三';
            if (obj.info.shortName.includes('11Y')) {
              shortName = '三码';
            }
          }
          shortName.includes('后四') && (shortName = '后四');
          shortName.includes('猜1个') && (shortName = '猜中位');
          shortName.includes('猜前四') && (shortName = '前四');
          shortName.includes('猜前五') && (shortName = '前五');
          shortName.search(/龙虎和|龙虎1|龙虎2|龙虎3|龙虎4|龙虎5/) > -1 && (shortName = '龙虎');
          shortName.search(/趣味三|趣味二|趣味一|趣味四|趣味好/) > -1 && (shortName = '趣味');
          shortName.includes('冠军') && (shortName = '前一');
          shortName.includes('中三') && (shortName = '中三');
          shortName.includes('四星') && (shortName = '后四');
          longName.includes('大小单双') && (shortName = '大小单双');
          obj.twoMenuMapping[a] = true// 这个就是第四层菜单的映射表--即二级菜单映射表
          obj.oneMenuMapping[shortName] = true;// 这个shortName就是一级菜单的名字，也就是一级菜单的映射表
        }
        // 这里需要做一个特殊判断 二星为前二和后二
        if (obj.oneMenuMapping['二星']) {
          obj.oneMenuMapping['前二'] = true;
          obj.oneMenuMapping['后二'] = true;
        }
        v.config.userCode = v.code
        obj.config = v.config;// config是选注栏的配置，进度条大小，比率，单价等
        this.gameData = Object.assign({}, obj)
        this.setData({key: "lotteryConfig", value: this.gameData.config})// 将这个config存起来  在我要追号里面的利润率追号中会用到
        this.setData({key: "lotteryTwoMenuMapping", value: this.gameData.twoMenuMapping}) // 这个是当前彩种开启的二级菜单  这个在做号投注里面会使用到，需要筛选一些是否可以放开
      },
      // 从所有的初始玩法（layout）中获取改彩种的各种玩法（一级菜单，二级菜单），用v-if的方法过滤
      findMenu() {
        let lotteryType = 'lottery_' + this.biggerLotteyType;// 比如重庆时时彩就是'lottery_sscs'
        // 获取映射表大类并且保存起来，方便之后引用
        this.mappingType = mapping[lotteryType]
        // 获取一级菜单的映射表--这个是用来限制一级菜单的展示内容--即与layout的一级菜单取并集
        // this.oneMenuMaping = this.mappingType.oneMenuMaping;//映射过程是在html用v-if写的
        //获取所有的菜单、玩法数据，有些是多余的，要通过映射表过滤
        this.layout = this.mappingType.layout
        this.findMenu1(0)
      },
      // 查找一级菜单
      findMenu1(i) {
        //i是一个一级有效菜单的下标
        //通过映射表找到第一个一级菜单，手动传入到一级菜单的点击事件中，并初始化二级菜单
        // let obj = this.layout.find((e)=>(this.gameData.oneMenuMapping[e.title]))  //好像这样写效率也不差,但是拿不到i
        let obj = null
        let index = 0;
        for (let val of this.layout) {
          if (index >= i && this.gameData.oneMenuMapping[val.title]) {
            obj = val;//这个第一个一级有效菜单的数据
            break;   //切记这里只能用break，不能用return
          }
          index++
        }
        // 一级菜单初始化-会联动二级菜单初始化
        this.oneMenuClick(obj, index)//这里不能直接传入this.layout[0]，因为第0个可能在映射表中不存在
      },
      filterTwoMenu(val, name) {  // name是跳到指定的二级菜单下  一般用在做号投注里面 跳到单式
        //循环筛选出二级有效菜单
        for (let [v, i] of new Map(val.rows.map((v, i) => [v, i]))) {   //循环第二层
          for (let [m, n] of new Map(v.map((m, n) => [m, n]))) {    //循环第三层
            // 如果有name  就先循环找指定的二级菜单  循环没有找到就找下面常规的
            if (name) {
              for (let [s, t] of new Map(m.columns.map((s, t) => [s, t]))) {    //循环第四层
                if (this.gameData.twoMenuMapping[s.shortname] && s.showname === name) {
                  return {data: s, twoMenu: i, threeMenu: n, fourMenu: t}
                }
              }
            }
            for (let [s, t] of new Map(m.columns.map((s, t) => [s, t]))) {    //循环第四层
              if (this.gameData.twoMenuMapping[s.shortname]) {
                return {data: s, twoMenu: i, threeMenu: n, fourMenu: t}
              }
            }
          }
        }
      },
      // 查看二级菜单的一行是否有一个数据可以展示 没有的话  就整行隐藏掉
      twoRow_show(v) {
        for (let val of v) {
          if (this.gameData.twoMenuMapping[val.shortname]) {
            return true
          }
        }
        return false
      },


      // 点击事件
      oneMenuClick(v, i, name) {// name是跳到指定的二级菜单下  一般用在做号投注里面 跳到单式
        if (!v) return;
        //保存二级菜单的第一个有效对象数据
        // let data = v.rows[0][0].columns[0]   //不能这么直接赋值，会出问题的，需要通过映射表筛选一下
        //所以这里就有一个三层的循环，为了直接跳出，最好使用return+函数，省去不必要的多次break
        let obj = this.filterTwoMenu(v, name)    //obj里面的数据应该第四层的数据，第2，3,4层对应的下标
        if (!obj) {// 如果为false说明没有二级菜单  需要直接去找当前一级菜单的下一个菜单
          i < this.layout.length && this.findMenu1(++i)
          return
        }
        //初始化一级菜单
        this.oneMenu = i;
        // 对应的二级菜单数据初始化
        // v是当前选中的四级菜单，也就是最小的玩法级别，可以具体怎么玩，有详细的彩种玩法说明
        this.twoMenuClick(v, obj.data, obj.twoMenu, obj.threeMenu, obj.fourMenu)//二级菜单初始化
      },
      // 二层三层div是不可点的  但是二级菜单是可以初始化的
      twoMenuClick(oneMenuData, v, i, t, n) {
        // 先把组态事件回调到父组件，为了就是拿到排行榜第三列的数据并展示
        this.zu(oneMenuData.title, this.mappingType, v.showname);//传参是一级菜单名字和第二级菜单名字
        // 更新选号区内容和选号的数据
        this.twoMenuInfo = this.layout[this.oneMenu].rows;
        // 这里有个问题  就是当页面是时时彩五星的时候  切到菲律宾五星时   这个置虽然是赋值了 但是并没有改变  所以选号区的watch监听不到  所以这里加一个神复制操作
        this.currentPlayInfo = Object.assign({}, v)
        // i,t,n是对应的二三四层--对应控制的就是二级菜单的active
        this.twoMenu = i;
        this.threeMenu = t;
        this.fourMenu = n;

        // 最后把当前玩法的类型和奖金存在vuex中，当点击投注的时候  类型会展示在表格中  奖金会在添加号码弹出框中提示出来
        this.setData({key: "lottery_method", value: this.gameData.method[v.shortname]}) //如  当前玩法的说有配置数据  在选择号码的时候有很多用处  比如中文玩法名称  最高奖金
        this.setData({key: "currentPlayInfo", value: v}) // 当前玩法对象存起来  确定投注按钮可以使用其数据 shortname compress
      },


      init() {
        this.switchFn = this.dictionary[0][this.currentLottery.id]
        this.findMapping_mapping()
      }
    }
    ,
    created() {
      this.init();
    }
    ,
    mounted() {
      console.log(this.$store.state.appConfigData)
    }
    ,

  }
</script>

<style lang='less' scoped>
  @import "../../css/global.less";

  .playFn {
    background: #fff;
    .oneMenu {
      width: 100%;
      overflow: hidden;
      background: @oneMenuBg;
      position: relative;
      span {
        position: relative;
        float: left;
        width: 68px;
        height: 40px;
        line-height: 40px;
        color: @oneMenuColor;
        font-size: 14px;
        cursor: pointer;
        z-index: 22;
        &.active {
          color: @themeColor !important;
          /*border-top: 3px solid #F53B4A;*/
          background: #fff;
          .al_navWood;
        }
        &:hover {
          /*color: #3bac87 !important;*/
          /*border-bottom: 3px solid #3bac87;*/
        }
      }
    }
    .twoMenu {
      font-size: 14px;
      overflow: hidden;
      width: auto;
      border-top: 0px;
      background-color: #fff;
      text-align: left;
      padding: 0 10px;
      /*height: 38px;*/
      color: @twoMenuColor_Sel;
      padding-top: 12px;
      .twoMenuRows {
        display: inline-block;
        float: left;
        margin-right: 24px;
        &:last-child {
          margin-right: 0px;
        }
        label {
          height: 24px;
          line-height: 24px;
          /*margin: 0 10px;*/
          color: @twoMenuColor_Lab;
          text-align: left;
          margin-right: 10px;
        }
        span {
          height: 24px;
          line-height: 22px;
          background-color: #F0F0F0;
          padding: 0 8px;
          margin: 0 8px;
          /* float: left; */
          cursor: pointer;
          min-width: 60px;
          overflow: hidden;
          text-align: center;
          border-radius: 4px;
          display: inline-block;
          vertical-align: middle;
          font-size: 12px;
          .bor(#EBEBEB);
          &:hover, &.active {
            background: @themeColor;
            color: #fff;
            border-color: transparent;
          }
        }

      }
    }
    .twoMenu:first-child {
      margin-bottom: 12px;
    }

  }

  @media screen and (max-width: 1024px) {
    .playFn {
      .oneMenu {
        > span {
          width: 54px;
          padding: 0;
        }
      }
      .twoMenu {
        height: unset;

      }
    }
  }
</style>
